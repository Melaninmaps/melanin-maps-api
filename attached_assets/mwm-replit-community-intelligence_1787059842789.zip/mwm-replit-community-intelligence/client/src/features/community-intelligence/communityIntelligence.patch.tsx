// Replace every product/navigation occurrence of the old Community Safety label.
// Do not globally replace ordinary emergency or personal-safety guidance where it is factually necessary.

import { communityIntelligenceCopy } from "./communityIntelligenceCopy";

// Navigation
// BEFORE: <NavLink to="/safety">Safety</NavLink>
// AFTER:
export const communityIntelligenceNavItem = { href: "/community-intelligence", label: communityIntelligenceCopy.nav };

// Page hero
// BEFORE: <p>COMMUNITY SAFETY</p><h1>Safety Hub</h1>
// AFTER:
export function CommunityIntelligenceHero() {
  return <header><p>{communityIntelligenceCopy.eyebrow}</p><h1>{communityIntelligenceCopy.title}</h1><p>{communityIntelligenceCopy.subtitle}</p><p>{communityIntelligenceCopy.body}</p></header>;
}

// Map/directory metadata
// BEFORE: "Safe stay" / "Safety context" / `neighborhoodSafetyScore`
// AFTER: "Community-sourced local context" / `communityIntelligenceSignals`
// No map marker, recommendation, or filter may use diversity/demographic composition as a risk variable.

// Keep this separate from actual emergency affordances:
// "Get emergency help" and official alerts must remain accurately labeled; they are not Community Intelligence.
