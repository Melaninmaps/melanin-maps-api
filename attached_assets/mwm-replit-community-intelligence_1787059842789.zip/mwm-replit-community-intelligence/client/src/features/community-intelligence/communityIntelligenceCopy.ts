export const communityIntelligenceCopy = {
  nav: "Community Intelligence",
  eyebrow: "COMMUNITY-SOURCED CONTEXT",
  title: "Community Intelligence",
  subtitle: "Community-sourced context for informed choices.",
  body: "Explore shared experiences about access, arrival, atmosphere, local connection, and practical details—without reducing a neighborhood or its people to a safety judgment.",
  empty: "Community insight is still growing here. You can browse trusted local resources or share a respectful experience.",
  sourceLabel: "Community-sourced insight",
  contributionTitle: "Share community context",
  contributionPrompt: "What would help another community member plan, arrive, connect, or make an informed choice?",
  evidenceNote: "Shared experiences are moderated and shown as context, not as a score or judgment about a community.",
};
