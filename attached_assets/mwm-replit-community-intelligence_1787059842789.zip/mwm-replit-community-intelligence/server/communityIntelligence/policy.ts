export const COMMUNITY_INTELLIGENCE_LANGUAGE = {
  productName: "Community Intelligence",
  navigationLabel: "Community Intelligence",
  headline: "Community-sourced context for informed choices.",
  description: "See what community members share about places, access, atmosphere, local connection, and practical experiences.",
  evidenceLabel: "Community-sourced insight",
  disclaimer: "Community Intelligence reflects shared experiences and practical local context. It is not a judgment about a neighborhood or the people who live there.",
} as const;

export const PROHIBITED_COMMUNITY_INFERENCES = [
  "minority presence means unsafe",
  "lack of diversity means unsafe",
  "demographic composition determines safety",
  "neighborhood safety score from race or ethnicity",
  "community unsafe because it is minority",
] as const;

export type CommunityIntelligenceSignal = {
  placeId: string;
  category: "access" | "arrival" | "atmosphere" | "business_experience" | "community_connection" | "event_experience" | "practical_context";
  observation: string;
  sourceType: "member_review" | "member_check_in" | "verified_organization" | "public_source";
  sourceId: string;
  observedAt: string;
  moderationStatus: "pending" | "approved" | "rejected";
};

export function isPermittedSignal(signal: CommunityIntelligenceSignal) {
  const text = signal.observation.toLowerCase();
  return signal.moderationStatus === "approved"
    && signal.observation.trim().length > 0
    && !/(minority|race|ethnicity|diversity).{0,40}(unsafe|dangerous|safe)/i.test(text);
}

export function communityIntelligencePromptRules() {
  return [
    "Describe only source-backed community-sourced observations.",
    "Do not rate, rank, or infer a neighborhood's safety from race, ethnicity, diversity, or minority presence.",
    "Do not call a place safe or unsafe unless the answer clearly attributes a timely, specific observation to an approved source and states its limits.",
    "Use 'Community-sourced context' and identify the signal type, coverage, and date when available.",
    "For immediate danger or emergency situations, direct people to emergency services rather than presenting Community Intelligence as emergency guidance.",
  ].join("\n");
}
