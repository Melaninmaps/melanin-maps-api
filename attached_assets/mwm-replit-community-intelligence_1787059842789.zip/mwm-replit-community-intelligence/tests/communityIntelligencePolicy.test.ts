import { expect, test } from "vitest";
import { COMMUNITY_INTELLIGENCE_LANGUAGE, isPermittedSignal } from "../server/communityIntelligence/policy";

test("uses Community Intelligence rather than Community Safety", () => {
  expect(COMMUNITY_INTELLIGENCE_LANGUAGE.productName).toBe("Community Intelligence");
  expect(COMMUNITY_INTELLIGENCE_LANGUAGE.description.toLowerCase()).toContain("community-sourced");
  expect(JSON.stringify(COMMUNITY_INTELLIGENCE_LANGUAGE)).not.toMatch(/community safety/i);
});

test("rejects demographic or diversity-based safety judgments", () => {
  const common = { placeId: "place-1", category: "practical_context" as const, sourceType: "member_review" as const, sourceId: "review-1", observedAt: "2026-08-18", moderationStatus: "approved" as const };
  expect(isPermittedSignal({ ...common, observation: "The neighborhood is unsafe because it lacks diversity." })).toBe(false);
  expect(isPermittedSignal({ ...common, observation: "A member shared that the entrance is accessible from the main street." })).toBe(true);
});

test("keeps emergency guidance separate from community-sourced context", () => {
  expect(COMMUNITY_INTELLIGENCE_LANGUAGE.disclaimer).toMatch(/not a judgment/i);
});
