-- PostgreSQL migration: community-informed hair and health recommendations.
-- Community signals are moderated evidence of member experience, never medical claims.

CREATE TABLE IF NOT EXISTS care_provider_profiles (
  business_id UUID PRIMARY KEY REFERENCES businesses(id) ON DELETE CASCADE,
  provider_type TEXT NOT NULL CHECK (provider_type IN ('dermatologist', 'hair_care_professional')),
  professional_verification TEXT NOT NULL CHECK (
    professional_verification IN ('board_certified', 'licensed', 'directory_verified', 'unverified')
  ),
  verification_reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS provider_community_signals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  label TEXT NOT NULL CHECK (label IN (
    'growing_hands', 'hair_loss_support', 'scalp_care',
    'protective_style_care', 'gentle_detangling',
    'stylist_listens', 'culturally_knowledgeable'
  )),
  confirmed_member_count INTEGER NOT NULL DEFAULT 0,
  recent_confirmed_member_count INTEGER NOT NULL DEFAULT 0,
  moderation_status TEXT NOT NULL DEFAULT 'pending' CHECK (moderation_status IN ('approved', 'pending', 'rejected')),
  last_reviewed_at TIMESTAMPTZ,
  UNIQUE (business_id, label)
);

CREATE INDEX IF NOT EXISTS provider_community_signals_recommendation_idx
  ON provider_community_signals (business_id, moderation_status, label)
  WHERE moderation_status = 'approved';

-- Operational rule:
-- 1. A community member may submit feedback in a separate private review flow.
-- 2. Aggregate/verify it before incrementing confirmed_member_count here.
-- 3. Never display member names or raw sensitive hair/health details.
-- 4. Do not approve “growing hands” unless at least three independent,
--    non-duplicative member confirmations meet the moderation standard.
