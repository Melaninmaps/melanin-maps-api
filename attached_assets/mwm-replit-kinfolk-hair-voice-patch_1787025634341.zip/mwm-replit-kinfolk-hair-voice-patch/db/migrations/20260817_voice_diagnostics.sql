-- PostgreSQL migration: voice capture/transcription diagnostics.
-- Stores operational error metadata only; never audio blobs or transcript text.

CREATE TABLE IF NOT EXISTS kinfolk_voice_diagnostic_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  member_id UUID REFERENCES users(id) ON DELETE SET NULL,
  stage TEXT NOT NULL CHECK (stage IN ('received', 'rejected', 'transcribed', 'failed')),
  code TEXT NOT NULL,
  mime_type TEXT,
  byte_count INTEGER,
  detail TEXT,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS kinfolk_voice_diagnostic_events_recent_idx
  ON kinfolk_voice_diagnostic_events (occurred_at DESC, code);
