import assert from "node:assert/strict";
import {
  buildHairLossCarePlan,
  getOptionalHairLossRecommendations,
  scoreCommunityHairCareProvider,
} from "./server/kinfolk/hairCare/hairLossRecommendation";

const communityProvider = {
  id: "stylist-1",
  name: "Community Hair Professional",
  providerType: "hair_care_professional" as const,
  category: "Hair Care",
  city: "Charlotte",
  stateCode: "NC",
  addressLine1: "100 Example Street",
  detailUrl: "/businesses/stylist-1",
  isVerified: true,
  professionalVerification: "licensed" as const,
  communitySignals: [
    { label: "growing_hands" as const, confirmedMemberCount: 6, recentConfirmedMemberCount: 3, moderationStatus: "approved" as const },
    { label: "hair_loss_support" as const, confirmedMemberCount: 4, recentConfirmedMemberCount: 2, moderationStatus: "approved" as const },
    { label: "scalp_care" as const, confirmedMemberCount: 3, recentConfirmedMemberCount: 2, moderationStatus: "approved" as const },
  ],
  distanceMiles: 3,
};

async function main() {
  const plan = buildHairLossCarePlan();
  assert.equal(plan.optionalPaths.length, 2);
  assert.ok(plan.optionalPaths.some((path) => path.id === "show_dermatologists"));
  assert.ok(plan.optionalPaths.some((path) => path.id === "show_hair_loss_stylists"));

  const communityRecommendation = scoreCommunityHairCareProvider(communityProvider);
  assert.ok(communityRecommendation);
  assert.ok(communityRecommendation.reasons.join(" ").includes("growing hands"));

  const repository = {
    async findVerifiedCareProviders({ providerType }: { providerType: "dermatologist" | "hair_care_professional" }) {
      if (providerType === "hair_care_professional") return [communityProvider];
      return [
        {
          ...communityProvider,
          id: "dermatologist-1",
          name: "Board-Certified Dermatologist",
          providerType: "dermatologist" as const,
          category: "Dermatology",
          professionalVerification: "board_certified" as const,
          communitySignals: [],
        },
      ];
    },
  };

  const dermatologists = await getOptionalHairLossRecommendations({
    action: "show_dermatologists",
    location: { city: "Charlotte", stateCode: "NC" },
    repository,
  });
  const stylists = await getOptionalHairLossRecommendations({
    action: "show_hair_loss_stylists",
    location: { city: "Charlotte", stateCode: "NC" },
    repository,
  });
  assert.equal(dermatologists[0]?.providerType, "dermatologist");
  assert.equal(stylists[0]?.providerType, "hair_care_professional");

  console.log("Community-informed hair-care path smoke test passed.");
}

void main();
