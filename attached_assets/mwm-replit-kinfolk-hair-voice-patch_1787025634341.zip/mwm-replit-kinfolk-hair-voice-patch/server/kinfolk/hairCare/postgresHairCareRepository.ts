import type { CareProvider, CommunitySignal, HairCareRepository } from "./types";

type Queryable = {
  query<T>(sql: string, parameters?: unknown[]): Promise<{ rows: T[] }>;
};

type ProviderRow = {
  id: string;
  name: string;
  provider_type: CareProvider["providerType"];
  category: string;
  city: string | null;
  state_code: string | null;
  address_line_1: string | null;
  professional_verification: CareProvider["professionalVerification"];
  signals: CommunitySignal[] | null;
};

export function createPostgresHairCareRepository(db: Queryable): HairCareRepository {
  return {
    async findVerifiedCareProviders({ providerType, city, stateCode, limit }) {
      const { rows } = await db.query<ProviderRow>(
        `SELECT
          b.id,
          b.name,
          cpp.provider_type,
          b.category,
          c.name AS city,
          c.state_code,
          b.address_line_1,
          cpp.professional_verification,
          COALESCE(
            json_agg(
              json_build_object(
                'label', pcs.label,
                'confirmedMemberCount', pcs.confirmed_member_count,
                'recentConfirmedMemberCount', pcs.recent_confirmed_member_count,
                'moderationStatus', pcs.moderation_status
              )
            ) FILTER (WHERE pcs.id IS NOT NULL),
            '[]'::json
          ) AS signals
        FROM businesses b
        JOIN care_provider_profiles cpp ON cpp.business_id = b.id
        LEFT JOIN cities c ON c.id = b.city_id
        LEFT JOIN provider_community_signals pcs ON pcs.business_id = b.id
        WHERE b.is_active = TRUE
          AND b.is_verified = TRUE
          AND cpp.provider_type = $1
          AND ($2::text IS NULL OR LOWER(c.name) = LOWER($2))
          AND ($3::text IS NULL OR UPPER(c.state_code) = UPPER($3))
        GROUP BY b.id, cpp.provider_type, cpp.professional_verification, c.name, c.state_code
        ORDER BY COALESCE(b.curation_score, 0) DESC, b.name ASC
        LIMIT $4`,
        [providerType, city, stateCode, Math.min(Math.max(limit, 1), 25)],
      );

      return rows.map((row) => ({
        id: row.id,
        name: row.name,
        providerType: row.provider_type,
        category: row.category,
        city: row.city,
        stateCode: row.state_code,
        addressLine1: row.address_line_1,
        detailUrl: `/businesses/${encodeURIComponent(row.id)}`,
        isVerified: true,
        professionalVerification: row.professional_verification,
        communitySignals: row.signals ?? [],
        distanceMiles: null,
      }));
    },
  };
}
