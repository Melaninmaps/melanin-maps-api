import { describe, expect, it } from "vitest";
import {
  buildHairLossCarePlan,
  getOptionalHairLossRecommendations,
  scoreCommunityHairCareProvider,
} from "./hairLossRecommendation";
import type { CareProvider } from "./types";

function hairProfessional(signals: CareProvider["communitySignals"]): CareProvider {
  return {
    id: "stylist-1",
    name: "Community Hair Professional",
    providerType: "hair_care_professional",
    category: "Hair Care",
    city: "Charlotte",
    stateCode: "NC",
    addressLine1: "100 Example Street",
    detailUrl: "/businesses/stylist-1",
    isVerified: true,
    professionalVerification: "licensed",
    communitySignals: signals,
    distanceMiles: 3,
  };
}

describe("Kinfolk hair-loss recommendation paths", () => {
  it("offers both dermatology and community hair-care paths", () => {
    const plan = buildHairLossCarePlan();
    expect(plan.optionalPaths.map((path) => path.id)).toEqual([
      "show_dermatologists",
      "show_hair_loss_stylists",
    ]);
  });

  it("surfaces a community hair-care professional only with sufficient approved evidence", () => {
    const recommendation = scoreCommunityHairCareProvider(
      hairProfessional([
        { label: "growing_hands", confirmedMemberCount: 6, recentConfirmedMemberCount: 3, moderationStatus: "approved" },
        { label: "hair_loss_support", confirmedMemberCount: 4, recentConfirmedMemberCount: 2, moderationStatus: "approved" },
        { label: "scalp_care", confirmedMemberCount: 3, recentConfirmedMemberCount: 2, moderationStatus: "approved" },
      ]),
    );

    expect(recommendation?.communityTrustScore).toBeGreaterThanOrEqual(0.55);
    expect(recommendation?.reasons.join(" ")).toContain("growing hands");
  });

  it("does not elevate a generic salon from unmoderated or insufficient signals", () => {
    const recommendation = scoreCommunityHairCareProvider(
      hairProfessional([
        { label: "growing_hands", confirmedMemberCount: 1, recentConfirmedMemberCount: 1, moderationStatus: "pending" },
      ]),
    );
    expect(recommendation).toBeNull();
  });

  it("keeps dermatology and community care as distinct optional result sets", async () => {
    const dermatologist: CareProvider = {
      ...hairProfessional([]),
      id: "derm-1",
      name: "Board-Certified Dermatologist",
      providerType: "dermatologist",
      category: "Dermatology",
      professionalVerification: "board_certified",
    };
    const repository = {
      async findVerifiedCareProviders({ providerType }: { providerType: CareProvider["providerType"] }) {
        return providerType === "dermatologist"
          ? [dermatologist]
          : [
              hairProfessional([
                { label: "growing_hands", confirmedMemberCount: 6, recentConfirmedMemberCount: 3, moderationStatus: "approved" },
                { label: "hair_loss_support", confirmedMemberCount: 4, recentConfirmedMemberCount: 2, moderationStatus: "approved" },
              ]),
            ];
      },
    };

    const medical = await getOptionalHairLossRecommendations({
      action: "show_dermatologists",
      location: { city: "Charlotte", stateCode: "NC" },
      repository,
    });
    const community = await getOptionalHairLossRecommendations({
      action: "show_hair_loss_stylists",
      location: { city: "Charlotte", stateCode: "NC" },
      repository,
    });

    expect(medical[0]?.providerType).toBe("dermatologist");
    expect(community[0]?.providerType).toBe("hair_care_professional");
  });
});
