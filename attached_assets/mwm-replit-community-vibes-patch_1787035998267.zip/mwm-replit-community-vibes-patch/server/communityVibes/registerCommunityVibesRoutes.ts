import type { Express, Request, Response, NextFunction } from "express";
import { CommunityVibesRepository } from "./communityVibesRepository";

type AuthenticatedRequest = Request & { user?: { id: string } };

export function registerCommunityVibesRoutes(app: Express, repository: CommunityVibesRepository) {
  app.get("/api/businesses/:businessId/community-vibes", async (request: Request, response: Response, next: NextFunction) => {
    try {
      const payload = await repository.getForBusiness(request.params.businessId);
      if (!payload) return response.status(404).json({ code: "BUSINESS_NOT_FOUND" });
      response.setHeader("Cache-Control", "no-store");
      return response.json(payload);
    } catch (error) {
      return next(error);
    }
  });

  app.post("/api/businesses/:businessId/community-vibes", async (request: AuthenticatedRequest, response: Response, next: NextFunction) => {
    try {
      if (!request.user) return response.status(401).json({ code: "AUTHENTICATION_REQUIRED" });
      const { sourceId, vibeKeys } = request.body ?? {};
      if (typeof sourceId !== "string" || !Array.isArray(vibeKeys) || !vibeKeys.every((value) => typeof value === "string")) {
        return response.status(400).json({ code: "INVALID_VIBE_SUBMISSION" });
      }
      await repository.submitMemberTags({ businessId: request.params.businessId, memberId: request.user.id, sourceId, vibeKeys });
      return response.status(202).json({ status: "PENDING_MODERATION" });
    } catch (error) {
      return next(error);
    }
  });
}
