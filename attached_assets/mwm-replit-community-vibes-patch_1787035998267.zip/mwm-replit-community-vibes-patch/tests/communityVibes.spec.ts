import { expect, test } from "@playwright/test";

const businessId = process.env.E2E_BUSINESS_ID!;

test.describe("dynamic Community Vibes", () => {
  test("a zero-evidence business shows an honest empty state rather than static default chips", async ({ page }) => {
    await page.goto(`/businesses/${businessId}`);
    const section = page.getByRole("region", { name: /community vibes/i });
    await expect(section.getByText(/community is still building this story/i)).toBeVisible();
    await expect(section.getByText("Locals Know")).not.toBeVisible();
    await expect(section.getByText("Auntie Energy")).not.toBeVisible();
  });

  test("approved evidence displays aggregate voice counts without contributor identities", async ({ request }) => {
    const response = await request.get(`/api/businesses/${businessId}/community-vibes`);
    expect(response.ok()).toBeTruthy();
    const payload = await response.json();
    for (const vibe of payload.vibes) {
      expect(vibe).toHaveProperty("voices");
      expect(vibe).not.toHaveProperty("contributorId");
      expect(vibe).not.toHaveProperty("contributorEmail");
    }
  });

  test("a signed-in member can submit up to three tag choices, which remain pending until moderation", async ({ page }) => {
    await page.goto(`/businesses/${businessId}`);
    await page.getByRole("button", { name: /add your experience/i }).click();
    await page.getByLabel(/locals know/i).check();
    await page.getByLabel(/neighborhood love/i).check();
    await page.getByRole("button", { name: /submit for review/i }).click();
    await expect(page.getByText(/queued for moderation/i)).toBeVisible();
  });
});
