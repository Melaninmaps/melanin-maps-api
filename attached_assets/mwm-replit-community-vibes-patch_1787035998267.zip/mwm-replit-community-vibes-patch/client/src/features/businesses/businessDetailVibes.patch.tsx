// Replace the static component block and delete any DEFAULT_VIBES, BUSINESS_VIBES,
// or hard-coded `['Locals Know', ...]` array used by the business detail page.

import { CommunityVibes } from "./CommunityVibes";

// Inside the existing business-detail page, where `business`, `viewer`, and the active
// verified check-in (if any) are already available:
<CommunityVibes
  businessId={business.id}
  isAuthenticated={Boolean(viewer)}
  checkinId={activeCheckin?.id}
/>;

// Important: do not pass generic display tags as props. This component fetches
// /api/businesses/:businessId/community-vibes and treats a zero-evidence result as an
// honest empty state instead of displaying a preconfigured tag list.
