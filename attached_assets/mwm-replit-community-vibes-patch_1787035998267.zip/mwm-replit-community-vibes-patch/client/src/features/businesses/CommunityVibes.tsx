import { useEffect, useState } from "react";

type Vibe = { vibeKey: string; label: string; voices: number; evidenceCount: number; confidence: "emerging" | "growing" | "established"; lastEvidenceAt: string };
type Payload = { businessId: string; voices: number; vibes: Vibe[]; contributionChoices: Array<{ vibeKey: string; label: string }>; updatedAt: string | null };

type Props = { businessId: string; checkinId?: string; isAuthenticated: boolean };

export function CommunityVibes({ businessId, checkinId, isAuthenticated }: Props) {
  const [payload, setPayload] = useState<Payload | null>(null);
  const [state, setState] = useState<"loading" | "ready" | "error" | "contributing" | "submitted">("loading");
  const [selectedKeys, setSelectedKeys] = useState<string[]>([]);

  useEffect(() => {
    let active = true;
    setState("loading");
    fetch(`/api/businesses/${encodeURIComponent(businessId)}/community-vibes`, { headers: { Accept: "application/json" } })
      .then((response) => response.ok ? response.json() : Promise.reject(new Error("VIBES_REQUEST_FAILED")))
      .then((result: Payload) => { if (active) { setPayload(result); setState("ready"); } })
      .catch(() => { if (active) setState("error"); });
    return () => { active = false; };
  }, [businessId]);

  function toggleChoice(key: string) {
    setSelectedKeys((selected) => selected.includes(key) ? selected.filter((value) => value !== key) : selected.length < 3 ? [...selected, key] : selected);
  }

  async function submit() {
    if (!checkinId || selectedKeys.length === 0) return;
    const response = await fetch(`/api/businesses/${encodeURIComponent(businessId)}/community-vibes`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sourceId: checkinId, vibeKeys: selectedKeys }),
    });
    setState(response.status === 202 ? "submitted" : "error");
  }

  return <section aria-labelledby="community-vibes-heading" className="community-vibes-card">
    <div className="flex items-start justify-between gap-4"><div><h2 id="community-vibes-heading">Community Vibes</h2><p className="community-vibes-subtitle">What approved community voices say about this place.</p></div>{payload?.voices ? <span className="community-voice-count">{payload.voices} {payload.voices === 1 ? "voice" : "voices"}</span> : null}</div>
    {state === "loading" ? <p className="community-vibes-loading">Loading community evidence…</p> : null}
    {state === "error" ? <p className="community-vibes-error">Community Vibes are temporarily unavailable. Please try again.</p> : null}
    {state === "ready" && payload?.vibes.length === 0 ? <div className="community-vibes-empty"><strong>The community is still building this story.</strong><p>No approved vibe tags have been recorded for this place yet.</p></div> : null}
    {state === "ready" && payload?.vibes.length ? <ul aria-label="Approved community vibes" className="community-vibe-list">{payload.vibes.map((vibe) => <li key={vibe.vibeKey}><span className={`community-vibe-chip community-vibe-chip--${vibe.confidence}`}>{vibe.label}</span><small>{vibe.confidence === "emerging" ? "Emerging signal" : `${vibe.voices} community voices`}</small></li>)}</ul> : null}
    {state === "submitted" ? <p className="community-vibes-submitted">Thank you. Your experience is queued for moderation before it contributes to the community view.</p> : null}
    {state === "ready" && isAuthenticated && checkinId ? <button className="community-vibes-action" onClick={() => setState("contributing")} type="button">Add your experience</button> : null}
    {state === "ready" && !isAuthenticated ? <a className="community-vibes-action" href={`/login?next=${encodeURIComponent(location.pathname)}`}>Sign in to share your experience</a> : null}
    {state === "ready" && isAuthenticated && !checkinId ? <p className="community-vibes-hint">Check in or add a review to contribute a verified experience.</p> : null}
    {state === "contributing" && payload ? <div className="community-vibe-contribute"><p>Select up to three tags that match your visit. These are contribution choices, not existing community claims.</p><div className="community-vibe-choice-list">{payload.contributionChoices.map((choice) => <label key={choice.vibeKey}><input checked={selectedKeys.includes(choice.vibeKey)} onChange={() => toggleChoice(choice.vibeKey)} type="checkbox" />{choice.label}</label>)}</div><div className="community-vibe-contribute-actions"><button onClick={() => setState("ready")} type="button">Cancel</button><button disabled={selectedKeys.length === 0} onClick={submit} type="button">Submit for review</button></div></div> : null}
  </section>;
}
