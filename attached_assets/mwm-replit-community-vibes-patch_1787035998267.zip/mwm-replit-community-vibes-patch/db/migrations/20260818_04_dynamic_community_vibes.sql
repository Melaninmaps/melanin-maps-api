BEGIN;

-- Definitions are the controlled vocabulary. They are not displayed as a business's
-- community evidence until the approved evidence table supports them.
CREATE TABLE IF NOT EXISTS public.community_vibe_definitions (
  vibe_key text PRIMARY KEY,
  display_label text NOT NULL,
  eligible_categories text[] NOT NULL DEFAULT '{}',
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (btrim(vibe_key) <> ''),
  CHECK (btrim(display_label) <> '')
);

-- Each row is a specific, auditable contribution. Server code generates the UUID so
-- this migration has no extension dependency. A member can update their source entry,
-- but cannot create duplicate evidence for the same vibe/source pair.
CREATE TABLE IF NOT EXISTS public.business_vibe_evidence (
  id uuid PRIMARY KEY,
  business_id uuid NOT NULL REFERENCES public.businesses(id) ON DELETE CASCADE,
  vibe_key text NOT NULL REFERENCES public.community_vibe_definitions(vibe_key),
  source_type text NOT NULL CHECK (source_type IN ('review', 'checkin', 'member_tag')),
  source_id uuid NOT NULL,
  contributor_id uuid NOT NULL,
  moderation_status text NOT NULL DEFAULT 'pending' CHECK (moderation_status IN ('pending', 'approved', 'rejected', 'removed')),
  weight numeric(5,2) NOT NULL DEFAULT 1.00 CHECK (weight > 0 AND weight <= 5),
  created_at timestamptz NOT NULL DEFAULT now(),
  moderated_at timestamptz,
  UNIQUE (source_type, source_id, vibe_key)
);

CREATE INDEX IF NOT EXISTS business_vibe_evidence_lookup
  ON public.business_vibe_evidence (business_id, moderation_status, created_at DESC);
CREATE INDEX IF NOT EXISTS business_vibe_evidence_contributor
  ON public.business_vibe_evidence (contributor_id, created_at DESC);

-- This view is the only public read model. It intentionally exposes aggregate counts,
-- never a list of contributor identities. One approved voice is labeled emerging, not
-- presented as a settled community conclusion.
CREATE OR REPLACE VIEW public.approved_business_vibes AS
SELECT
  evidence.business_id,
  evidence.vibe_key,
  definition.display_label,
  count(*)::int AS evidence_count,
  count(DISTINCT evidence.contributor_id)::int AS voice_count,
  round(sum(evidence.weight)::numeric, 2) AS weighted_score,
  max(evidence.created_at) AS last_evidence_at,
  CASE
    WHEN count(DISTINCT evidence.contributor_id) >= 3 THEN 'established'
    WHEN count(DISTINCT evidence.contributor_id) = 2 THEN 'growing'
    ELSE 'emerging'
  END AS confidence
FROM public.business_vibe_evidence AS evidence
JOIN public.community_vibe_definitions AS definition ON definition.vibe_key = evidence.vibe_key
WHERE evidence.moderation_status = 'approved'
  AND definition.active = true
GROUP BY evidence.business_id, evidence.vibe_key, definition.display_label;

-- Seed vocabulary; these are contribution choices only. They must not be rendered as
-- a business's existing vibes without rows in approved_business_vibes.
INSERT INTO public.community_vibe_definitions (vibe_key, display_label, eligible_categories)
VALUES
  ('locals-know', 'Locals Know', ARRAY['bookstore', 'restaurant', 'barbershop', 'salon']),
  ('auntie-energy', 'Auntie Energy', ARRAY['bookstore', 'salon', 'barbershop', 'restaurant']),
  ('hood-classic', 'Hood Classic', ARRAY['bookstore', 'restaurant', 'barbershop', 'salon']),
  ('soft-life', 'Soft Life', ARRAY['salon', 'spa', 'restaurant', 'hotel']),
  ('neighborhood-love', 'Neighborhood Love', ARRAY['bookstore', 'restaurant', 'barbershop', 'salon']),
  ('history-lives-here', 'History Lives Here', ARRAY['bookstore', 'cultural_site', 'museum']),
  ('take-somebody-out-of-town', 'Take Somebody From Out of Town', ARRAY['restaurant', 'cultural_site', 'museum'])
ON CONFLICT (vibe_key) DO UPDATE
SET display_label = EXCLUDED.display_label,
    eligible_categories = EXCLUDED.eligible_categories;

COMMIT;
