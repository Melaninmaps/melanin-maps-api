import Constants from "expo-constants";
import * as SecureStore from "expo-secure-store";

const API_BASE = (Constants.expoConfig?.extra?.apiBaseUrl as string | undefined) ?? "https://api.melaninmaps.com";
const TOKEN_KEY = "mwm.mobile.access-token";

export type Coordinates = { latitude: number; longitude: number };
export type LocalBusiness = { id: string; name: string; slug: string; category: string; city: string; state: string; latitude: number; longitude: number; distanceMiles: number; detailUrl: string };
export type LocalSearchResponse = { results: LocalBusiness[]; searchRadiusMiles: number; limit: number; canExpand: boolean; expansionOptions: number[]; message?: string };
export type LibraryTopic = { id: string; slug: string; title: string; summary: string; iconKey: string; entryCount: number };

async function headers(extra?: HeadersInit) {
  const token = await SecureStore.getItemAsync(TOKEN_KEY);
  return { Accept: "application/json", "X-Client-Surface": "native", ...(token ? { Authorization: `Bearer ${token}` } : {}), ...extra };
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const response = await fetch(`${API_BASE}${path}`, { ...init, headers: await headers(init.headers) });
  const body = await response.json().catch(() => null);
  if (!response.ok) throw Object.assign(new Error(body?.message ?? "REQUEST_FAILED"), { code: body?.code, status: response.status });
  return body as T;
}

export const mwmApi = {
  async localBusinesses(query: string, location: Coordinates, radiusMiles = 5) {
    const params = new URLSearchParams({ query, latitude: String(location.latitude), longitude: String(location.longitude), radiusMiles: String(radiusMiles), limit: "2" });
    return request<LocalSearchResponse>(`/api/map/local-business-search?${params}`);
  },
  async resolveArea(query: string) {
    return request<{ location: Coordinates & { label: string } }>("/api/location/resolve", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ query }) });
  },
  async libraryTopics() { return request<{ topics: LibraryTopic[] }>("/api/library/topics"); },
  async culturalSite(id: string) { return request<{ id: string; slug: string; title: string; detailUrl: string }>(`/api/cultural-sites/${encodeURIComponent(id)}`); },
  async prepareKinfolkResearch(question: string, subject: "me" | "someone_else" | "general_research" | "unknown") {
    return request<{ topic: string; researchQuery: string; clarification: unknown[] }>("/api/kinfolk/research-plan", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ question, subject }) });
  },
  async kinfolkChat(question: string, subject: "me" | "someone_else" | "general_research" | "unknown") {
    return request<{ message: string; clarification?: unknown[] }>("/api/kinfolk/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ question, subject }) });
  },
  async transcribeVoice(uri: string, mimeType: string) {
    const form = new FormData();
    form.append("audio", { uri, name: "kinfolk-question.m4a", type: mimeType } as never);
    const response = await fetch(`${API_BASE}/api/kinfolk/voice`, { method: "POST", headers: await headers(), body: form });
    const body = await response.json().catch(() => null);
    if (!response.ok) throw Object.assign(new Error(body?.message ?? "VOICE_TRANSCRIPTION_FAILED"), { code: body?.code, stage: body?.stage });
    return body as { transcript: string };
  }
};
