import { useState } from "react";
import * as Location from "expo-location";
import type { Coordinates } from "../api/mwmApi";

export type LocationState = { status: "idle" | "locating" | "ready" | "denied" | "error"; coordinates?: Coordinates; message?: string };

export function useMemberLocation() {
  const [state, setState] = useState<LocationState>({ status: "idle" });

  async function useMyLocation() {
    setState({ status: "locating", message: "Finding your approximate location…" });
    try {
      const permission = await Location.requestForegroundPermissionsAsync();
      if (permission.status !== "granted") {
        setState({ status: "denied", message: "Location access was not granted. Enter a city or neighborhood instead." });
        return null;
      }
      const enabled = await Location.hasServicesEnabledAsync();
      if (!enabled) {
        setState({ status: "error", message: "Location services are off. Turn them on or enter an area manually." });
        return null;
      }
      const last = await Location.getLastKnownPositionAsync({ maxAge: 120000, requiredAccuracy: 5000 });
      const position = last ?? await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const coordinates = { latitude: position.coords.latitude, longitude: position.coords.longitude };
      setState({ status: "ready", coordinates, message: "Using your approximate location." });
      return coordinates;
    } catch {
      setState({ status: "error", message: "We could not get your location. Enter a city or neighborhood instead." });
      return null;
    }
  }

  return { state, useMyLocation, setManualLocation: (coordinates: Coordinates) => setState({ status: "ready", coordinates, message: "Using your selected area." }) };
}
