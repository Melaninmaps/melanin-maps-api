import { useEffect, useState } from "react";
import { ActivityIndicator, Linking, StyleSheet, Text, View } from "react-native";
import { useLocalSearchParams } from "expo-router";
import { mwmApi } from "../../src/api/mwmApi";

export default function CulturalSiteScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const [site, setSite] = useState<{ id: string; slug: string; title: string; detailUrl: string } | null>(null);
  useEffect(() => { if (id) mwmApi.culturalSite(id).then(setSite).catch(() => setSite(null)); }, [id]);
  if (!site) return <View style={styles.page}><ActivityIndicator color="#D4AF37" /><Text style={styles.text}>Finding this cultural site…</Text></View>;
  return <View style={styles.page}><Text style={styles.title}>{site.title}</Text><Text onPress={() => Linking.openURL(`https://mappingwithmelanin.com${site.detailUrl}`)} style={styles.link}>Open the full cultural-site story</Text></View>;
}
const styles = StyleSheet.create({ page: { flex: 1, gap: 16, padding: 20, backgroundColor: "#FDF9F0" }, title: { color: "#2A0F05", fontFamily: "serif", fontSize: 30, fontWeight: "700" }, text: { color: "#5E4B3E" }, link: { color: "#855913", fontWeight: "800" } });
