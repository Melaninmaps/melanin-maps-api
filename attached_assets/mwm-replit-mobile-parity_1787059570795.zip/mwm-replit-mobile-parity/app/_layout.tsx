import { Stack } from "expo-router";

export default function RootLayout() {
  return <Stack screenOptions={{ headerStyle: { backgroundColor: "#2A0F05" }, headerTintColor: "#FFFDF7", headerTitleStyle: { fontFamily: "serif" }, contentStyle: { backgroundColor: "#FDF9F0" } }}>
    <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
    <Stack.Screen name="cultural-sites/[id]" options={{ title: "Cultural Site" }} />
    <Stack.Screen name="kinfolk" options={{ title: "Kinfolk" }} />
  </Stack>;
}
