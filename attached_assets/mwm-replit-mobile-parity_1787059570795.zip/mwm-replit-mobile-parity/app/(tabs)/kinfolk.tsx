import { useState } from "react";
import { Alert, Button, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { AudioModule, RecordingPresets, setAudioModeAsync, useAudioRecorder, useAudioRecorderState } from "expo-audio";
import { mwmApi } from "../../src/api/mwmApi";

type Subject = "unknown" | "me" | "someone_else" | "general_research";

export default function KinfolkScreen() {
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [subject, setSubject] = useState<Subject>("unknown");
  const [busy, setBusy] = useState(false);
  const recorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const recorderState = useAudioRecorderState(recorder);

  async function send() {
    if (!question.trim()) return;
    setBusy(true); setAnswer("");
    try { const response = await mwmApi.kinfolkChat(question, subject); setAnswer(response.message); }
    catch (error: unknown) {
      const typed = error as { code?: string; message?: string };
      if (typed.code === "KINFOLK_BUSY") setAnswer("Kinfolk is helping a few people right now. Your question is still here—please try again in a moment.");
      else setAnswer(typed.message ?? "Kinfolk could not answer right now. Please try again.");
    } finally { setBusy(false); }
  }

  async function toggleVoice() {
    try {
      if (recorderState.isRecording) {
        await recorder.stop();
        if (!recorder.uri) throw new Error("EMPTY_RECORDING");
        const transcript = await mwmApi.transcribeVoice(recorder.uri, "audio/mp4");
        setQuestion(transcript.transcript);
        return;
      }
      const permission = await AudioModule.requestRecordingPermissionsAsync();
      if (!permission.granted) { Alert.alert("Microphone permission", "Kinfolk needs microphone access to record your question. You can still type it instead."); return; }
      await setAudioModeAsync({ playsInSilentMode: true, allowsRecording: true });
      await recorder.prepareToRecordAsync();
      recorder.record();
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : "VOICE_CAPTURE_FAILED";
      Alert.alert("Voice input could not start", message === "EMPTY_RECORDING" ? "No audio was captured. Please try again or type your question." : "We could not record your question. Please check microphone permission and try again.");
    }
  }

  return <ScrollView contentContainerStyle={styles.page}>
    <Text style={styles.eyebrow}>KIN FOLK</Text><Text style={styles.title}>Ask what matters.</Text><Text style={styles.copy}>Kinfolk researches with diaspora context first, offers personal context only when it helps, and never assumes identity from a question.</Text>
    <TextInput multiline onChangeText={setQuestion} placeholder="Ask Kinfolk a question…" placeholderTextColor="#6D625A" style={styles.input} value={question} />
    <View style={styles.subjects}>{(["me", "someone_else", "general_research"] as const).map((option) => <Button key={option} title={option === "me" ? "For me" : option === "someone_else" ? "Someone else" : "Researching"} onPress={() => setSubject(option)} color={subject === option ? "#B88721" : "#5E4B3E"} />)}</View>
    <Button onPress={toggleVoice} title={recorderState.isRecording ? `Stop recording (${Math.round(recorderState.durationMillis / 1000)}s)` : "Record a question"} />
    <Button disabled={busy} onPress={send} title={busy ? "Kinfolk is thinking…" : "Ask Kinfolk"} />
    {answer ? <View style={styles.answer}><Text style={styles.answerLabel}>Kinfolk</Text><Text style={styles.answerText}>{answer}</Text></View> : null}
  </ScrollView>;
}

const styles = StyleSheet.create({ page: { gap: 14, padding: 20, backgroundColor: "#FDF9F0", flexGrow: 1 }, eyebrow: { color: "#936719", fontWeight: "800", letterSpacing: 2 }, title: { color: "#2A0F05", fontFamily: "serif", fontSize: 32, fontWeight: "700" }, copy: { color: "#5E4B3E", lineHeight: 21 }, input: { backgroundColor: "#FFFDF8", borderColor: "#D9C8AE", borderWidth: 1, borderRadius: 14, color: "#2A0F05", fontSize: 16, minHeight: 150, padding: 14, textAlignVertical: "top" }, subjects: { flexDirection: "row", justifyContent: "space-between" }, answer: { backgroundColor: "#FFFDF8", borderColor: "#E7D7BF", borderRadius: 14, borderWidth: 1, padding: 16 }, answerLabel: { color: "#936719", fontWeight: "800" }, answerText: { color: "#2A0F05", lineHeight: 22, marginTop: 6 } });
