import { useMemo, useState } from "react";
import { ActivityIndicator, Alert, Button, FlatList, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import MapView, { Marker } from "react-native-maps";
import { mwmApi, type Coordinates, type LocalBusiness } from "../../src/api/mwmApi";
import { useMemberLocation } from "../../src/location/useMemberLocation";

export default function DiscoverScreen() {
  const [query, setQuery] = useState("bookstore");
  const [area, setArea] = useState("");
  const [radius, setRadius] = useState(5);
  const [results, setResults] = useState<LocalBusiness[]>([]);
  const [loading, setLoading] = useState(false);
  const { state: location, useMyLocation, setManualLocation } = useMemberLocation();
  const mapRegion = useMemo(() => location.coordinates ? ({ latitude: location.coordinates.latitude, longitude: location.coordinates.longitude, latitudeDelta: 0.08, longitudeDelta: 0.08 }) : undefined, [location.coordinates]);

  async function search(coordinates?: Coordinates) {
    const selected = coordinates ?? location.coordinates;
    if (!selected) { Alert.alert("Choose an area", "Use your location or enter a city or neighborhood first."); return; }
    setLoading(true);
    try {
      const response = await mwmApi.localBusinesses(query, selected, radius);
      setResults(response.results); // The sole source for both list cards and map markers.
    } catch (error) { Alert.alert("Search unavailable", error instanceof Error ? error.message : "Please try again."); }
    finally { setLoading(false); }
  }

  async function locateAndSearch() { const selected = await useMyLocation(); if (selected) await search(selected); }
  async function resolveAreaAndSearch() {
    if (!area.trim()) { Alert.alert("Enter an area", "Enter a city or neighborhood to search there."); return; }
    try { const resolved = await mwmApi.resolveArea(area); setManualLocation(resolved.location); await search(resolved.location); }
    catch { Alert.alert("Area not found", "Try a city or neighborhood name."); }
  }

  return <View style={styles.page}>
    <Text style={styles.title}>Find who you need, where you are.</Text>
    <Text style={styles.copy}>Start close to home. Kinfolk never inserts a distant listing into your local results.</Text>
    <TextInput accessibilityLabel="What are you looking for?" onChangeText={setQuery} placeholder="Bookstore, barber, dentist…" placeholderTextColor="#6D625A" style={styles.input} value={query} />
    <View style={styles.areaRow}><TextInput accessibilityLabel="City or neighborhood" onChangeText={setArea} placeholder="City or neighborhood" placeholderTextColor="#6D625A" style={[styles.input, styles.areaInput]} value={area} /><Button onPress={resolveAreaAndSearch} title="Search area" /></View>
    <Button onPress={locateAndSearch} title={location.status === "locating" ? "Finding your location…" : "Use my location"} />
    {location.message ? <Text style={styles.status}>{location.message}</Text> : null}
    {mapRegion ? <MapView initialRegion={mapRegion} region={mapRegion} style={styles.map}>{results.map((business) => <Marker coordinate={{ latitude: business.latitude, longitude: business.longitude }} key={business.id} title={business.name} />)}</MapView> : null}
    {loading ? <ActivityIndicator color="#B88721" /> : null}
    <FlatList data={results} keyExtractor={(item) => item.id} ListEmptyComponent={location.coordinates && !loading ? <Text style={styles.empty}>No nearby matches yet. You can expand your search only if you choose.</Text> : null} renderItem={({ item }) => <View style={styles.card}><Text style={styles.cardTitle}>{item.name}</Text><Text>{item.city}, {item.state} · {item.distanceMiles.toFixed(1)} mi away</Text></View>} />
    {results.length < 2 && location.coordinates ? <View style={styles.expand}><Text>Need to look farther?</Text><Pressable onPress={() => { setRadius(10); search(); }}><Text style={styles.link}>Search within 10 miles</Text></Pressable><Pressable onPress={() => { setRadius(25); search(); }}><Text style={styles.link}>Search within 25 miles</Text></Pressable></View> : null}
  </View>;
}

const styles = StyleSheet.create({ page: { flex: 1, gap: 12, padding: 20, backgroundColor: "#FDF9F0" }, title: { color: "#2A0F05", fontFamily: "serif", fontSize: 28, fontWeight: "700" }, copy: { color: "#5E4B3E", lineHeight: 20 }, input: { minHeight: 48, borderColor: "#D9C8AE", borderWidth: 1, borderRadius: 12, backgroundColor: "#FFFDF8", color: "#2A0F05", fontSize: 16, paddingHorizontal: 14 }, areaRow: { flexDirection: "row", gap: 8 }, areaInput: { flex: 1 }, status: { color: "#5E4B3E" }, map: { height: 245, borderRadius: 16 }, card: { borderColor: "#E7D7BF", borderWidth: 1, borderRadius: 12, backgroundColor: "#FFFDF8", padding: 14, marginTop: 8 }, cardTitle: { color: "#2A0F05", fontWeight: "700" }, empty: { color: "#5E4B3E", paddingVertical: 16 }, expand: { gap: 8, paddingVertical: 12 }, link: { color: "#855913", fontWeight: "700" } });
