import { Tabs } from "expo-router";
import { BookOpen, Compass, MessageCircle } from "lucide-react-native";

const gold = "#D4AF37";
const brown = "#2A0F05";
export default function TabLayout() {
  return <Tabs screenOptions={{ headerStyle: { backgroundColor: brown }, headerTintColor: "#FFFDF7", tabBarActiveTintColor: gold, tabBarStyle: { backgroundColor: "#FFFDF8", borderTopColor: "#E7D7BF" } }}>
    <Tabs.Screen name="discover" options={{ title: "Discover", tabBarIcon: ({ color }) => <Compass color={color} size={21} /> }} />
    <Tabs.Screen name="library" options={{ title: "Library", tabBarIcon: ({ color }) => <BookOpen color={color} size={21} /> }} />
    <Tabs.Screen name="kinfolk" options={{ title: "Kinfolk", tabBarIcon: ({ color }) => <MessageCircle color={color} size={21} /> }} />
  </Tabs>;
}
