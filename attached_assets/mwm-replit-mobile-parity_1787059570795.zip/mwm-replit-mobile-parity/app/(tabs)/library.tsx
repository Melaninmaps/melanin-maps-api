import { useEffect, useState } from "react";
import { ActivityIndicator, FlatList, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { useRouter } from "expo-router";
import { BookOpen, BriefcaseBusiness, GraduationCap, HeartPulse, Home, Landmark, Store, UsersRound, Wrench } from "lucide-react-native";
import { mwmApi, type LibraryTopic } from "../../src/api/mwmApi";

const ICONS: Record<string, typeof BookOpen> = { housing: Home, education: GraduationCap, "home-services": Wrench, health: HeartPulse, money: Landmark, career: BriefcaseBusiness, business: Store, community: UsersRound };
const START_HERE = new Set(["housing-home", "education-learning", "trades-skills-certifications", "health-wellness", "money-economic-mobility", "careers-professional-life", "business-entrepreneurship", "community-resources-help"]);

export default function LibraryScreen() {
  const [topics, setTopics] = useState<LibraryTopic[]>([]);
  const [query, setQuery] = useState("");
  const router = useRouter();
  useEffect(() => { mwmApi.libraryTopics().then((data) => setTopics(data.topics)).catch(() => setTopics([])); }, []);
  const visible = topics.filter((topic) => START_HERE.has(topic.slug) && `${topic.title} ${topic.summary}`.toLowerCase().includes(query.toLowerCase()));
  return <View style={styles.page}>
    <Text style={styles.eyebrow}>LIVING LIBRARY</Text><Text style={styles.title}>Knowledge that grows with the community.</Text><Text style={styles.copy}>Begin with trusted foundations for the diaspora, then explore source-cited knowledge that grows through Kinfolk and community context.</Text>
    <TextInput accessibilityLabel="Search Library topics" onChangeText={setQuery} placeholder="Search Housing, Education, Trades…" placeholderTextColor="#6D625A" style={styles.input} value={query} />
    <Text style={styles.section}>Start here</Text>
    {!topics.length ? <ActivityIndicator color="#D4AF37" /> : <FlatList data={visible} keyExtractor={(item) => item.id} renderItem={({ item }) => { const Icon = ICONS[item.iconKey] ?? BookOpen; return <Pressable onPress={() => router.push(`/library/${item.slug}`)} style={styles.card}><Icon color="#D4AF37" fill="none" size={28} strokeWidth={1.7} /><View style={styles.cardBody}><Text style={styles.cardTitle}>{item.title}</Text><Text style={styles.cardCopy}>{item.summary}</Text><Text style={styles.cardMeta}>{item.entryCount ? `${item.entryCount} research entries` : "Explore this foundation"}</Text></View></Pressable>; }} />}
  </View>;
}

const styles = StyleSheet.create({ page: { flex: 1, backgroundColor: "#2A0F05", padding: 20 }, eyebrow: { color: "#F0CF63", fontSize: 12, fontWeight: "800", letterSpacing: 2 }, title: { color: "#FFFDF7", fontFamily: "serif", fontSize: 30, fontWeight: "700", marginTop: 8 }, copy: { color: "#F1DFCC", fontSize: 16, lineHeight: 23, marginTop: 10 }, input: { backgroundColor: "#FFFDF8", borderRadius: 12, color: "#2A0F05", fontSize: 16, marginTop: 20, minHeight: 48, paddingHorizontal: 14 }, section: { color: "#FFFDF7", fontFamily: "serif", fontSize: 22, fontWeight: "700", marginVertical: 20 }, card: { alignItems: "flex-start", backgroundColor: "#FFFDF8", borderColor: "#E7D7BF", borderRadius: 14, borderWidth: 1, flexDirection: "row", gap: 12, marginBottom: 10, padding: 15 }, cardBody: { flex: 1 }, cardTitle: { color: "#2A0F05", fontFamily: "serif", fontSize: 18, fontWeight: "700" }, cardCopy: { color: "#5E4B3E", lineHeight: 19, marginTop: 5 }, cardMeta: { color: "#855913", fontWeight: "700", marginTop: 9 } });
