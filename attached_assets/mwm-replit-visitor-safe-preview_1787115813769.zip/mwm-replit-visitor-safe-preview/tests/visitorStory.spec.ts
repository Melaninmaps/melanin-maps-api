import { expect, test } from "vitest";
import { readFileSync } from "node:fs";
const source = readFileSync("client/src/features/preview/VisitorStory.tsx", "utf8");

test("public visitor copy contains no implementation or QA language", () => {
  const visitorCopy = source.match(/const moments = \[([\s\S]*?)\] as const/)?.[1] ?? "";
  expect(visitorCopy).not.toMatch(/QR|stable|route|version|preview|resume|demo|feature|national dump|local discovery|official alerts/i);
});

test("visitor story makes no API calls, asks no question, and has no product-operation controls", () => {
  expect(source).not.toMatch(/fetch\(|api\/|input|textarea|button|onClick|Kinfolk/i);
});

test("visitor story shows five quiet value moments and loops automatically", () => {
  expect(source).toContain("const moments = [");
  expect(source).toContain("setInterval");
  expect((source.match(/visual:/g) ?? []).length).toBe(5);
});
