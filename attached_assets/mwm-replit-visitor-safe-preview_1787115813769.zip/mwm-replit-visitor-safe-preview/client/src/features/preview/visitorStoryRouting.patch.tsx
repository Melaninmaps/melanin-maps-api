import { Route } from "react-router-dom";
import { VisitorStory } from "./VisitorStory";

// Preserve the printed destination. The route is an implementation detail and must never be shown in UI copy.
export const visitorStoryRoute = <Route path="/preview" element={<VisitorStory />} />;
