import assert from "node:assert/strict";

function webSubmitPayload(mediaUrls) {
  return {
    content: "Community post with a picture",
    mediaUrls: mediaUrls.length ? JSON.stringify(mediaUrls) : undefined,
  };
}

function serverStoredMediaUrls(mediaUrls) {
  return mediaUrls?.length ? JSON.stringify(mediaUrls) : null;
}

function webReloadParser(mediaUrls) {
  if (!mediaUrls) return undefined;
  if (Array.isArray(mediaUrls)) return mediaUrls;
  try {
    return JSON.parse(mediaUrls);
  } catch {
    return undefined;
  }
}

function mobileProfileParser(mediaUrls) {
  return mediaUrls ? JSON.parse(mediaUrls) : undefined;
}

const uploadedUrl = "https://cdn.example.test/community/photo.jpg";
const submitted = webSubmitPayload([uploadedUrl]);
assert.equal(typeof submitted.mediaUrls, "string");

const stored = serverStoredMediaUrls(submitted.mediaUrls);
const reloaded = webReloadParser(stored);
assert.equal(typeof reloaded, "string");

let renderFailure = "";
try {
  reloaded.slice(0, 4).map((url) => url);
} catch (error) {
  renderFailure = error instanceof Error ? error.message : String(error);
}
assert.match(renderFailure, /map is not a function/);

let profileFailure = "";
try {
  mobileProfileParser([uploadedUrl]);
} catch (error) {
  profileFailure = error instanceof Error ? error.message : String(error);
}
assert.ok(profileFailure.length > 0);

console.log(JSON.stringify({
  web_media_contract: {
    uploaded_url: uploadedUrl,
    submitted_type: typeof submitted.mediaUrls,
    stored_value: stored,
    reload_type: typeof reloaded,
    render_failure: renderFailure,
  },
  mobile_profile_parser: {
    input_shape: "array",
    failure: profileFailure,
  },
}, null, 2));
