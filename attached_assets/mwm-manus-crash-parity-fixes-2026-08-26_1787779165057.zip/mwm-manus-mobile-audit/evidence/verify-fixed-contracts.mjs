import assert from "node:assert/strict";

function normalizeMediaUrls(value) {
  let current = value;
  for (let depth = 0; depth < 3; depth += 1) {
    if (Array.isArray(current)) {
      const urls = [...new Set(current.filter((item) => typeof item === "string").map((item) => item.trim()).filter(Boolean))].slice(0, 5);
      return urls.length > 0 ? urls : undefined;
    }
    if (typeof current !== "string" || !current.trim()) return undefined;
    try {
      current = JSON.parse(current);
    } catch {
      return undefined;
    }
  }
  return undefined;
}

function normalizeExternalHttpUrl(value) {
  if (typeof value !== "string" || !value.trim()) return null;
  const trimmed = value.trim();
  const candidate = /^[a-z][a-z0-9+.-]*:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  try {
    const url = new URL(candidate);
    return url.protocol === "http:" || url.protocol === "https:" ? url.toString() : null;
  } catch {
    return null;
  }
}

const uploadedUrl = "https://cdn.example.test/community/photo.jpg";
const arrayShape = [uploadedUrl];
const stringShape = JSON.stringify(arrayShape);
const doubleEncodedShape = JSON.stringify(stringShape);

assert.deepEqual(normalizeMediaUrls(arrayShape), arrayShape);
assert.deepEqual(normalizeMediaUrls(stringShape), arrayShape);
assert.deepEqual(normalizeMediaUrls(doubleEncodedShape), arrayShape);
assert.equal(normalizeMediaUrls("not-json"), undefined);
assert.equal(normalizeExternalHttpUrl("www.nps.gov/malu"), "https://www.nps.gov/malu");
assert.equal(normalizeExternalHttpUrl("javascript:alert(1)"), null);

const submittedBody = { content: "Community post with a picture", mediaUrls: arrayShape };
assert.ok(Array.isArray(submittedBody.mediaUrls));

console.log(JSON.stringify({
  media_shapes: {
    array: normalizeMediaUrls(arrayShape),
    json_string: normalizeMediaUrls(stringShape),
    double_encoded_legacy: normalizeMediaUrls(doubleEncodedShape),
    malformed: normalizeMediaUrls("not-json") ?? null,
  },
  external_links: {
    scheme_less: normalizeExternalHttpUrl("www.nps.gov/malu"),
    unsafe_protocol: normalizeExternalHttpUrl("javascript:alert(1)"),
  },
  submitted_media_type: Array.isArray(submittedBody.mediaUrls) ? "array" : typeof submittedBody.mediaUrls,
}, null, 2));
