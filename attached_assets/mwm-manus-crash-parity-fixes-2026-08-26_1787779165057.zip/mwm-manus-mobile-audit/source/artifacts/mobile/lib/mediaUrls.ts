export function normalizeMediaUrls(value: unknown): string[] | undefined {
  let current = value;

  for (let depth = 0; depth < 3; depth += 1) {
    if (Array.isArray(current)) {
      const unique = new Set<string>();
      for (const item of current) {
        if (typeof item !== "string") continue;
        const url = item.trim();
        if (url) unique.add(url);
      }
      const urls = Array.from(unique).slice(0, 5);
      return urls.length > 0 ? urls : undefined;
    }

    if (typeof current !== "string" || !current.trim()) return undefined;

    try {
      current = JSON.parse(current);
    } catch {
      return undefined;
    }
  }

  return undefined;
}
