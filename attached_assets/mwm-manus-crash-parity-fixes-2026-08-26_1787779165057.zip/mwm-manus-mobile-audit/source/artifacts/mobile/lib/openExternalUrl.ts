import { Alert, Linking } from "react-native";
import { getApiBase } from "@/lib/api";

const WEB_PROTOCOLS = new Set(["http:", "https:"]);
const DEVICE_PROTOCOLS = new Set(["http:", "https:", "maps:", "geo:", "tel:", "sms:"]);

export type OpenExternalUrlOptions = {
  kind?: "web" | "device";
  unavailableTitle?: string;
  unavailableMessage?: string;
};

export function normalizeExternalUrl(value: unknown, kind: "web" | "device" = "web"): string | null {
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  if (!trimmed) return null;

  const hasScheme = /^[a-z][a-z0-9+.-]*:/i.test(trimmed);
  const candidate = trimmed.startsWith("/")
    ? `${getApiBase()}${trimmed}`
    : !hasScheme && kind === "web"
      ? `https://${trimmed}`
      : trimmed;

  try {
    const parsed = new URL(candidate);
    const allowed = kind === "device" ? DEVICE_PROTOCOLS : WEB_PROTOCOLS;
    return allowed.has(parsed.protocol.toLowerCase()) ? parsed.toString() : null;
  } catch {
    return null;
  }
}

export async function openExternalUrl(
  value: unknown,
  options: OpenExternalUrlOptions = {},
): Promise<boolean> {
  const {
    kind = "web",
    unavailableTitle = "Link unavailable",
    unavailableMessage = "This link is invalid or cannot be opened on this device.",
  } = options;
  const url = normalizeExternalUrl(value, kind);

  if (!url) {
    Alert.alert(unavailableTitle, unavailableMessage);
    return false;
  }

  try {
    const supported = await Linking.canOpenURL(url);
    if (!supported) {
      Alert.alert(unavailableTitle, unavailableMessage);
      return false;
    }
    await Linking.openURL(url);
    return true;
  } catch {
    Alert.alert(unavailableTitle, unavailableMessage);
    return false;
  }
}
