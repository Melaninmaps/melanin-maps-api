# Mapping With Melanin Fix Delivery

This delivery contains the patched source snapshot, a Replit-ready unified patch, safe application and validation scripts, deterministic reproduction evidence, and the final crash/parity audit report.

| Start here | Path |
|---|---|
| Final findings and release gates | `report/MWM_CRASH_PARITY_AUDIT_AND_FIX_REPORT.md` |
| Replit commands | `replit/README.md` |
| Replit patch | `replit/mwm-crash-parity-fixes.patch` |
| Post-fix status | `validation/POST_FIX_STATUS.md` |
| Delivery integrity | `DELIVERY_SHA256SUMS.txt` |

No production deployment, EAS build, build-number change, App Store submission, Google Play submission, database migration, or production-data modification was performed.
