# Replit Crash and Feature-Parity Fix Bundle

This folder contains an **idempotent source patch**, an application script, and a validation runner for the Mapping With Melanin monorepo. The patch changes only the audited website, API, and Expo files. It does not deploy, run an EAS build, change build numbers, submit to either app store, or modify production data.

| File | Purpose |
|---|---|
| `mwm-crash-parity-fixes.patch` | Unified patch for the website, API server, and Expo app. |
| `apply-fixes.sh` | Verifies the Replit workspace revision, creates a timestamped backup, and applies the patch once. |
| `validate-source-contracts.mjs` | Deterministic checks for media, cultural-site, external-link, and crash-prevention contracts. |
| `validate-fixes.sh` | Runs the source checks plus existing mobile audit, tests, typecheck, Expo config, and iOS/Android pre-build gates. |

## Apply in Replit

Upload this `replit` folder to the monorepo or extract the full delivery archive at the workspace root. From the Replit Shell, run:

```bash
chmod +x replit/apply-fixes.sh replit/validate-fixes.sh
./replit/apply-fixes.sh "$PWD"
```

The script first runs `git apply --check`. If the patch does not match, it exits without changing files. If the patch is already present, it exits successfully without applying it a second time. Before a first application, it copies existing touched files into `.manus-backups/`.

## Validate

Run the complete non-deployment validation suite:

```bash
./replit/validate-fixes.sh "$PWD"
```

Results are written under `validation/manus-crash-parity-<UTC timestamp>/`. Review `summary.md` first, then open the individual logs for any failed command.

## Required manual journeys

After automated checks pass, use the normal authenticated preview and native simulator/device flows to confirm: website image upload → submit → visible media → reload; mobile image upload → selected preview → submit → reload; an intentionally failed second upload while the first completed attachment remains selected; a cultural-site detail such as the MLK House route; official and support links with and without a URL scheme; location permission denied; GPS timeout; and cold-launch map readiness.

## Rollback

The apply script prints the exact backup directory it created. Copy files from that directory back to their original locations to restore the pre-patch source. New helper files can be removed manually if a full rollback is required:

```bash
rm -f artifacts/mobile/lib/mediaUrls.ts artifacts/mobile/lib/openExternalUrl.ts
```
