#!/usr/bin/env bash
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKSPACE_ROOT="${1:-$(pwd)}"
RUN_ID="$(date -u +%Y%m%dT%H%M%SZ)"
OUTPUT_DIR="${2:-$WORKSPACE_ROOT/validation/manus-crash-parity-$RUN_ID}"

mkdir -p "$OUTPUT_DIR"
cd "$WORKSPACE_ROOT"

names=()
codes=()
logs=()

run_check() {
  local name="$1"
  shift
  local slug
  slug="$(printf '%s' "$name" | tr '[:upper:] ' '[:lower:]-' | tr -cd 'a-z0-9_-')"
  local log="$OUTPUT_DIR/$slug.log"

  printf '\n== %s ==\n' "$name"
  "$@" >"$log" 2>&1
  local code=$?

  names+=("$name")
  codes+=("$code")
  logs+=("$(basename "$log")")

  if [[ $code -eq 0 ]]; then
    printf 'PASS: %s\n' "$name"
  else
    printf 'FAIL: %s (exit %s; see %s)\n' "$name" "$code" "$log"
  fi
}

run_check "Source contracts" node "$SCRIPT_DIR/validate-source-contracts.mjs" "$WORKSPACE_ROOT"

if command -v pnpm >/dev/null 2>&1; then
  run_check "Mobile audit" bash -lc 'cd artifacts/mobile && pnpm run audit'
  run_check "Mobile tests" bash -lc 'cd artifacts/mobile && pnpm test -- --run'
  run_check "Mobile typecheck" bash -lc 'cd artifacts/mobile && pnpm run typecheck'
  run_check "Expo config" bash -lc 'cd artifacts/mobile && pnpm exec expo config --json'
  run_check "iOS pre-build gate" bash -lc 'cd artifacts/mobile && node scripts/pre-build-check.js ios'
  run_check "Android pre-build gate" bash -lc 'cd artifacts/mobile && node scripts/pre-build-check.js android'
else
  printf 'pnpm is unavailable; package-level checks were not run.\n' | tee "$OUTPUT_DIR/pnpm-unavailable.log"
  names+=("Package-level checks")
  codes+=("127")
  logs+=("pnpm-unavailable.log")
fi

summary="$OUTPUT_DIR/summary.md"
{
  printf '# MWM Crash and Parity Validation\n\n'
  printf '**Run:** %s  \n' "$RUN_ID"
  printf '**Workspace:** `%s`\n\n' "$WORKSPACE_ROOT"
  printf '| Check | Result | Exit | Log |\n'
  printf '|---|---:|---:|---|\n'
  failures=0
  for i in "${!names[@]}"; do
    if [[ "${codes[$i]}" -eq 0 ]]; then
      result="PASS"
    else
      result="FAIL"
      failures=$((failures + 1))
    fi
    printf '| %s | %s | %s | `%s` |\n' "${names[$i]}" "$result" "${codes[$i]}" "${logs[$i]}"
  done
  printf '\nNo production deployment, EAS build, App Store submission, or Google Play submission was performed.\n'
} >"$summary"

printf '\nValidation summary: %s\n' "$summary"
printf 'Failures: %s\n' "$failures"
exit "$failures"
