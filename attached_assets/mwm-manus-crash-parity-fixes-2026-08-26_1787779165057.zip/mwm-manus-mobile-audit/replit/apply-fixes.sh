#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKSPACE_ROOT="${1:-$(pwd)}"
PATCH_FILE="$SCRIPT_DIR/mwm-crash-parity-fixes.patch"

cd "$WORKSPACE_ROOT"

required_files=(
  "artifacts/mobile/package.json"
  "artifacts/mobile/app/(tabs)/community.tsx"
  "artifacts/web/src/pages/community.tsx"
  "artifacts/api-server/src/routes/community.ts"
)

for path in "${required_files[@]}"; do
  if [[ ! -f "$path" ]]; then
    printf 'ERROR: expected Replit workspace file is missing: %s\n' "$path" >&2
    printf 'Run this script from the monorepo root, or pass that root as the first argument.\n' >&2
    exit 2
  fi
done

if [[ ! -f "$PATCH_FILE" ]]; then
  printf 'ERROR: patch file not found: %s\n' "$PATCH_FILE" >&2
  exit 2
fi

if git apply --reverse --check "$PATCH_FILE" >/dev/null 2>&1; then
  printf 'Fixes are already applied. No files changed.\n'
  exit 0
fi

if ! git apply --check "$PATCH_FILE"; then
  printf 'ERROR: patch does not match this workspace revision. No files changed.\n' >&2
  printf 'Use the included source files as a manual comparison, then rerun validation.\n' >&2
  exit 3
fi

backup_root=".manus-backups/mwm-crash-parity-$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$backup_root"

mapfile -t touched_files < <(
  awk '/^--- a\// { sub(/^--- a\//, ""); print } /^\+\+\+ b\// { sub(/^\+\+\+ b\//, ""); print }' "$PATCH_FILE" \
    | grep -v '^/dev/null$' \
    | sort -u
)

for path in "${touched_files[@]}"; do
  if [[ -f "$path" ]]; then
    mkdir -p "$backup_root/$(dirname "$path")"
    cp -p "$path" "$backup_root/$path"
  fi
done

git apply "$PATCH_FILE"
printf 'Applied crash/parity fixes. Backup: %s\n' "$backup_root"
printf 'Next: %s/validate-fixes.sh %s\n' "$SCRIPT_DIR" "$WORKSPACE_ROOT"
