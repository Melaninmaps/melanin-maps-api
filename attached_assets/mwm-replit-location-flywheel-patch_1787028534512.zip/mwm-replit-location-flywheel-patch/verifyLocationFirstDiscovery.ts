import assert from "node:assert/strict";
import { executeLocationFirstDiscovery } from "./server/discovery/locationFirstDiscovery";

const signals: string[] = [];
const query = {
  surface: "map" as const,
  location: { city: "Charlotte", stateCode: "NC", neighborhood: null, latitude: null, longitude: null, source: "explicit" as const },
  locationMode: "exact" as const,
  radiusMiles: null,
  filters: { recordTypes: ["business" as const], category: null, specialty: "barber", ownership: [], tagSlugs: [], dateRange: null },
  searchText: null,
};

async function main() {
  const exactRepository = {
    async findExact() {
      return [{
        id: "barber-1", recordType: "business" as const, name: "Charlotte Barber", category: "Beauty", specialty: "barber",
        city: "Charlotte", stateCode: "NC", neighborhood: "Uptown", latitude: 35.22, longitude: -80.84, distanceMiles: 1.2,
        detailUrl: "/businesses/barber-1", isVerified: true, contextTags: [],
      }];
    },
    async findNearestAvailableLocation() { return { city: "Atlanta", stateCode: "GA", distanceMiles: 245 }; },
    async recordCoverageGap() { signals.push("gap"); },
    async recordFlywheelSignal(input: { action: string }) { signals.push(input.action); },
  };

  const exact = await executeLocationFirstDiscovery(query, exactRepository);
  assert.equal(exact.records.length, 1);
  assert.equal(exact.records[0]?.city, "Charlotte");
  assert.equal(exact.coverageGap, null);

  const emptyRepository = { ...exactRepository, async findExact() { return []; } };
  const empty = await executeLocationFirstDiscovery(query, emptyRepository);
  assert.equal(empty.records.length, 0);
  assert.equal(empty.coverageGap?.city, "Charlotte");
  assert.ok(empty.suggestedActions.includes("show_nearest_city"));
  assert.ok(signals.includes("gap"));

  const noLocation = await executeLocationFirstDiscovery({
    ...query,
    location: { city: null, stateCode: null, neighborhood: null, latitude: null, longitude: null, source: "none" as const },
  }, exactRepository);
  assert.equal(noLocation.requiresLocation, true);
  assert.equal(noLocation.records.length, 0);
  console.log("Location-first discovery smoke test passed.");
}

void main();
