import { useEffect, useMemo, useState } from "react";
import { useDiscoveryLocation } from "../discovery/LocationContext";
import type { DiscoveryRecord, LocationFirstResponse } from "../../../../shared/discoveryContracts";

const EXPLORE_LENSES = ["Heritage & History", "Arts & Culture", "Neighborhoods", "HBCUs", "Living Culture", "Family", "Nightlife", "Faith & Community"];

export function LocationFirstExplore() {
  const { location } = useDiscoveryLocation();
  const [lens, setLens] = useState<string | null>(null);
  const [response, setResponse] = useState<LocationFirstResponse | null>(null);
  const query = useMemo(() => ({
    surface: "explore" as const,
    location,
    locationMode: "exact" as const,
    radiusMiles: null,
    filters: {
      recordTypes: ["cultural_site" as const, "community_place" as const, "event" as const],
      category: lens,
      specialty: null,
      ownership: [],
      tagSlugs: [],
      dateRange: null,
    },
    searchText: null,
  }), [location, lens]);

  useEffect(() => {
    const controller = new AbortController();
    fetch("/api/discovery/query", { method: "POST", credentials: "include", signal: controller.signal, headers: { "Content-Type": "application/json" }, body: JSON.stringify(query) })
      .then((result) => result.json()).then(setResponse)
      .catch((error) => error.name !== "AbortError" && console.error("Explore discovery failed", error));
    return () => controller.abort();
  }, [query]);

  const label = [location.neighborhood, location.city, location.stateCode].filter(Boolean).join(", ");
  return <main className="bg-[#FBF6EC] pb-16"><section className="bg-[#2B1507] px-6 py-16 text-center text-white"><p className="text-xs font-bold uppercase tracking-[0.16em] text-[#E5B94B]">Discover with purpose</p><h1 className="mt-3 font-serif text-5xl font-bold">What should you experience here?</h1><p className="mx-auto mt-4 max-w-2xl leading-7 text-white/75">History, culture, neighborhoods, places that matter, and timely local experiences. Businesses appear as contextual stops, not a duplicate directory.</p></section><section className="mx-auto max-w-6xl px-6 py-8"><p className="font-semibold text-[#2B1507]">{label || "Choose an area to explore"}</p><div className="mt-4 flex flex-wrap gap-2">{EXPLORE_LENSES.map((item) => <button aria-pressed={lens === item} className={`rounded-full px-4 py-2 text-sm ${lens === item ? "bg-[#3A1F0E] text-white" : "border border-[#3A1F0E]/15 bg-white text-[#3A1F0E]"}`} key={item} onClick={() => setLens(lens === item ? null : item)} type="button">{item}</button>)}</div>{response?.requiresLocation ? <EmptyExplore title="Choose a city or neighborhood" body="Explore begins with the place you want to understand. Select an area to find local heritage, culture, and community experiences." /> : null}{response?.coverageGap ? <EmptyExplore title="We are still building this local cultural map" body="You can expand to a nearby city, browse a guide, or help the community add a place that matters here." /> : null}<section className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{response?.records.map((record) => <ExploreCard key={`${record.recordType}-${record.id}`} record={record} />)}</section></section></main>;
}

function ExploreCard({ record }: { record: DiscoveryRecord }) { return <a className="rounded-2xl border border-[#3A1F0E]/10 bg-white p-5 shadow-sm hover:border-[#CA922B]/60" href={record.detailUrl}><p className="text-xs font-bold uppercase tracking-[0.14em] text-[#8D5C17]">{record.recordType.replace("_", " ")}</p><h2 className="mt-2 text-xl font-bold text-[#2B1507]">{record.name}</h2><p className="mt-2 text-sm text-[#3A1F0E]/70">{[record.category, record.neighborhood, record.city].filter(Boolean).join(" · ")}</p></a>; }
function EmptyExplore({ title, body }: { title: string; body: string }) { return <section className="mt-8 rounded-2xl border border-[#CA922B]/35 bg-white p-6"><h2 className="font-serif text-2xl font-bold text-[#2B1507]">{title}</h2><p className="mt-2 max-w-2xl leading-7 text-[#3A1F0E]/70">{body}</p><div className="mt-4 flex flex-wrap gap-3"><button className="rounded-full border border-[#CA922B] px-4 py-2 font-semibold text-[#8D5C17]" type="button">Explore a nearby city</button><a className="rounded-full border border-[#CA922B] px-4 py-2 font-semibold text-[#8D5C17]" href="/guides">Browse guides</a></div></section>; }
