import { useEffect, useMemo, useState } from "react";
import { useDiscoveryLocation } from "../discovery/LocationContext";
import type { CanonicalRecordType, DiscoveryRecord, LocationFirstResponse } from "../../../../shared/discoveryContracts";

type Layer = { id: CanonicalRecordType; label: string };
const LAYERS: Layer[] = [
  { id: "business", label: "Businesses" },
  { id: "cultural_site", label: "Cultural Sites" },
  { id: "event", label: "Events" },
  { id: "community_place", label: "Community Places" },
];

function mapCategoryToRecordTypes(layer: CanonicalRecordType): CanonicalRecordType[] {
  return [layer];
}

export function LocationFirstMap({ renderMap }: { renderMap: (records: DiscoveryRecord[], selectedLayer: CanonicalRecordType) => React.ReactNode }) {
  const { location } = useDiscoveryLocation();
  const [selectedLayer, setSelectedLayer] = useState<CanonicalRecordType>("business");
  const [specialty, setSpecialty] = useState<string | null>(null);
  const [response, setResponse] = useState<LocationFirstResponse | null>(null);
  const [loading, setLoading] = useState(false);

  const query = useMemo(() => ({
    surface: "map" as const,
    location,
    locationMode: "exact" as const,
    radiusMiles: null,
    filters: {
      recordTypes: mapCategoryToRecordTypes(selectedLayer),
      category: null,
      specialty,
      ownership: [],
      tagSlugs: [],
      dateRange: null,
    },
    searchText: null,
  }), [location, selectedLayer, specialty]);

  useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    fetch("/api/discovery/query", {
      method: "POST",
      credentials: "include",
      signal: controller.signal,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(query),
    })
      .then((result) => result.json())
      .then(setResponse)
      .catch((error) => {
        if (error.name !== "AbortError") console.error("Map discovery failed", error);
      })
      .finally(() => setLoading(false));
    return () => controller.abort();
  }, [query]);

  const records = response?.records ?? [];
  const locationLabel = [location.neighborhood, location.city, location.stateCode].filter(Boolean).join(", ");

  return (
    <section className="grid min-h-[680px] grid-cols-[340px_1fr] bg-[#FBF6EC]">
      <aside className="border-r border-[#3A1F0E]/10 bg-white">
        <header className="border-b border-[#3A1F0E]/10 p-5">
          <p className="text-xs font-bold uppercase tracking-[0.16em] text-[#8D5C17]">Around you</p>
          <h1 className="mt-1 font-serif text-2xl font-bold text-[#2B1507]">{locationLabel || "Choose an area"}</h1>
          <p className="mt-2 text-sm leading-6 text-[#3A1F0E]/70">The list and map pins always show the same selected local inventory.</p>
        </header>
        <nav className="flex flex-wrap gap-2 p-4" aria-label="Map layers">
          {LAYERS.map((layer) => (
            <button
              aria-pressed={selectedLayer === layer.id}
              className={`rounded-full px-3 py-2 text-sm font-semibold ${selectedLayer === layer.id ? "bg-[#3A1F0E] text-white" : "border border-[#3A1F0E]/15 text-[#3A1F0E]"}`}
              key={layer.id}
              onClick={() => { setSelectedLayer(layer.id); setSpecialty(null); }}
              type="button"
            >
              {layer.label}
            </button>
          ))}
        </nav>
        {selectedLayer === "business" ? (
          <div className="flex flex-wrap gap-2 border-b border-[#3A1F0E]/10 px-4 pb-4">
            <button aria-pressed={specialty === "barber"} className={`rounded-full px-3 py-1.5 text-sm ${specialty === "barber" ? "bg-[#CA922B]/20 text-[#8D5C17]" : "border border-[#CA922B]/35 text-[#8D5C17]"}`} onClick={() => setSpecialty(specialty === "barber" ? null : "barber")} type="button">Barbers</button>
            <button aria-pressed={specialty === "natural-hair-specialist"} className={`rounded-full px-3 py-1.5 text-sm ${specialty === "natural-hair-specialist" ? "bg-[#CA922B]/20 text-[#8D5C17]" : "border border-[#CA922B]/35 text-[#8D5C17]"}`} onClick={() => setSpecialty(specialty === "natural-hair-specialist" ? null : "natural-hair-specialist")} type="button">Natural hair</button>
          </div>
        ) : null}

        <div className="max-h-[520px] overflow-y-auto" aria-live="polite">
          {loading ? <p className="p-5 text-sm text-[#3A1F0E]/60">Updating the local map…</p> : null}
          {response?.requiresLocation ? <p className="p-5 text-sm leading-6 text-[#3A1F0E]/70">Choose a city or neighborhood to see what Mapping with Melanin has nearby. Kinfolk will not substitute a nationwide list.</p> : null}
          {!loading && !response?.requiresLocation && records.map((record) => <MapResultRow key={`${record.recordType}-${record.id}`} record={record} />)}
          {!loading && response?.coverageGap ? <CoverageGapPanel response={response} /> : null}
          {!loading && response && !response.requiresLocation && !response.coverageGap && !records.length ? <p className="p-5 text-sm text-[#3A1F0E]/70">No matching local places are available yet.</p> : null}
        </div>
      </aside>
      <div className="relative">{renderMap(records, selectedLayer)}</div>
    </section>
  );
}

function MapResultRow({ record }: { record: DiscoveryRecord }) {
  return (
    <a className="block border-b border-[#3A1F0E]/10 p-5 hover:bg-[#CA922B]/[0.06]" href={record.detailUrl}>
      <p className="text-xs font-bold uppercase tracking-[0.12em] text-[#8D5C17]">{record.recordType.replace("_", " ")}</p>
      <h2 className="mt-1 font-semibold text-[#2B1507]">{record.name}</h2>
      <p className="mt-1 text-sm text-[#3A1F0E]/70">{[record.category, record.neighborhood, record.city].filter(Boolean).join(" · ")}</p>
    </a>
  );
}

function CoverageGapPanel({ response }: { response: LocationFirstResponse }) {
  const nearest = response.nearestAvailableLocation;
  return (
    <section className="m-4 rounded-xl border border-[#CA922B]/35 bg-[#CA922B]/[0.07] p-4">
      <p className="font-semibold text-[#2B1507]">Nothing matching this selection is listed nearby yet.</p>
      <p className="mt-2 text-sm leading-6 text-[#3A1F0E]/70">Mapping with Melanin recorded this local need so the community can grow coverage without pretending a distant listing is local.</p>
      <div className="mt-3 flex flex-wrap gap-2">
        {nearest ? <button className="rounded-full border border-[#CA922B] px-3 py-1.5 text-sm font-semibold text-[#8D5C17]" type="button">Show {nearest.city} options</button> : null}
        <button className="rounded-full border border-[#CA922B] px-3 py-1.5 text-sm font-semibold text-[#8D5C17]" type="button">Expand my search</button>
        <a className="rounded-full border border-[#CA922B] px-3 py-1.5 text-sm font-semibold text-[#8D5C17]" href="/businesses/submit">Add a listing</a>
      </div>
    </section>
  );
}
