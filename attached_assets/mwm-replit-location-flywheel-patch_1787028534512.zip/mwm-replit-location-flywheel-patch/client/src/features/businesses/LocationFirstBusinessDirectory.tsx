import { useEffect, useMemo, useState } from "react";
import { useDiscoveryLocation } from "../discovery/LocationContext";
import type { DiscoveryRecord, LocationFirstResponse } from "../../../../shared/discoveryContracts";

const CATEGORIES = ["Food & Drink", "Beauty & Personal Care", "Health & Wellness", "Professional Services", "Arts & Culture"];
const SPECIALTIES = [
  { slug: "barber", label: "Barbers" },
  { slug: "natural-hair-specialist", label: "Natural hair" },
  { slug: "dermatologist", label: "Dermatologists" },
  { slug: "obgyn", label: "OB-GYNs" },
  { slug: "attorney", label: "Attorneys" },
];

export function LocationFirstBusinessDirectory() {
  const { location, requestDeviceLocation } = useDiscoveryLocation();
  const [category, setCategory] = useState<string | null>(null);
  const [specialty, setSpecialty] = useState<string | null>(null);
  const [ownership, setOwnership] = useState<string[]>([]);
  const [searchText, setSearchText] = useState("");
  const [response, setResponse] = useState<LocationFirstResponse | null>(null);

  const query = useMemo(() => ({
    surface: "businesses" as const,
    location,
    locationMode: "exact" as const,
    radiusMiles: null,
    filters: { recordTypes: ["business" as const], category, specialty, ownership, tagSlugs: [], dateRange: null },
    searchText: searchText.trim() || null,
  }), [location, category, specialty, ownership, searchText]);

  useEffect(() => {
    const controller = new AbortController();
    fetch("/api/discovery/query", {
      method: "POST",
      credentials: "include",
      signal: controller.signal,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(query),
    })
      .then((result) => result.json())
      .then(setResponse)
      .catch((error) => {
        if (error.name !== "AbortError") console.error("Business discovery failed", error);
      });
    return () => controller.abort();
  }, [query]);

  const locationLabel = [location.neighborhood, location.city, location.stateCode].filter(Boolean).join(", ");
  const countLabel = response?.requiresLocation ? "Choose your area" : `${response?.records.length ?? 0} verified businesses in ${locationLabel || "your area"}`;

  function toggleOwnership(value: string) {
    setOwnership((current) => current.includes(value) ? current.filter((item) => item !== value) : [...current, value]);
  }

  return (
    <main className="bg-[#FBF6EC] pb-16">
      <section className="bg-[#2B1507] px-6 py-14 text-center text-white">
        <p className="text-xs font-bold uppercase tracking-[0.16em] text-[#E5B94B]">Community business and service finder</p>
        <h1 className="mt-3 font-serif text-5xl font-bold">Find who you need, where you are.</h1>
        <p className="mx-auto mt-4 max-w-2xl leading-7 text-white/75">Find businesses, professionals, and organizations with the cultural context that matters to your community.</p>
      </section>
      <section className="mx-auto max-w-6xl px-6 py-8">
        <div className="flex flex-wrap items-center gap-3">
          <input className="min-w-[280px] flex-1 rounded-full border border-[#3A1F0E]/15 bg-white px-5 py-3" onChange={(event) => setSearchText(event.target.value)} placeholder="Search barber, OB-GYN, tax attorney, restaurant…" value={searchText} />
          <button className="rounded-full border border-[#CA922B] bg-white px-4 py-3 font-semibold text-[#8D5C17]" onClick={() => void requestDeviceLocation()} type="button">Use my location</button>
        </div>
        <p className="mt-4 text-sm font-semibold text-[#2B1507]">{countLabel}</p>
        <p className="mt-1 text-sm text-[#3A1F0E]/65">Location first. Mapping with Melanin does not substitute a national directory dump for your local result.</p>

        <FilterRow label="Category" values={CATEGORIES} selected={category ? [category] : []} onToggle={(value) => setCategory(category === value ? null : value)} />
        <FilterRow label="Specialty" values={SPECIALTIES.map((item) => item.label)} selected={specialty ? [SPECIALTIES.find((item) => item.slug === specialty)?.label ?? specialty] : []} onToggle={(label) => {
          const value = SPECIALTIES.find((item) => item.label === label)?.slug ?? null;
          setSpecialty(value === specialty ? null : value);
        }} />
        <FilterRow label="Ownership" values={["Black-Owned", "Women-Owned", "LGBTQIA+-Owned", "Latino-Owned", "Indigenous-Owned", "Veteran-Owned"]} selected={ownership} onToggle={toggleOwnership} />

        {response?.requiresLocation ? <LocationNeededState /> : null}
        {response?.coverageGap ? <DirectoryGapState response={response} /> : null}
        <section className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {response?.records.map((record) => <BusinessCard key={record.id} record={record} />)}
        </section>
      </section>
    </main>
  );
}

function FilterRow({ label, values, selected, onToggle }: { label: string; values: string[]; selected: string[]; onToggle(value: string): void }) {
  return <section className="mt-6"><p className="text-xs font-bold uppercase tracking-[0.15em] text-[#8D5C17]">{label}</p><div className="mt-2 flex flex-wrap gap-2">{values.map((value) => <button aria-pressed={selected.includes(value)} className={`rounded-full px-4 py-2 text-sm ${selected.includes(value) ? "bg-[#3A1F0E] text-white" : "border border-[#3A1F0E]/15 bg-white text-[#3A1F0E]"}`} key={value} onClick={() => onToggle(value)} type="button">{value}</button>)}</div></section>;
}

function BusinessCard({ record }: { record: DiscoveryRecord }) {
  return <a className="rounded-2xl border border-[#3A1F0E]/10 bg-white p-5 shadow-sm transition hover:border-[#CA922B]/60" href={record.detailUrl}><p className="text-xs font-bold uppercase tracking-[0.14em] text-[#8D5C17]">{record.category || "Business"}</p><h2 className="mt-2 text-lg font-bold text-[#2B1507]">{record.name}</h2><p className="mt-2 text-sm text-[#3A1F0E]/70">{[record.specialty, record.neighborhood, record.city].filter(Boolean).join(" · ")}</p>{record.contextTags.length ? <p className="mt-3 text-sm text-[#8D5C17]">{record.contextTags.map((tag) => tag.label).join(" · ")}</p> : null}</a>;
}

function LocationNeededState() {
  return <section className="mt-8 rounded-2xl border border-[#CA922B]/35 bg-white p-6"><h2 className="font-serif text-2xl font-bold text-[#2B1507]">Choose an area to begin</h2><p className="mt-2 max-w-xl leading-7 text-[#3A1F0E]/70">Tell us a city or use your location to see nearby businesses and services. We will not show you a nationwide list and label it local.</p></section>;
}

function DirectoryGapState({ response }: { response: LocationFirstResponse }) {
  return <section className="mt-8 rounded-2xl border border-[#CA922B]/35 bg-[#CA922B]/[0.07] p-6"><h2 className="font-serif text-2xl font-bold text-[#2B1507]">We do not have that nearby yet.</h2><p className="mt-2 leading-7 text-[#3A1F0E]/70">This local need has been recorded so we can improve coverage. You can choose to expand your search, view the nearest available city, or help add a listing.</p><div className="mt-4 flex flex-wrap gap-3">{response.nearestAvailableLocation ? <button className="rounded-full border border-[#CA922B] px-4 py-2 font-semibold text-[#8D5C17]" type="button">Show {response.nearestAvailableLocation.city}</button> : null}<button className="rounded-full border border-[#CA922B] px-4 py-2 font-semibold text-[#8D5C17]" type="button">Expand search</button><a className="rounded-full border border-[#CA922B] px-4 py-2 font-semibold text-[#8D5C17]" href="/businesses/submit">Add a business</a></div></section>;
}
