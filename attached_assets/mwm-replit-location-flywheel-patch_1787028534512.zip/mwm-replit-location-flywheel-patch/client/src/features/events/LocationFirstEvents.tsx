import { useEffect, useMemo, useState } from "react";
import { useDiscoveryLocation } from "../discovery/LocationContext";
import type { DiscoveryRecord, LocationFirstResponse } from "../../../../shared/discoveryContracts";

const TIME_FILTERS = [
  { id: "today", label: "Today" },
  { id: "weekend", label: "This weekend" },
  { id: "month", label: "This month" },
] as const;

export function LocationFirstEvents() {
  const { location } = useDiscoveryLocation();
  const [dateRange, setDateRange] = useState<"today" | "weekend" | "month">("weekend");
  const [response, setResponse] = useState<LocationFirstResponse | null>(null);
  const query = useMemo(() => ({
    surface: "events" as const,
    location,
    locationMode: "exact" as const,
    radiusMiles: null,
    filters: { recordTypes: ["event" as const], category: null, specialty: null, ownership: [], tagSlugs: [], dateRange },
    searchText: null,
  }), [location, dateRange]);

  useEffect(() => {
    const controller = new AbortController();
    fetch("/api/discovery/query", { method: "POST", credentials: "include", signal: controller.signal, headers: { "Content-Type": "application/json" }, body: JSON.stringify(query) })
      .then((result) => result.json()).then(setResponse)
      .catch((error) => error.name !== "AbortError" && console.error("Event discovery failed", error));
    return () => controller.abort();
  }, [query]);

  const locationLabel = [location.neighborhood, location.city, location.stateCode].filter(Boolean).join(", ");
  return <main className="bg-[#FBF6EC] pb-16"><section className="bg-[#2B1507] px-6 py-16 text-center text-white"><p className="text-xs font-bold uppercase tracking-[0.16em] text-[#E5B94B]">Gather and connect</p><h1 className="mt-3 font-serif text-5xl font-bold">Community events</h1><p className="mx-auto mt-4 max-w-2xl leading-7 text-white/75">What is happening around you, and when?</p><p className="mt-5 font-semibold text-[#E5B94B]">{locationLabel || "Choose an area"}</p><div className="mt-5 flex justify-center gap-2">{TIME_FILTERS.map((filter) => <button aria-pressed={dateRange === filter.id} className={`rounded-full px-4 py-2 text-sm font-semibold ${dateRange === filter.id ? "bg-[#E5B94B] text-[#2B1507]" : "border border-white/30 text-white"}`} key={filter.id} onClick={() => setDateRange(filter.id)} type="button">{filter.label}</button>)}</div></section><section className="mx-auto max-w-6xl px-6 py-8">{response?.requiresLocation ? <EventEmptyState title="Choose an area to find what is happening" body="Events are local and time-specific. Select a city or neighborhood to see current community events." /> : null}{response?.coverageGap ? <EventEmptyState title={`Nothing listed ${dateRange === "weekend" ? "this weekend" : "for this time window"} in ${locationLabel || "this area"} yet`} body="You can look at a nearby city, browse community happenings, or help add an event. This local event gap is recorded so the platform can improve." nearest={response.nearestAvailableLocation?.city ?? null} /> : null}<section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{response?.records.map((record) => <EventCard key={record.id} record={record} />)}</section></section></main>;
}

function EventCard({ record }: { record: DiscoveryRecord }) { return <a className="rounded-2xl border border-[#3A1F0E]/10 bg-white p-5 shadow-sm hover:border-[#CA922B]/60" href={record.detailUrl}><p className="text-xs font-bold uppercase tracking-[0.14em] text-[#8D5C17]">Event</p><h2 className="mt-2 text-xl font-bold text-[#2B1507]">{record.name}</h2><p className="mt-2 text-sm text-[#3A1F0E]/70">{[record.category, record.neighborhood, record.city].filter(Boolean).join(" · ")}</p></a>; }
function EventEmptyState({ title, body, nearest }: { title: string; body: string; nearest?: string | null }) { return <section className="rounded-2xl border border-[#CA922B]/35 bg-white p-8 text-center"><h2 className="font-serif text-3xl font-bold text-[#2B1507]">{title}</h2><p className="mx-auto mt-3 max-w-xl leading-7 text-[#3A1F0E]/70">{body}</p><div className="mt-5 flex flex-wrap justify-center gap-3">{nearest ? <button className="rounded-full border border-[#CA922B] px-4 py-2 font-semibold text-[#8D5C17]" type="button">See events in {nearest}</button> : null}<button className="rounded-full border border-[#CA922B] px-4 py-2 font-semibold text-[#8D5C17]" type="button">Browse all cities</button><a className="rounded-full border border-[#CA922B] px-4 py-2 font-semibold text-[#8D5C17]" href="/events/submit">Add an event</a></div></section>; }
