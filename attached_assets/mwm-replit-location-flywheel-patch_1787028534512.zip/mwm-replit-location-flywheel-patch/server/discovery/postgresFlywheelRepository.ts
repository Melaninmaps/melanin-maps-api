import type { CoverageGap, FlywheelSignal, LocationFirstQuery, DiscoveryRecord } from "../../shared/discoveryContracts";
import type { LocationFirstDiscoveryRepository } from "./locationFirstDiscovery";

type Queryable = {
  query<T>(sql: string, parameters?: unknown[]): Promise<{ rows: T[] }>;
};

export function createPostgresFlywheelRepository(
  db: Queryable,
  dependencies: {
    findExact(query: LocationFirstQuery): Promise<DiscoveryRecord[]>;
    findNearestAvailableLocation(query: LocationFirstQuery): Promise<{ city: string; stateCode: string | null; distanceMiles: number | null } | null>;
  },
): LocationFirstDiscoveryRepository {
  return {
    findExact: dependencies.findExact,
    findNearestAvailableLocation: dependencies.findNearestAvailableLocation,
    async recordCoverageGap(gap: CoverageGap) {
      await db.query(
        `INSERT INTO discovery_coverage_gaps (
          city_name, state_code, record_type, category, specialty_slug
        ) VALUES ($1, $2, $3, $4, $5)
        ON CONFLICT DO UPDATE SET
          last_observed_at = NOW(),
          observation_count = discovery_coverage_gaps.observation_count + 1`,
        [gap.city, gap.stateCode, gap.recordType, gap.category, gap.specialty],
      );
    },
    async recordFlywheelSignal(input) {
      const signal: FlywheelSignal = {
        surface: input.surface,
        action: input.action,
        city: input.city,
        stateCode: input.stateCode,
        recordType: input.recordType,
        category: input.category,
        specialty: input.specialty,
        occurredAt: new Date().toISOString(),
      };
      await db.query(
        `INSERT INTO discovery_flywheel_daily_signals (
          day, surface, action, city_name, state_code, record_type, category, specialty_slug, count
        ) VALUES (CURRENT_DATE, $1, $2, $3, $4, $5, $6, $7, 1)
        ON CONFLICT (day, surface, action, city_name, state_code, record_type, category, specialty_slug)
        DO UPDATE SET count = discovery_flywheel_daily_signals.count + 1`,
        [
          signal.surface,
          signal.action,
          signal.city ?? "",
          signal.stateCode ?? "",
          signal.recordType ?? "none",
          signal.category ?? "",
          signal.specialty ?? "",
        ],
      );
    },
  };
}
