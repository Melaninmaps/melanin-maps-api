import { type Express, type Request, type Response } from "express";
import { executeLocationFirstDiscovery, type LocationFirstDiscoveryRepository } from "./locationFirstDiscovery";
import type { LocationFirstQuery } from "../../shared/discoveryContracts";

const RECORD_TYPES = new Set(["business", "cultural_site", "event", "community_place", "resource"]);
const LOCATION_MODES = new Set(["exact", "expanded_radius", "nearest_city", "all_locations"]);

function isValidQuery(value: unknown): value is LocationFirstQuery {
  const query = value as Partial<LocationFirstQuery>;
  return Boolean(
    query &&
      typeof query.surface === "string" &&
      query.location &&
      query.filters &&
      Array.isArray(query.filters.recordTypes) &&
      query.filters.recordTypes.every((recordType) => RECORD_TYPES.has(recordType)) &&
      typeof query.locationMode === "string" &&
      LOCATION_MODES.has(query.locationMode),
  );
}

export function registerLocationFirstDiscoveryRoutes(app: Express, repository: LocationFirstDiscoveryRepository): void {
  app.post("/api/discovery/query", async (request: Request, response: Response) => {
    if (!isValidQuery(request.body)) return response.status(400).json({ error: "Invalid location-first discovery query." });

    const query = request.body as LocationFirstQuery;
    // All-national browsing must follow a member's explicit choice, never an
    // automatic fallback after exact-local inventory is empty.
    if (query.locationMode === "all_locations" && request.header("x-mwm-confirm-expansion") !== "true") {
      return response.status(400).json({ error: "All-location browsing requires explicit member confirmation." });
    }

    const result = await executeLocationFirstDiscovery(query, repository);
    response.setHeader("Cache-Control", "private, no-store, max-age=0");
    response.setHeader("Vary", "Authorization, Cookie, X-Community-Location");
    return response.json(result);
  });
}
