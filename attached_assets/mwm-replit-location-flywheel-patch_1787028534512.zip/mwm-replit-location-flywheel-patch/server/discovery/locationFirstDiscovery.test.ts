import { describe, expect, it, vi } from "vitest";
import { executeLocationFirstDiscovery } from "./locationFirstDiscovery";
import type { LocationFirstQuery } from "../../shared/discoveryContracts";

const baseQuery: LocationFirstQuery = {
  surface: "map",
  location: { city: "Charlotte", stateCode: "NC", neighborhood: null, latitude: null, longitude: null, source: "explicit" },
  locationMode: "exact",
  radiusMiles: null,
  filters: { recordTypes: ["business"], category: null, specialty: "barber", ownership: [], tagSlugs: [], dateRange: null },
  searchText: null,
};

function repository(records: unknown[] = []) {
  return {
    findExact: vi.fn(async () => records),
    findNearestAvailableLocation: vi.fn(async () => ({ city: "Atlanta", stateCode: "GA", distanceMiles: 245 })),
    recordCoverageGap: vi.fn(async () => undefined),
    recordFlywheelSignal: vi.fn(async () => undefined),
  };
}

describe("location-first discovery", () => {
  it("returns only exact local Business pins and sidebar records when the Businesses layer is selected", async () => {
    const localBusiness = {
      id: "barber-1", recordType: "business", name: "Charlotte Barber", category: "Beauty & Personal Care", specialty: "barber",
      city: "Charlotte", stateCode: "NC", neighborhood: "Uptown", latitude: 35.22, longitude: -80.84, distanceMiles: 1.3,
      detailUrl: "/businesses/barber-1", isVerified: true, contextTags: [],
    };
    const repo = repository([localBusiness]);
    const result = await executeLocationFirstDiscovery(baseQuery, repo);

    expect(result.records).toEqual([localBusiness]);
    expect(result.coverageGap).toBeNull();
    expect(repo.recordCoverageGap).not.toHaveBeenCalled();
  });

  it("does not replace a Charlotte empty result with a global list", async () => {
    const repo = repository();
    const result = await executeLocationFirstDiscovery(baseQuery, repo);

    expect(result.records).toEqual([]);
    expect(result.coverageGap?.city).toBe("Charlotte");
    expect(result.coverageGap?.specialty).toBe("barber");
    expect(result.suggestedActions).toContain("show_nearest_city");
    expect(repo.recordCoverageGap).toHaveBeenCalledOnce();
  });

  it("asks for a location instead of loading all inventory when the member has not selected an area", async () => {
    const repo = repository();
    const result = await executeLocationFirstDiscovery({
      ...baseQuery,
      location: { city: null, stateCode: null, neighborhood: null, latitude: null, longitude: null, source: "none" },
    }, repo);

    expect(result.requiresLocation).toBe(true);
    expect(result.records).toEqual([]);
    expect(repo.findExact).not.toHaveBeenCalled();
  });
});
