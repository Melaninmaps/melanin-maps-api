-- Location-first discovery schema.
-- This migration adds a shared discovery projection; it does not create copies of
-- business/cultural/event content. record_id points to the canonical source row.

BEGIN;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS canonical_record_locations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  record_type TEXT NOT NULL CHECK (record_type IN ('business', 'cultural_site', 'event', 'community_place', 'resource')),
  record_id UUID NOT NULL,
  city_name TEXT NOT NULL,
  state_code TEXT,
  neighborhood_name TEXT,
  latitude NUMERIC(9,6),
  longitude NUMERIC(9,6),
  is_primary BOOLEAN NOT NULL DEFAULT TRUE,
  verified_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (record_type, record_id, city_name, state_code, neighborhood_name)
);

CREATE INDEX IF NOT EXISTS canonical_record_locations_city_idx
  ON canonical_record_locations (record_type, LOWER(city_name), UPPER(state_code));
CREATE INDEX IF NOT EXISTS canonical_record_locations_coordinate_idx
  ON canonical_record_locations (latitude, longitude)
  WHERE latitude IS NOT NULL AND longitude IS NOT NULL;

-- Business remains the source of truth; specialties are searchable facets.
CREATE TABLE IF NOT EXISTS business_specialties (
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  specialty_slug TEXT NOT NULL CHECK (specialty_slug ~ '^[a-z0-9]+(?:-[a-z0-9]+)*$'),
  verified_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (business_id, specialty_slug)
);
CREATE INDEX IF NOT EXISTS business_specialties_lookup_idx ON business_specialties (specialty_slug, business_id);

-- “Barber” is a first-class discovery facet; it is not hidden inside generic
-- Beauty & Personal Care. Add other specialties through the same table.
INSERT INTO business_specialties (business_id, specialty_slug)
SELECT id, 'barber'
FROM businesses
WHERE LOWER(COALESCE(category, '')) IN ('barber', 'barbershop', 'barbers')
ON CONFLICT DO NOTHING;

-- Aggregate unmet local demand. Do not write exact device coordinates, private
-- prompts, or member identity to this table.
CREATE TABLE IF NOT EXISTS discovery_coverage_gaps (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  city_name TEXT NOT NULL,
  state_code TEXT,
  record_type TEXT NOT NULL CHECK (record_type IN ('business', 'cultural_site', 'event', 'community_place', 'resource')),
  category TEXT,
  specialty_slug TEXT,
  first_observed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_observed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  observation_count INTEGER NOT NULL DEFAULT 1 CHECK (observation_count >= 1)
);
CREATE UNIQUE INDEX IF NOT EXISTS discovery_coverage_gaps_unique_context_idx
  ON discovery_coverage_gaps (
    LOWER(city_name),
    COALESCE(UPPER(state_code), ''),
    record_type,
    COALESCE(LOWER(category), ''),
    COALESCE(specialty_slug, '')
  );

-- Aggregate engagement used to improve local retrieval and identify community
-- gaps. A daily roll-up protects privacy and keeps Kinfolk from becoming a
-- surveillance profile.
CREATE TABLE IF NOT EXISTS discovery_flywheel_daily_signals (
  day DATE NOT NULL DEFAULT CURRENT_DATE,
  surface TEXT NOT NULL CHECK (surface IN ('map', 'businesses', 'explore', 'events', 'kinfolk')),
  action TEXT NOT NULL,
  city_name TEXT NOT NULL DEFAULT '',
  state_code TEXT NOT NULL DEFAULT '',
  record_type TEXT NOT NULL DEFAULT 'none' CHECK (record_type IN ('business', 'cultural_site', 'event', 'community_place', 'resource', 'none')),
  category TEXT NOT NULL DEFAULT '',
  specialty_slug TEXT NOT NULL DEFAULT '',
  count INTEGER NOT NULL DEFAULT 1 CHECK (count >= 1),
  PRIMARY KEY (day, surface, action, city_name, state_code, record_type, category, specialty_slug)
);

COMMIT;
