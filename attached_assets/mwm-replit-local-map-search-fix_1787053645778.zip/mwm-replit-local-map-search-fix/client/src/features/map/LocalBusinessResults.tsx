import { useEffect, useState } from "react";

type Result = { id: string; name: string; city: string | null; stateCode: string | null; latitude: number; longitude: number; distanceMi: number; detailUrl: string };
type SearchResponse = { scope: "local" | "expanded"; radiusMi: number; limit: number; results: Result[]; pins: Result[]; expansion: { available: boolean; nextRadiusMi: 10 | 25 | null; message: string | null } };
type Area = { latitude: number; longitude: number; label: string };

type Props = { query: string; area: Area; onPinsChange(pins: Result[], area: Area): void };

export function LocalBusinessResults({ query, area, onPinsChange }: Props) {
  const [response, setResponse] = useState<SearchResponse | null>(null);
  const [status, setStatus] = useState<"loading" | "ready" | "error">("loading");
  const [radiusMi, setRadiusMi] = useState<5 | 10 | 25>(5);

  useEffect(() => {
    if (!query.trim()) return;
    const controller = new AbortController();
    setStatus("loading");
    const url = `/api/map/local-business-search?q=${encodeURIComponent(query)}&lat=${area.latitude}&lng=${area.longitude}&radius=${radiusMi}&expand=${radiusMi > 5 ? 1 : 0}`;
    fetch(url, { signal: controller.signal, headers: { Accept: "application/json" } })
      .then((result) => result.ok ? result.json() : Promise.reject(new Error("LOCAL_SEARCH_FAILED")))
      .then((result: SearchResponse) => { setResponse(result); setStatus("ready"); onPinsChange(result.pins, area); })
      .catch((error) => { if (error.name !== "AbortError") { setStatus("error"); onPinsChange([], area); } });
    return () => controller.abort();
  }, [query, area.latitude, area.longitude, radiusMi, onPinsChange]);

  if (status === "loading") return <p className="map-search-status">Finding nearby results…</p>;
  if (status === "error") return <p className="map-search-error">We could not load nearby results. Please try again.</p>;
  if (!response) return null;

  return <section aria-label="Nearby search results" className="map-local-results">
    <p className="map-local-results-summary">{response.results.length} nearby {response.results.length === 1 ? "result" : "results"} within {response.radiusMi} miles of {area.label}.</p>
    {response.results.length === 0 ? <p>No matching places were found nearby.</p> : <ol>{response.results.map((business) => <li key={business.id}><a href={business.detailUrl}><strong>{business.name}</strong><span>{[business.city, business.stateCode].filter(Boolean).join(", ")} · {business.distanceMi.toFixed(1)} mi away</span></a></li>)}</ol>}
    {response.expansion.available && response.expansion.nextRadiusMi ? <div className="map-search-expansion"><p>{response.expansion.message}</p><button onClick={() => setRadiusMi(response.expansion.nextRadiusMi!)} type="button">Search within {response.expansion.nextRadiusMi} miles</button></div> : null}
  </section>;
}
