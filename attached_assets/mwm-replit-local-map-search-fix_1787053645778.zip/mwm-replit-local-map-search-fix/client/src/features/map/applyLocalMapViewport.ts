type Coordinate = { latitude: number; longitude: number };
type NearbyPin = Coordinate & { id: string };

export type MapViewportAdapter = {
  clearSearchPins(): void;
  renderSearchPins(pins: NearbyPin[]): void;
  setView(center: [number, number], zoom: number): void;
  fitBounds(bounds: [[number, number], [number, number]], options: { padding: [number, number]; maxZoom: number }): void;
};

export function applyLocalMapViewport(map: MapViewportAdapter, area: Coordinate, pins: NearbyPin[]) {
  // Search results own a distinct pin layer. Never reuse the global discovery layer.
  map.clearSearchPins();
  map.renderSearchPins(pins);

  if (pins.length === 0) {
    map.setView([area.latitude, area.longitude], 12);
    return;
  }

  const coordinates = [{ latitude: area.latitude, longitude: area.longitude }, ...pins];
  const latitudes = coordinates.map((point) => point.latitude);
  const longitudes = coordinates.map((point) => point.longitude);
  map.fitBounds(
    [[Math.min(...latitudes), Math.min(...longitudes)], [Math.max(...latitudes), Math.max(...longitudes)]],
    { padding: [72, 72], maxZoom: 14 },
  );
}

// Parent integration:
// <LocalBusinessResults query={query} area={selectedArea} onPinsChange={(pins, area) => applyLocalMapViewport(map, area, pins)} />
// Do not call fitBounds with global discoverability pins after a local search response.
