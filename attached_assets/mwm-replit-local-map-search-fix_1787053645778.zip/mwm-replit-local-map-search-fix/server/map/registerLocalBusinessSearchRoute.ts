import type { Express, Request, Response, NextFunction } from "express";
import { LocalBusinessSearch } from "./localBusinessSearch";

export function registerLocalBusinessSearchRoute(app: Express, service: LocalBusinessSearch) {
  app.get("/api/map/local-business-search", async (request: Request, response: Response, next: NextFunction) => {
    try {
      const query = typeof request.query.q === "string" ? request.query.q : "";
      const latitude = Number(request.query.lat);
      const longitude = Number(request.query.lng);
      const radius = Number(request.query.radius ?? 5);
      const expansionAccepted = request.query.expand === "1";
      if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) return response.status(400).json({ code: "LOCATION_REQUIRED" });
      if (![5, 10, 25].includes(radius)) return response.status(400).json({ code: "INVALID_RADIUS" });
      const result = await service.search({ query, latitude, longitude, radiusMi: radius as 5 | 10 | 25, expansionAccepted });
      response.setHeader("Cache-Control", "no-store");
      return response.json(result);
    } catch (error) {
      return next(error);
    }
  });
}
