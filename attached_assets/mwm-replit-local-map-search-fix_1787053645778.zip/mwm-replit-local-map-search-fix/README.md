# Local Map Search: Charlotte Bookstore Correction

## Required behavior

A member in Charlotte who searches **bookstore** should see exactly the two closest qualifying Charlotte-area businesses in the initial result set. Their two map pins should be emphasized and the map should remain around Charlotte.

**Hakim’s Bookstore in Philadelphia must not appear.** A Raleigh bookstore must also not appear while two qualifying Charlotte results already exist. Neither Kinfolk nor the map may silently choose a more distant business merely because it matches the search term.

| Situation | Required result |
|---|---|
| Two or more matches within 5 miles | Return only the nearest **two**; map displays only their pins plus the member location. |
| One or zero matches within 5 miles | Return the available local result(s), then offer—not apply—an expansion to 10 miles. |
| Still fewer than two after the member selects 10 miles | Offer a second explicit expansion to 25 miles. |
| Two results found at any allowed local radius | Stop. Do not include a farther record. |
| No result within 25 miles | Show a truthful empty state and optional Kinfolk/community-submission path. Do not substitute a national result. |

## What caused the screenshot failure

The current map is using a broad/global pin or search feed in addition to the local result list. That creates two contradictory views: a Charlotte-side result list combined with map bounds that include the United States, Raleigh, Philadelphia, and unrelated places. The result source, pin source, and map-bounds source must be one identical local response.

## Install sequence

1. Register `registerLocalBusinessSearchRoute(app, new LocalBusinessSearch(pool))` after location resolution and before the generic API 404 handler.
2. Replace the existing map search call with `GET /api/map/local-business-search`.
3. Mount `LocalBusinessResults` in the left panel.
4. Pass **only** `response.pins` to `applyLocalMapViewport`. Clear the old global discovery/search pins whenever a local search begins.
5. Add `data-testid="local-search-pin"` to each pin created from this response; do not add it to global map inventory pins.
6. Run the regression tests before release.

## Server guarantees

`localBusinessSearch.ts` calculates the Haversine distance in PostgreSQL, constrains it server-side, sorts by distance, and enforces `LIMIT 2`. The client cannot append Hakim’s Bookstore, Raleigh, Boston, or any other far record after the response arrives.

The map’s `pins` property is a deliberate reference to the same two results returned to the left panel. There is no independent map-search source.

## Client map integration

```tsx
<LocalBusinessResults
  query={query}
  area={selectedArea}
  onPinsChange={(pins, area) => applyLocalMapViewport(mapAdapter, area, pins)}
/>
```

The map viewport implementation first clears the search pin layer and then fits bounds to **the member’s selected area plus the returned local pins only**. It must not call `fitBounds` on all discovery records after this function runs.

## Release gate

Use a Charlotte test location and the real bookstore data. The following must pass:

1. Search `bookstore` from Charlotte.
2. The left panel contains **Urban Reader** and **Curio, Craft & Conjure** only.
3. It contains no **Hakim’s Bookstore**, Raleigh, Philadelphia, Boston, or national fallback record.
4. Exactly two local search pins render.
5. The map remains centered/zoomed around Charlotte, not the United States.
6. The API response reports `radiusMi: 5`, `limit: 2`, and the same two IDs in `results` and `pins`.
7. A wider search request occurs only after an explicit `Search within … miles` click; it does not trigger just because a farther match exists.

This patch must be released after the slug-schema fix, because the business detail URLs include the canonical `slug` field.
