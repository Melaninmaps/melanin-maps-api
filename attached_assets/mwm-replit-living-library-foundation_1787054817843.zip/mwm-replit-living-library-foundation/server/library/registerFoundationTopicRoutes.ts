import type { Express, Request, Response, NextFunction } from "express";
import { FoundationTopicRepository } from "./foundationTopicRepository";

export function registerFoundationTopicRoutes(app: Express, repository: FoundationTopicRepository) {
  app.get("/api/library/topics", async (request: Request, response: Response, next: NextFunction) => {
    try {
      const featuredOnly = request.query.featured === "true";
      const query = typeof request.query.q === "string" ? request.query.q : undefined;
      response.setHeader("Cache-Control", "no-store");
      return response.json({ topics: await repository.list({ featuredOnly, query }) });
    } catch (error) {
      return next(error);
    }
  });
}
