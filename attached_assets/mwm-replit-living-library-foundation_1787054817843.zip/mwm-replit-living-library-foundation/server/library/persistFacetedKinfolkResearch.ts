import type { Pool } from "pg";

export type FacetedLibraryClassification = {
  topicSlugs: string[];
  facetKeys: string[];
  relatedTopicSlugs?: string[];
};

// Kinfolk writes source-cited content once, then links it to all relevant domains and
// contexts. For example, a Black maternal-health entry can link to Health, Family,
// Rights, Legal Information, and Community Resources without copying the entry.
export async function persistFacetedKinfolkResearch(
  pool: Pool,
  entryId: string,
  classification: FacetedLibraryClassification,
) {
  const topicSlugs = [...new Set(classification.topicSlugs)].slice(0, 6);
  const facetKeys = [...new Set(classification.facetKeys)].slice(0, 12);
  if (topicSlugs.length === 0) throw new Error("KIN_FOLK_RESEARCH_NEEDS_A_TOPIC");

  await pool.query("BEGIN");
  try {
    const { rows: topics } = await pool.query<{ id: string; slug: string }>(
      `SELECT id, slug FROM library_topics WHERE active = true AND slug = ANY($1::text[])`,
      [topicSlugs],
    );
    if (topics.length === 0) throw new Error("NO_VALID_LIBRARY_TOPICS");

    for (const topic of topics) {
      await pool.query(
        `INSERT INTO library_entry_topic_links (entry_id, topic_id, relevance)
         VALUES ($1, $2, $3)
         ON CONFLICT (entry_id, topic_id) DO UPDATE SET relevance = greatest(library_entry_topic_links.relevance, EXCLUDED.relevance)`,
        [entryId, topic.id, topic.slug === topicSlugs[0] ? 1 : 0.8],
      );
    }

    if (facetKeys.length) {
      await pool.query(
        `INSERT INTO library_entry_facets (entry_id, facet_key)
         SELECT $1, definition.facet_key
         FROM library_facet_definitions definition
         WHERE definition.active = true AND definition.facet_key = ANY($2::text[])
         ON CONFLICT DO NOTHING`,
        [entryId, facetKeys],
      );
    }

    await pool.query("COMMIT");
  } catch (error) {
    await pool.query("ROLLBACK");
    throw error;
  }
}

// Kinfolk classification policy:
// - topicSlugs are durable foundations, not one-off subfolders.
// - facetKeys capture who, goal, place, life stage, cultural context, need, experience,
//   resource, and content type.
// - content types (guide, professional, event, historic place, story) are facets, never
//   top-level topic replacements.
