BEGIN;

-- A topic is a durable domain, not a rigid folder. Its readable slug connects it to the
-- MWM gold-outline topic icon registry and supports stable Library URLs.
CREATE TABLE IF NOT EXISTS public.library_topics (
  id uuid PRIMARY KEY,
  slug text NOT NULL UNIQUE,
  title text NOT NULL,
  summary text NOT NULL DEFAULT '',
  icon_key text NOT NULL DEFAULT 'general',
  is_foundational boolean NOT NULL DEFAULT true,
  is_featured boolean NOT NULL DEFAULT false,
  sort_order integer NOT NULL DEFAULT 999,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (btrim(slug) <> ''),
  CHECK (btrim(title) <> '')
);

ALTER TABLE public.library_topics ADD COLUMN IF NOT EXISTS summary text NOT NULL DEFAULT '';
ALTER TABLE public.library_topics ADD COLUMN IF NOT EXISTS icon_key text NOT NULL DEFAULT 'general';
ALTER TABLE public.library_topics ADD COLUMN IF NOT EXISTS is_foundational boolean NOT NULL DEFAULT true;
ALTER TABLE public.library_topics ADD COLUMN IF NOT EXISTS is_featured boolean NOT NULL DEFAULT false;
ALTER TABLE public.library_topics ADD COLUMN IF NOT EXISTS sort_order integer NOT NULL DEFAULT 999;
ALTER TABLE public.library_topics ADD COLUMN IF NOT EXISTS active boolean NOT NULL DEFAULT true;

-- Context facets are reusable dimensions. They let one Library entry appear under several
-- topics and be refined by who, place, goal, life stage, cultural context, and resource.
CREATE TABLE IF NOT EXISTS public.library_facet_definitions (
  facet_key text PRIMARY KEY,
  dimension text NOT NULL,
  label text NOT NULL,
  active boolean NOT NULL DEFAULT true,
  CHECK (dimension IN ('who', 'goal', 'where', 'life_stage', 'cultural_context', 'need', 'experience', 'resource', 'content_type'))
);

CREATE TABLE IF NOT EXISTS public.library_entry_topic_links (
  entry_id uuid NOT NULL,
  topic_id uuid NOT NULL REFERENCES public.library_topics(id) ON DELETE CASCADE,
  relevance numeric(4,3) NOT NULL DEFAULT 1.000 CHECK (relevance > 0 AND relevance <= 1),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (entry_id, topic_id)
);

CREATE TABLE IF NOT EXISTS public.library_entry_facets (
  entry_id uuid NOT NULL,
  facet_key text NOT NULL REFERENCES public.library_facet_definitions(facet_key) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (entry_id, facet_key)
);

CREATE TABLE IF NOT EXISTS public.library_topic_relationships (
  from_topic_id uuid NOT NULL REFERENCES public.library_topics(id) ON DELETE CASCADE,
  to_topic_id uuid NOT NULL REFERENCES public.library_topics(id) ON DELETE CASCADE,
  relationship_type text NOT NULL CHECK (relationship_type IN ('related', 'pathway', 'resource', 'place', 'community_context')),
  weight numeric(4,3) NOT NULL DEFAULT 1.000 CHECK (weight > 0 AND weight <= 1),
  PRIMARY KEY (from_topic_id, to_topic_id, relationship_type),
  CHECK (from_topic_id <> to_topic_id)
);

INSERT INTO public.library_topics (id, slug, title, summary, icon_key, is_featured, sort_order)
VALUES
  ('10000000-0000-0000-0000-000000000001','housing-home','Housing & Home','Renting, homeownership, neighborhoods, home services, and housing rights.','housing',true,10),
  ('10000000-0000-0000-0000-000000000002','education-learning','Education & Learning','Schools, HBCUs, scholarships, adult learning, and pathways forward.','education',true,20),
  ('10000000-0000-0000-0000-000000000003','trades-skills-certifications','Trades, Skills & Certifications','Apprenticeships, skilled trades, certifications, and career pathways.','home-services',true,30),
  ('10000000-0000-0000-0000-000000000004','health-wellness','Health & Wellness','Culturally responsive health information, care, wellness, and support.','health',true,40),
  ('10000000-0000-0000-0000-000000000005','money-economic-mobility','Money & Economic Mobility','Credit, banking, ownership, financial literacy, and wealth-building.','money',true,50),
  ('10000000-0000-0000-0000-000000000006','careers-professional-life','Careers & Professional Life','Workplace life, advancement, mentorship, and professional development.','career',true,60),
  ('10000000-0000-0000-0000-000000000007','business-entrepreneurship','Business & Entrepreneurship','Starting, operating, funding, growing, and sustaining community businesses.','business',true,70),
  ('10000000-0000-0000-0000-000000000008','community-resources-help','Community Resources & Help','Local assistance, mutual aid, grants, legal aid, transportation, and childcare.','community',true,80),
  ('10000000-0000-0000-0000-000000000009','culture-heritage','Culture & Heritage','Traditions, identity, diaspora, cultural preservation, and shared history.','culture',true,90),
  ('10000000-0000-0000-0000-000000000010','places-our-history','Places & Our History','Historic sites, neighborhoods, HBCUs, migration routes, and living landmarks.','culture',true,100),
  ('10000000-0000-0000-0000-000000000011','travel-exploration','Travel & Exploration','Cultural travel, safety, etiquette, local discovery, and meaningful journeys.','travel',true,110),
  ('10000000-0000-0000-0000-000000000012','living-relocation','Living & Relocation','Moving, community fit, local culture, transportation, schools, and daily life.','housing',false,120),
  ('10000000-0000-0000-0000-000000000013','family-relationships','Family & Relationships','Parenting, caregiving, elders, chosen family, and multigenerational life.','community',false,130),
  ('10000000-0000-0000-0000-000000000014','beauty-hair-personal-care','Beauty, Hair & Personal Care','Hair, skin, grooming, traditions, specialists, and product education.','beauty',false,140),
  ('10000000-0000-0000-0000-000000000015','food-culinary-culture','Food & Culinary Culture','Food history, restaurants, recipes, traditions, and culinary businesses.','food',false,150),
  ('10000000-0000-0000-0000-000000000016','faith-spirituality-community-institutions','Faith, Spirituality & Community Institutions','Faith communities, spiritual traditions, service organizations, and history.','community',false,160),
  ('10000000-0000-0000-0000-000000000017','arts-music-creative-culture','Arts, Music & Creative Culture','Music, visual art, literature, fashion, film, dance, and cultural movements.','culture',false,170),
  ('10000000-0000-0000-0000-000000000018','entertainment-social-life','Entertainment & Social Life','Nightlife, festivals, celebrations, social spaces, and community events.','travel',false,180),
  ('10000000-0000-0000-0000-000000000019','community-connection','Community & Connection','Organizations, networks, mutual aid, volunteering, and affinity groups.','community',false,190),
  ('10000000-0000-0000-0000-000000000020','safety-navigating-world','Safety & Navigating the World','Travel safety, neighborhood awareness, digital safety, and emergency resources.','safety',false,200),
  ('10000000-0000-0000-0000-000000000021','rights-advocacy-civic-life','Rights, Advocacy & Civic Life','Civil rights, voting, consumer rights, discrimination information, and advocacy.','legal',false,210),
  ('10000000-0000-0000-0000-000000000022','legal-information-resources','Legal Information & Resources','General legal education, common processes, legal aid, and finding counsel.','legal',false,220),
  ('10000000-0000-0000-0000-000000000023','parenting-youth-future-generations','Parenting, Youth & Future Generations','Youth programs, mentoring, identity, safety, and college preparation.','education',false,230),
  ('10000000-0000-0000-0000-000000000024','lgbtqia-life-community','LGBTQIA+ Life & Community','Resources, history, family, health, travel, businesses, and community life.','community',false,240),
  ('10000000-0000-0000-0000-000000000025','disability-accessibility','Disability & Accessibility','Accessible places, travel, work, rights, and community resources.','safety',false,250),
  ('10000000-0000-0000-0000-000000000026','immigration-migration-diaspora-life','Immigration, Migration & Diaspora Life','Migration histories, adaptation, diaspora connections, and community resources.','travel',false,260),
  ('10000000-0000-0000-0000-000000000027','people-stories-living-memory','People, Stories & Living Memory','Oral histories, elders, leaders, alumni stories, memorials, and living memory.','culture',false,270),
  ('10000000-0000-0000-0000-000000000028','current-issues-community-conversations','Current Issues & Community Conversations','Current community issues, context, resources, and continuing conversation.','community',false,280)
ON CONFLICT (slug) DO UPDATE
SET title = EXCLUDED.title, summary = EXCLUDED.summary, icon_key = EXCLUDED.icon_key,
    is_featured = EXCLUDED.is_featured, sort_order = EXCLUDED.sort_order, active = true,
    updated_at = now();

INSERT INTO public.library_facet_definitions (facet_key, dimension, label)
VALUES
  ('who:black-women','who','Black women'),('who:family','who','Families'),('goal:find-provider','goal','Find a provider'),
  ('goal:learn','goal','Learn'),('goal:take-action','goal','Take action'),('where:location-specific','where','Location specific'),
  ('life-stage:youth','life_stage','Youth'),('life-stage:parenting','life_stage','Parenting'),('life-stage:elder-care','life_stage','Elder care'),
  ('cultural-context:diaspora','cultural_context','Diaspora context'),('cultural-context:lived-experience','cultural_context','Lived experience'),
  ('need:urgent-support','need','Urgent support'),('need:connection','need','Connection'),('experience:travel','experience','Travel'),
  ('resource:professional','resource','Professional'),('resource:organization','resource','Organization'),
  ('content:guide','content_type','Guide'),('content:business','content_type','Business'),('content:event','content_type','Event'),('content:story','content_type','Personal story')
ON CONFLICT (facet_key) DO UPDATE SET label = EXCLUDED.label, active = true;

COMMIT;
