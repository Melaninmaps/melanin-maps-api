import { expect, test } from "@playwright/test";

const startHere = ["Housing & Home", "Education & Learning", "Trades, Skills & Certifications", "Health & Wellness", "Money & Economic Mobility", "Careers & Professional Life", "Business & Entrepreneurship", "Community Resources & Help"];

test.describe("Living Library foundation", () => {
  test("opens with readable introductory copy and populated foundational cards", async ({ page }) => {
    await page.goto("/library");
    await expect(page.getByRole("heading", { name: /knowledge that grows with the community/i })).toBeVisible();
    await expect(page.getByText(/begin with trusted foundations for the diaspora/i)).toBeVisible();
    for (const title of startHere) await expect(page.getByRole("link", { name: new RegExp(title, "i") })).toBeVisible();
    await expect(page.locator(".living-library-topic-card")).toHaveCount(8);
    await expect(page.getByText(/^research entries$/i)).toHaveCount(0);
  });

  test("preselected topic search opens the selected foundational topic", async ({ page }) => {
    await page.goto("/library");
    await page.getByRole("link", { name: /housing & home/i }).click();
    await expect(page).toHaveURL(/\/library\/topics\/housing-home$/);
  });

  test("a faceted entry can appear under several foundational topics", async ({ request }) => {
    const response = await request.get("/api/library/search?q=black%20maternal%20health");
    expect(response.ok()).toBeTruthy();
    const body = await response.json();
    const entry = body.entries.find((item: { title: string }) => /maternal health/i.test(item.title));
    if (entry) expect(entry.topics.length).toBeGreaterThanOrEqual(2);
  });
});
