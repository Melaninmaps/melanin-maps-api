import type { ReactNode } from "react";
import { GoldFeatherBadge, GoldFeatherIcon } from "./GoldFeatherIcon";

export type MwmOwnedSurface =
  | "navigation"
  | "directory"
  | "kinfolk"
  | "library"
  | "category-card"
  | "button"
  | "status";

/**
 * Use this in every MWM-authored control that formerly used an emoji. The
 * surface is semantic only; the visual mark remains the approved gold feather.
 */
export function MwmOwnedAccent({
  label,
  surface: _surface,
  compact = false,
}: {
  label: string;
  surface: MwmOwnedSurface;
  compact?: boolean;
}) {
  return compact ? <GoldFeatherIcon label={label} size={18} /> : <GoldFeatherBadge label={label} />;
}

function stripUnicodeEmoji(value: string): string {
  return value
    .replace(/\p{Extended_Pictographic}/gu, "")
    .replace(/\uFE0F|\u200D/g, "")
    .replace(/[ \t]{2,}/g, " ")
    .replace(/[ \t]+([,.;:!?])/g, "$1")
    .trim();
}

/**
 * System, editorial, and assistant content must use the feather component for
 * accents. Member-authored copy is returned untouched, including their emoji.
 */
export function BrandedText({
  children,
  origin,
  className = "",
}: {
  children: string;
  origin: "mwm" | "kinfolk" | "member";
  className?: string;
}) {
  const text = origin === "member" ? children : stripUnicodeEmoji(children);
  return <span className={className}>{text}</span>;
}

export function MwmCardHeading({
  children,
  label,
  className = "",
}: {
  children: ReactNode;
  label: string;
  className?: string;
}) {
  return (
    <div className={`flex items-center gap-3 ${className}`.trim()}>
      <MwmOwnedAccent compact label={label} surface="category-card" />
      <span>{children}</span>
    </div>
  );
}
