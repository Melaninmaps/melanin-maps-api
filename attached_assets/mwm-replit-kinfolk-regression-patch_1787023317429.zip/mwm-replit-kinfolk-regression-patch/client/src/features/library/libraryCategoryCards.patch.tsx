/*
  REPLACE THE CURRENT CATEGORY CONFIGURATION AND CARD MARKUP.
  Remove every `emoji` field from MWM-owned category data.
*/

import { MwmOwnedAccent } from "../../components/brand/mwmVisualLanguage";

type LibraryCategory = {
  id: string;
  name: string;
  topicCount: number;
};

export const libraryCategories: LibraryCategory[] = [
  { id: "business", name: "Business", topicCount: 2 },
  { id: "careers", name: "Careers & Professional", topicCount: 4 },
  { id: "community", name: "Community", topicCount: 6 },
  { id: "culture", name: "Culture & Community", topicCount: 7 },
  { id: "divine-nine", name: "Divine Nine", topicCount: 9 },
  { id: "education", name: "Education", topicCount: 3 },
  { id: "faith", name: "Faith & Spirituality", topicCount: 12 },
  { id: "health", name: "Health", topicCount: 28 },
  { id: "history", name: "History", topicCount: 2 },
  { id: "places", name: "Places", topicCount: 3 },
  { id: "travel", name: "Travel", topicCount: 66 },
];

export function LibraryCategoryCard({ category }: { category: LibraryCategory }) {
  return (
    <button
      type="button"
      className="rounded-2xl bg-[#2B1507] p-5 text-left text-white transition hover:bg-[#3A1F0E] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#CA922B]"
    >
      <MwmOwnedAccent label={`${category.name} library category`} surface="category-card" />
      <h2 className="mt-3 text-lg font-bold">{category.name}</h2>
      <p className="mt-1 text-sm text-[#CA922B]">{category.topicCount} topics</p>
    </button>
  );
}

/*
  Apply the same replacement in navigation, status chips, Kinfolk controls,
  and system messages: replace Unicode emoji with <MwmOwnedAccent />.
  Never apply this replacement to a community member's authored message body.
*/
