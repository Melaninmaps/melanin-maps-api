import { Link } from "react-router-dom";
import { GoldFeatherIcon } from "../../components/brand/GoldFeatherIcon";
import { BrandedText, MwmOwnedAccent } from "../../components/brand/mwmVisualLanguage";

type KinfolkNightlifeResponse = {
  intent: "nightlife";
  resolvedCity: { name: string; stateCode: string } | null;
  message: string;
  locationNeeded: boolean;
  venues: Array<{
    id: string;
    name: string;
    detailUrl: string;
    category: string;
    addressLine1: string | null;
  }>;
};

export function MemberMessage({ children }: { children: string }) {
  // The member controls this content; emoji they typed are intentionally kept.
  return <BrandedText className="whitespace-pre-wrap" origin="member">{children}</BrandedText>;
}

export default function KinfolkNightlifeResponse({ response }: { response: KinfolkNightlifeResponse }) {
  return (
    <section className="max-w-4xl rounded-2xl border border-[#3A1F0E]/10 bg-white p-5 shadow-sm">
      <div className="flex items-center gap-3 text-[#CA922B]">
        <MwmOwnedAccent compact label="Kinfolk response" surface="kinfolk" />
        <p className="text-xs font-bold uppercase tracking-[0.16em]">Kinfolk</p>
      </div>

      {response.resolvedCity ? (
        <p className="mt-3 text-sm font-semibold text-[#3A1F0E]">
          <GoldFeatherIcon className="mr-2" label="Resolved location" size={15} />
          Searching {response.resolvedCity.name}, {response.resolvedCity.stateCode}
        </p>
      ) : null}

      <BrandedText className="mt-3 block whitespace-pre-wrap leading-7 text-[#3A1F0E]" origin="kinfolk">
        {response.message}
      </BrandedText>

      {response.venues.length > 0 ? (
        <ul className="mt-5 grid gap-3 sm:grid-cols-2">
          {response.venues.map((venue) => (
            <li key={venue.id}>
              <Link
                className="block rounded-xl border border-[#3A1F0E]/10 p-4 transition hover:border-[#CA922B]/60 hover:shadow-sm"
                to={venue.detailUrl}
              >
                <div className="flex gap-2">
                  <GoldFeatherIcon label={`${venue.name} listing`} size={17} />
                  <div>
                    <p className="font-bold text-[#3A1F0E]">{venue.name}</p>
                    <p className="mt-1 text-sm text-[#3A1F0E]/70">{venue.category}</p>
                    {venue.addressLine1 ? (
                      <p className="mt-1 text-sm text-[#3A1F0E]/60">{venue.addressLine1}</p>
                    ) : null}
                  </div>
                </div>
              </Link>
            </li>
          ))}
        </ul>
      ) : null}
    </section>
  );
}
