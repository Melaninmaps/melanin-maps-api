import assert from "node:assert/strict";
import {
  answerKinfolkQuestion,
  resolveCityFromQuestion,
  type KinfolkDirectoryRepository,
} from "./server/kinfolk/cityAwareNightlife";

const events: unknown[] = [];
const repository: KinfolkDirectoryRepository = {
  async listCityAliases() {
    return [
      {
        cityId: "charlotte",
        cityName: "Charlotte",
        stateCode: "NC",
        latitude: 35.2271,
        longitude: -80.8431,
        alias: "charlotte",
      },
      {
        cityId: "charlotte",
        cityName: "Charlotte",
        stateCode: "NC",
        latitude: 35.2271,
        longitude: -80.8431,
        alias: "charlotte nc",
      },
    ];
  },
  async findVerifiedNightlifeVenues() {
    return [
      {
        id: "verified-charlotte-lounge",
        name: "Verified Charlotte Lounge",
        slug: "verified-charlotte-lounge",
        cityId: "charlotte",
        cityName: "Charlotte",
        stateCode: "NC",
        category: "Nightlife",
        description: "Verified by the directory.",
        addressLine1: "100 Example Street",
        websiteUrl: null,
        isVerified: true,
        isActive: true,
        curationScore: 100,
      },
    ];
  },
  async recordKinfolkRetrieval(event) {
    events.push(event);
  },
};

async function main() {
  const city = await resolveCityFromQuestion("Charlotte NC night life", repository);
  assert.equal(city?.cityName, "Charlotte");
  assert.equal(city?.stateCode, "NC");

  const result = await answerKinfolkQuestion({
    question: "Charlotte NC night life",
    repository,
    answerWriter: {
      async write() {
        return "Start with Verified Charlotte Lounge tonight 🍸.";
      },
    },
  });

  assert.equal(result.locationNeeded, false);
  assert.equal(result.resolvedCity?.name, "Charlotte");
  assert.equal(result.venues[0]?.name, "Verified Charlotte Lounge");
  assert.equal(result.message, "Start with Verified Charlotte Lounge tonight.");
  assert.equal(/\p{Extended_Pictographic}/u.test(result.message), false);
  assert.ok(events.length > 0);

  const cityNeeded = await answerKinfolkQuestion({
    question: "nightlife suggestions",
    repository,
  });
  assert.equal(cityNeeded.locationNeeded, true);

  console.log("Kinfolk city-resolution and gold-feather guardrail smoke test passed.");
}

void main();
