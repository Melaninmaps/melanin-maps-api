-- PostgreSQL migration: reliable city extraction for Kinfolk.
-- Adjust `cities.id` only if the current schema uses a differently named key.

CREATE TABLE IF NOT EXISTS city_aliases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  city_id UUID NOT NULL REFERENCES cities(id) ON DELETE CASCADE,
  alias TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT city_aliases_alias_unique UNIQUE (alias)
);

CREATE INDEX IF NOT EXISTS city_aliases_lookup_idx
  ON city_aliases (LOWER(alias));

-- Add all editorially validated spelling and state-qualified forms for a city.
-- This allows "Charlotte NC night life" to resolve before any generic location
-- prompt is considered. Add the state-qualified alias for every supported city.
INSERT INTO city_aliases (city_id, alias)
SELECT id, alias
FROM cities
CROSS JOIN (VALUES
  ('charlotte'),
  ('charlotte nc'),
  ('charlotte north carolina')
) AS aliases(alias)
WHERE LOWER(cities.name) = 'charlotte'
  AND UPPER(cities.state_code) = 'NC'
ON CONFLICT (alias) DO NOTHING;

-- This is operational telemetry, not a record of private chat content.
-- Do not store a member ID, full conversation transcript, or precise location.
CREATE TABLE IF NOT EXISTS kinfolk_retrieval_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  intent TEXT NOT NULL,
  city_id UUID REFERENCES cities(id) ON DELETE SET NULL,
  query TEXT NOT NULL,
  result_count INTEGER NOT NULL,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT kinfolk_retrieval_events_intent_check CHECK (intent = 'nightlife')
);

CREATE INDEX IF NOT EXISTS kinfolk_retrieval_events_quality_idx
  ON kinfolk_retrieval_events (intent, city_id, occurred_at DESC);
