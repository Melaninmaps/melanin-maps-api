import type {
  CityAlias,
  KinfolkDirectoryRepository,
  NightlifeVenue,
} from "./cityAwareNightlife";

type Queryable = {
  query<T>(sql: string, parameters?: unknown[]): Promise<{ rows: T[] }>;
};

type CityAliasRow = {
  city_id: string;
  city_name: string;
  state_code: string;
  latitude: number;
  longitude: number;
  alias: string;
};

type NightlifeVenueRow = {
  id: string;
  name: string;
  slug: string;
  city_id: string;
  city_name: string;
  state_code: string;
  category: string;
  description: string | null;
  address_line_1: string | null;
  website_url: string | null;
  is_verified: boolean;
  is_active: boolean;
  curation_score: number;
};

export function createPostgresKinfolkDirectoryRepository(
  db: Queryable,
): KinfolkDirectoryRepository {
  return {
    async listCityAliases(): Promise<CityAlias[]> {
      const { rows } = await db.query<CityAliasRow>(`
        SELECT
          ca.city_id,
          c.name AS city_name,
          c.state_code,
          c.latitude,
          c.longitude,
          ca.alias
        FROM city_aliases ca
        JOIN cities c ON c.id = ca.city_id
        WHERE c.is_active = TRUE
          AND c.latitude IS NOT NULL
          AND c.longitude IS NOT NULL
      `);

      return rows.map((row) => ({
        cityId: row.city_id,
        cityName: row.city_name,
        stateCode: row.state_code,
        latitude: row.latitude,
        longitude: row.longitude,
        alias: row.alias,
      }));
    },

    async findVerifiedNightlifeVenues({ cityId, limit }): Promise<NightlifeVenue[]> {
      const { rows } = await db.query<NightlifeVenueRow>(
        `SELECT
          b.id,
          b.name,
          b.slug,
          b.city_id,
          c.name AS city_name,
          c.state_code,
          b.category,
          b.description,
          b.address_line_1,
          b.website_url,
          b.is_verified,
          b.is_active,
          COALESCE(b.curation_score, 0) AS curation_score
        FROM businesses b
        JOIN cities c ON c.id = b.city_id
        WHERE b.city_id = $1
          AND b.is_active = TRUE
          AND b.is_verified = TRUE
          AND (
            LOWER(b.category) IN ('nightlife', 'bars & nightlife')
            OR LOWER(COALESCE(b.subcategory, '')) IN ('nightlife', 'bar', 'lounge', 'club', 'live music')
            OR EXISTS (
              SELECT 1
              FROM unnest(COALESCE(b.tags, ARRAY[]::text[])) AS tag
              WHERE LOWER(tag) IN ('nightlife', 'bar', 'lounge', 'club', 'late-night', 'live music')
            )
          )
        ORDER BY COALESCE(b.curation_score, 0) DESC, b.name ASC
        LIMIT $2`,
        [cityId, limit],
      );

      return rows.map((row) => ({
        id: row.id,
        name: row.name,
        slug: row.slug,
        cityId: row.city_id,
        cityName: row.city_name,
        stateCode: row.state_code,
        category: row.category,
        description: row.description,
        addressLine1: row.address_line_1,
        websiteUrl: row.website_url,
        isVerified: row.is_verified,
        isActive: row.is_active,
        curationScore: row.curation_score,
      }));
    },

    async recordKinfolkRetrieval(input): Promise<void> {
      await db.query(
        `INSERT INTO kinfolk_retrieval_events (
          intent, city_id, query, result_count, occurred_at
        ) VALUES ($1, $2, $3, $4, $5)`,
        [input.intent, input.cityId, input.query, input.resultCount, input.occurredAt],
      );
    },
  };
}
