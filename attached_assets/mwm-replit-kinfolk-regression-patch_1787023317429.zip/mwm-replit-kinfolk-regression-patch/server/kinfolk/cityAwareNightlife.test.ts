import { describe, expect, it, vi } from "vitest";
import {
  answerKinfolkQuestion,
  resolveCityFromQuestion,
  type KinfolkDirectoryRepository,
} from "./cityAwareNightlife";

const repository: KinfolkDirectoryRepository = {
  listCityAliases: vi.fn(async () => [
    {
      cityId: "charlotte",
      cityName: "Charlotte",
      stateCode: "NC",
      latitude: 35.2271,
      longitude: -80.8431,
      alias: "charlotte",
    },
    {
      cityId: "charlotte",
      cityName: "Charlotte",
      stateCode: "NC",
      latitude: 35.2271,
      longitude: -80.8431,
      alias: "charlotte nc",
    },
  ]),
  findVerifiedNightlifeVenues: vi.fn(async () => [
    {
      id: "venue-1",
      name: "Verified Charlotte Lounge",
      slug: "verified-charlotte-lounge",
      cityId: "charlotte",
      cityName: "Charlotte",
      stateCode: "NC",
      category: "Nightlife",
      description: "A verified listing.",
      addressLine1: "100 Example Street",
      websiteUrl: null,
      isVerified: true,
      isActive: true,
      curationScore: 100,
    },
  ]),
  recordKinfolkRetrieval: vi.fn(async () => undefined),
};

describe("city-aware Kinfolk nightlife retrieval", () => {
  it("extracts the most specific city alias from a member question", async () => {
    const city = await resolveCityFromQuestion("Charlotte NC night life", repository);
    expect(city).toMatchObject({ cityName: "Charlotte", stateCode: "NC", alias: "charlotte nc" });
  });

  it("answers Charlotte nightlife directly instead of asking for a location again", async () => {
    const result = await answerKinfolkQuestion({
      question: "Charlotte NC night life",
      repository,
    });

    expect(result.locationNeeded).toBe(false);
    expect(result.resolvedCity).toEqual({ cityId: "charlotte", name: "Charlotte", stateCode: "NC" });
    expect(result.venues[0]?.name).toBe("Verified Charlotte Lounge");
    expect(result.message).toContain("Charlotte, NC");
  });

  it("asks for a city only when no location is present in a nightlife request", async () => {
    const result = await answerKinfolkQuestion({
      question: "Where should I go for nightlife?",
      repository,
    });

    expect(result.locationNeeded).toBe(true);
    expect(result.resolvedCity).toBeNull();
  });

  it("strips Unicode emoji from an assistant draft while keeping the direct answer", async () => {
    const result = await answerKinfolkQuestion({
      question: "Charlotte nightlife",
      repository,
      answerWriter: {
        write: vi.fn(async () => "Try Verified Charlotte Lounge tonight 🍸."),
      },
    });

    expect(result.message).toBe("Try Verified Charlotte Lounge tonight.");
    expect(result.message).not.toMatch(/\p{Extended_Pictographic}/u);
  });
});
