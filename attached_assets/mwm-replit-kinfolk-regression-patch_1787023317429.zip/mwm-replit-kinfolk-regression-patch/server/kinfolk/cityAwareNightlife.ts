export type CityAlias = {
  cityId: string;
  cityName: string;
  stateCode: string;
  latitude: number;
  longitude: number;
  alias: string;
};

export type NightlifeVenue = {
  id: string;
  name: string;
  slug: string;
  cityId: string;
  cityName: string;
  stateCode: string;
  category: string;
  description: string | null;
  addressLine1: string | null;
  websiteUrl: string | null;
  isVerified: boolean;
  isActive: boolean;
  curationScore: number;
};

export interface KinfolkDirectoryRepository {
  listCityAliases(): Promise<CityAlias[]>;
  findVerifiedNightlifeVenues(input: {
    cityId: string;
    limit: number;
  }): Promise<NightlifeVenue[]>;
  recordKinfolkRetrieval(input: {
    intent: "nightlife";
    cityId: string | null;
    query: string;
    resultCount: number;
    occurredAt: Date;
  }): Promise<void>;
}

export interface KinfolkAnswerWriter {
  write(input: {
    system: string;
    user: string;
    context: string;
  }): Promise<string>;
}

export type KinfolkResponse = {
  intent: "nightlife" | "other";
  resolvedCity: {
    cityId: string;
    name: string;
    stateCode: string;
  } | null;
  message: string;
  venues: Array<NightlifeVenue & { detailUrl: string }>;
  locationNeeded: boolean;
};

const NIGHTLIFE_PATTERN = /\b(night\s*-?\s*life|nightlife|bar|bars|club|clubs|late\s+night|lounge|lounges|after\s+dark)\b/i;

function normalize(value: string): string {
  return value
    .toLocaleLowerCase("en-US")
    .replace(/[\u2010-\u2015]/g, "-")
    .replace(/[^\p{L}\p{N}\s-]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function containsPhrase(text: string, phrase: string): boolean {
  return ` ${text} `.includes(` ${phrase} `);
}

function stripAssistantEmoji(value: string): string {
  // Unicode emoji belong to member-authored content only. MWM-owned visual
  // accents are rendered by the GoldFeatherIcon component in the client.
  return value
    .replace(/\p{Extended_Pictographic}/gu, "")
    .replace(/\uFE0F|\u200D/g, "")
    .replace(/[ \t]{2,}/g, " ")
    .replace(/[ \t]+([,.;:!?])/g, "$1")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

export function isNightlifeIntent(question: string): boolean {
  return NIGHTLIFE_PATTERN.test(question);
}

export async function resolveCityFromQuestion(
  question: string,
  repository: Pick<KinfolkDirectoryRepository, "listCityAliases">,
): Promise<CityAlias | null> {
  const normalizedQuestion = normalize(question);
  const aliases = await repository.listCityAliases();

  // Prefer the longest known alias, so "Charlotte NC" wins over "Charlotte"
  // and a state-qualified location is never discarded.
  const candidates = aliases
    .map((entry) => ({ entry, normalizedAlias: normalize(entry.alias) }))
    .filter(({ normalizedAlias }) => normalizedAlias.length > 1)
    .sort((left, right) => right.normalizedAlias.length - left.normalizedAlias.length);

  return candidates.find(({ normalizedAlias }) => containsPhrase(normalizedQuestion, normalizedAlias))?.entry ?? null;
}

function venueDetailUrl(venue: Pick<NightlifeVenue, "id" | "slug">): string {
  return `/businesses/${encodeURIComponent(venue.id)}/${encodeURIComponent(venue.slug)}`;
}

function deterministicNightlifeAnswer(city: CityAlias, venues: NightlifeVenue[]): string {
  if (venues.length === 0) {
    return `I found your location: ${city.cityName}, ${city.stateCode}. I do not yet have verified nightlife listings there to recommend with confidence. I have recorded the gap so the directory can be improved.`;
  }

  const names = venues.slice(0, 3).map((venue) => venue.name).join(", ");
  return `For nightlife in ${city.cityName}, ${city.stateCode}, start with ${names}. I selected these from the verified directory. Open a listing for details, hours, and location before heading out.`;
}

function buildWriterContext(city: CityAlias, venues: NightlifeVenue[]): string {
  const listingText = venues.length
    ? venues
        .map(
          (venue, index) =>
            `${index + 1}. ${venue.name} | ${venue.category} | ${venue.addressLine1 ?? "Address pending"} | ${venue.description ?? "No description yet"}`,
        )
        .join("\n")
    : "No verified nightlife listings were returned.";

  return `Resolved location: ${city.cityName}, ${city.stateCode}\nVerified directory results:\n${listingText}`;
}

export async function answerKinfolkQuestion(
  input: {
    question: string;
    repository: KinfolkDirectoryRepository;
    answerWriter?: KinfolkAnswerWriter;
  },
): Promise<KinfolkResponse> {
  const { question, repository, answerWriter } = input;

  if (!isNightlifeIntent(question)) {
    return {
      intent: "other",
      resolvedCity: null,
      message: "I can help with that. Tell me what you are looking for and the city or area you want to explore.",
      venues: [],
      locationNeeded: true,
    };
  }

  const city = await resolveCityFromQuestion(question, repository);
  if (!city) {
    return {
      intent: "nightlife",
      resolvedCity: null,
      message: "I can help you find nightlife. Which city, neighborhood, or metro area should I use?",
      venues: [],
      locationNeeded: true,
    };
  }

  const venues = (await repository.findVerifiedNightlifeVenues({ cityId: city.cityId, limit: 6 }))
    .filter((venue) => venue.isActive && venue.isVerified)
    .sort((left, right) => right.curationScore - left.curationScore)
    .map((venue) => ({ ...venue, detailUrl: venueDetailUrl(venue) }));

  void repository
    .recordKinfolkRetrieval({
      intent: "nightlife",
      cityId: city.cityId,
      query: question,
      resultCount: venues.length,
      occurredAt: new Date(),
    })
    .catch((error) => console.error("Kinfolk nightlife retrieval signal was not recorded", error));

  const resolvedCity = { cityId: city.cityId, name: city.cityName, stateCode: city.stateCode };
  const fallback = deterministicNightlifeAnswer(city, venues);

  if (!answerWriter) {
    return { intent: "nightlife", resolvedCity, message: fallback, venues, locationNeeded: false };
  }

  try {
    const draftedAnswer = await answerWriter.write({
      system:
        "You are Kinfolk, Mapping with Melanin's community companion. The location has already been resolved from the member's question. Answer directly using only the supplied verified directory results. Do not ask for a city. Do not invent venues, hours, safety information, or availability. Do not use Unicode emoji, symbols, or pictographs; MWM visual accents are rendered by the client as gold feather-outline icons.",
      user: question,
      context: buildWriterContext(city, venues),
    });

    return {
      intent: "nightlife",
      resolvedCity,
      message: stripAssistantEmoji(draftedAnswer) || fallback,
      venues,
      locationNeeded: false,
    };
  } catch (error) {
    console.error("Kinfolk answer writer failed; using verified deterministic answer", error);
    return { intent: "nightlife", resolvedCity, message: fallback, venues, locationNeeded: false };
  }
}
