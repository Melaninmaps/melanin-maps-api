/*
  APPLY THIS IN THE EXISTING POST /api/kinfolk/messages (or equivalent) handler.
  Place it before any generic "I need a location first" guard.
*/

import {
  answerKinfolkQuestion,
  isNightlifeIntent,
  type KinfolkAnswerWriter,
  type KinfolkDirectoryRepository,
} from "./cityAwareNightlife";

export async function handleKinfolkMessage(input: {
  question: string;
  directoryRepository: KinfolkDirectoryRepository;
  answerWriter: KinfolkAnswerWriter;
  runExistingKinfolkHandler: (question: string) => Promise<unknown>;
}) {
  const { question, directoryRepository, answerWriter, runExistingKinfolkHandler } = input;

  if (isNightlifeIntent(question)) {
    // `answerKinfolkQuestion` resolves a city named in the member's text
    // before it decides whether a location prompt is necessary.
    return answerKinfolkQuestion({
      question,
      repository: directoryRepository,
      answerWriter,
    });
  }

  // All non-nightlife questions retain the existing Kinfolk flow.
  return runExistingKinfolkHandler(question);
}

/*
  Example Express use:

  app.post("/api/kinfolk/messages", async (req, res, next) => {
    try {
      const result = await handleKinfolkMessage({
        question: req.body.message,
        directoryRepository,
        answerWriter: existingKinfolkAnswerWriter,
        runExistingKinfolkHandler: existingKinfolkHandler,
      });
      res.json(result);
    } catch (error) {
      next(error);
    }
  });
*/
