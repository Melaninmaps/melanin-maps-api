import type { Response } from "express";

/**
 * Use for responses that change when community tags, verification, listings,
 * map pins, or the member's location context changes. The supplied production
 * logs show 304 responses on map/listing endpoints; no-store removes stale
 * browser/CDN revalidation from this dynamic path until versioned data caching
 * is deliberately implemented.
 */
export function sendDynamicJson(response: Response, payload: unknown, status = 200): Response {
  response.status(status);
  response.setHeader("Cache-Control", "private, no-store, max-age=0");
  response.setHeader("Pragma", "no-cache");
  response.setHeader("Vary", "Authorization, Cookie, X-Community-Location");
  response.removeHeader("ETag");
  return response.json(payload);
}
