import { type Express, type Request, type Response } from "express";

type Queryable = {
  query<T>(sql: string, parameters?: unknown[]): Promise<{ rows: T[] }>;
};

export function registerReleaseStatusRoutes(app: Express, db: Queryable): void {
  app.get("/api/version", (_request: Request, response: Response) => {
    response.setHeader("Cache-Control", "no-store");
    return response.json({
      release: process.env.APP_RELEASE_SHA ?? "unconfigured",
      deployedAt: process.env.APP_DEPLOYED_AT ?? "unconfigured",
    });
  });

  app.get("/api/system/schema-status", async (request: Request, response: Response) => {
    if (!process.env.SCHEMA_STATUS_TOKEN || request.header("x-schema-status-token") !== process.env.SCHEMA_STATUS_TOKEN) {
      return response.status(404).end();
    }
    const { rows } = await db.query<{ filename: string; applied_at: Date }>(
      `SELECT filename, applied_at FROM schema_migrations ORDER BY applied_at DESC LIMIT 10`,
    );
    response.setHeader("Cache-Control", "no-store");
    return response.json({
      release: process.env.APP_RELEASE_SHA ?? "unconfigured",
      migrations: rows,
      expectedDynamicTagMigration: rows.some((row) => row.filename === "20260818_01_schema_compatibility_and_dynamic_tags.sql"),
    });
  });
}
