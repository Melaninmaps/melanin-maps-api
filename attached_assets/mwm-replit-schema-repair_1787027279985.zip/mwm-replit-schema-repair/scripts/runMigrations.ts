import { readdir, readFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import path from "node:path";
import { Client } from "pg";

const migrationsDir = process.env.DATABASE_MIGRATIONS_DIR ?? "./db/migrations";
const lockId = Number(process.env.DATABASE_MIGRATION_LOCK_ID ?? "82420260818");

if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required to run migrations.");
if (!Number.isSafeInteger(lockId)) throw new Error("DATABASE_MIGRATION_LOCK_ID must be a safe integer.");

async function main() {
  const client = new Client({
    connectionString: process.env.DATABASE_URL,
    ssl: process.env.DATABASE_SSL === "true" ? { rejectUnauthorized: false } : undefined,
  });
  await client.connect();

  try {
    await client.query("SELECT pg_advisory_lock($1)", [lockId]);
    await client.query(`
      CREATE TABLE IF NOT EXISTS schema_migrations (
        filename TEXT PRIMARY KEY,
        checksum TEXT NOT NULL,
        applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      )
    `);

    const filenames = (await readdir(migrationsDir))
      .filter((filename) => filename.endsWith(".sql"))
      .sort((left, right) => left.localeCompare(right));

    for (const filename of filenames) {
      const sql = await readFile(path.join(migrationsDir, filename), "utf8");
      const checksum = createHash("sha256").update(sql).digest("hex");
      const existing = await client.query<{ checksum: string }>(
        "SELECT checksum FROM schema_migrations WHERE filename = $1",
        [filename],
      );
      if (existing.rows[0]) {
        if (existing.rows[0].checksum !== checksum) {
          throw new Error(`Migration ${filename} was changed after being applied. Create a new corrective migration instead.`);
        }
        console.log(`Skipped already-applied migration: ${filename}`);
        continue;
      }

      console.log(`Applying migration: ${filename}`);
      await client.query(sql);
      await client.query("INSERT INTO schema_migrations (filename, checksum) VALUES ($1, $2)", [filename, checksum]);
    }
  } finally {
    await client.query("SELECT pg_advisory_unlock($1)", [lockId]).catch(() => undefined);
    await client.end();
  }
}

void main().catch((error) => {
  console.error("Migration failed:", error);
  process.exitCode = 1;
});
