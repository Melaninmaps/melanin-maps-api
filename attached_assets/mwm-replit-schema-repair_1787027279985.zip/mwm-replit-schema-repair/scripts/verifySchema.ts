import { Client } from "pg";

type Requirement = { table: string; column: string };
const requiredColumns: Requirement[] = [
  { table: "reviews", column: "author_id" },
  { table: "business_identity", column: "audience_type" },
  { table: "business_identity", column: "age_restriction_reasons" },
  { table: "business_identity", column: "environment_tags" },
  { table: "business_identity", column: "amenity_tags" },
];
const requiredRelations = [
  "community_locations",
  "community_location_aliases",
  "community_tag_definitions",
  "business_location_contexts",
  "business_location_community_tags",
  "community_tag_submissions",
  "approved_location_community_tags",
];

if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required for schema verification.");

async function main() {
  const client = new Client({
    connectionString: process.env.DATABASE_URL,
    ssl: process.env.DATABASE_SSL === "true" ? { rejectUnauthorized: false } : undefined,
  });
  await client.connect();
  try {
    const columns = await client.query<{ table_name: string; column_name: string }>(
      `SELECT table_name, column_name
       FROM information_schema.columns
       WHERE table_schema = 'public'
         AND (table_name, column_name) IN (${requiredColumns.map((_, index) => `($${index * 2 + 1}, $${index * 2 + 2})`).join(", ")})`,
      requiredColumns.flatMap((requirement) => [requirement.table, requirement.column]),
    );
    const foundColumns = new Set(columns.rows.map((row) => `${row.table_name}.${row.column_name}`));
    const missingColumns = requiredColumns
      .map((requirement) => `${requirement.table}.${requirement.column}`)
      .filter((column) => !foundColumns.has(column));

    const relations = await client.query<{ relation: string }>(
      `SELECT relation FROM unnest($1::text[]) relation WHERE to_regclass('public.' || relation) IS NOT NULL`,
      [requiredRelations],
    );
    const foundRelations = new Set(relations.rows.map((row) => row.relation));
    const missingRelations = requiredRelations.filter((relation) => !foundRelations.has(relation));

    // Directly execute the formerly failing lookup shapes to catch permission or
    // type mistakes before traffic reaches production.
    await client.query("SELECT count(*)::int AS cnt FROM reviews WHERE author_id IS NULL OR author_id IS NOT NULL");
    await client.query("SELECT audience_type, age_restriction_reasons, environment_tags, amenity_tags FROM business_identity LIMIT 1");
    await client.query("SELECT * FROM approved_location_community_tags LIMIT 1");

    if (missingColumns.length || missingRelations.length) {
      throw new Error(`Schema preflight failed. Missing columns: ${missingColumns.join(", ") || "none"}. Missing relations: ${missingRelations.join(", ") || "none"}.`);
    }
    console.log("Schema preflight passed.");
  } finally {
    await client.end();
  }
}

void main().catch((error) => {
  console.error("Schema preflight failed:", error);
  process.exitCode = 1;
});
