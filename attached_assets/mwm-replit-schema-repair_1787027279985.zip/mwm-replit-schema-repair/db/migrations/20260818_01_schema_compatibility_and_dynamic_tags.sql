-- Production-safe, additive PostgreSQL migration.
-- Purpose:
--   1) repair the two missing columns observed in production logs;
--   2) add location-specific, moderated, dynamic community tagging;
--   3) avoid assumptions about the legacy reviews author column.
--
-- Run once through the migration runner. Do not paste into a request handler.

BEGIN;

-- ---------------------------------------------------------------------------
-- A. Compatibility repair: business_identity query currently fails because
--    age_restriction_reasons is absent. All selected fields are made additive
--    so older rows receive empty/default values instead of crashing the API.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS business_identity (
  business_id UUID PRIMARY KEY REFERENCES businesses(id) ON DELETE CASCADE
);

ALTER TABLE business_identity
  ADD COLUMN IF NOT EXISTS audience_type TEXT,
  ADD COLUMN IF NOT EXISTS age_restriction_reasons TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  ADD COLUMN IF NOT EXISTS environment_tags TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  ADD COLUMN IF NOT EXISTS amenity_tags TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[];

-- ---------------------------------------------------------------------------
-- B. Compatibility repair: review code asks for reviews.author_id. Migrate an
--    existing author-like column when one is present; otherwise create a nullable
--    compatibility field and let the application populate it for new reviews.
--    This avoids guessing a foreign-key target in a live system.
-- ---------------------------------------------------------------------------
DO $$
DECLARE
  source_column TEXT;
BEGIN
  IF to_regclass('public.reviews') IS NOT NULL THEN
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.columns
      WHERE table_schema = 'public' AND table_name = 'reviews' AND column_name = 'author_id'
    ) THEN
      ALTER TABLE reviews ADD COLUMN author_id UUID;

      SELECT column_name INTO source_column
      FROM information_schema.columns
      WHERE table_schema = 'public'
        AND table_name = 'reviews'
        AND column_name IN ('user_id', 'member_id', 'reviewer_id', 'created_by')
        AND data_type = 'uuid'
      ORDER BY CASE column_name
        WHEN 'user_id' THEN 1
        WHEN 'member_id' THEN 2
        WHEN 'reviewer_id' THEN 3
        WHEN 'created_by' THEN 4
        ELSE 99
      END
      LIMIT 1;

      IF source_column IS NOT NULL THEN
        EXECUTE format(
          'UPDATE reviews SET author_id = %I WHERE author_id IS NULL',
          source_column
        );
      END IF;
    END IF;

    CREATE INDEX IF NOT EXISTS reviews_author_id_idx ON reviews (author_id);
  END IF;
END $$;

-- ---------------------------------------------------------------------------
-- C. Canonical location records. Tags are contextual: an “Uptown” observation
--    is connected to an explicit city/state/location record, never inferred as
--    global truth from a word alone.
-- ---------------------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS community_locations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  country_code CHAR(2) NOT NULL DEFAULT 'US',
  state_code TEXT,
  city_name TEXT NOT NULL,
  neighborhood_name TEXT,
  neighborhood_slug TEXT,
  latitude NUMERIC(9,6),
  longitude NUMERIC(9,6),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Expression index gives NULL-safe location uniqueness without requiring
-- PostgreSQL 15's UNIQUE NULLS NOT DISTINCT syntax.
CREATE UNIQUE INDEX IF NOT EXISTS community_locations_unique_context_idx
  ON community_locations (
    country_code,
    COALESCE(UPPER(state_code), ''),
    LOWER(city_name),
    COALESCE(LOWER(neighborhood_slug), '')
  );

CREATE INDEX IF NOT EXISTS community_locations_city_idx
  ON community_locations (LOWER(city_name), UPPER(state_code));

CREATE TABLE IF NOT EXISTS community_location_aliases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  location_id UUID NOT NULL REFERENCES community_locations(id) ON DELETE CASCADE,
  alias TEXT NOT NULL,
  moderation_status TEXT NOT NULL DEFAULT 'pending'
    CHECK (moderation_status IN ('approved', 'pending', 'rejected')),
  confidence NUMERIC(3,2) NOT NULL DEFAULT 0.90
    CHECK (confidence >= 0 AND confidence <= 1),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (location_id, alias)
);

CREATE INDEX IF NOT EXISTS community_location_aliases_lookup_idx
  ON community_location_aliases (LOWER(alias))
  WHERE moderation_status = 'approved';

-- ---------------------------------------------------------------------------
-- D. Dynamic tag definitions and per-location listing aggregates.
-- A tag can be proposed dynamically, but is not used for recommendations until
-- it is approved. A listing-tag record is local by design and has its own
-- evidence counts and recency.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS community_tag_definitions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE CHECK (slug ~ '^[a-z0-9]+(?:-[a-z0-9]+)*$'),
  display_name TEXT NOT NULL,
  category TEXT NOT NULL,
  description TEXT NOT NULL,
  recommendation_scope TEXT NOT NULL DEFAULT 'experience'
    CHECK (recommendation_scope IN ('experience', 'service', 'accessibility', 'safety', 'cultural_context')),
  is_medical_claim BOOLEAN NOT NULL DEFAULT FALSE,
  moderation_status TEXT NOT NULL DEFAULT 'pending'
    CHECK (moderation_status IN ('approved', 'pending', 'rejected')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT community_tag_definitions_non_medical_claim CHECK (is_medical_claim = FALSE)
);

CREATE TABLE IF NOT EXISTS business_location_contexts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  location_id UUID NOT NULL REFERENCES community_locations(id) ON DELETE CASCADE,
  is_primary_location BOOLEAN NOT NULL DEFAULT TRUE,
  service_radius_miles NUMERIC(6,2),
  verified_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (business_id, location_id)
);

CREATE INDEX IF NOT EXISTS business_location_contexts_location_idx
  ON business_location_contexts (location_id, business_id);

CREATE TABLE IF NOT EXISTS business_location_community_tags (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_location_context_id UUID NOT NULL REFERENCES business_location_contexts(id) ON DELETE CASCADE,
  tag_id UUID NOT NULL REFERENCES community_tag_definitions(id) ON DELETE RESTRICT,
  confirmed_member_count INTEGER NOT NULL DEFAULT 0 CHECK (confirmed_member_count >= 0),
  recent_confirmed_member_count INTEGER NOT NULL DEFAULT 0 CHECK (recent_confirmed_member_count >= 0),
  confidence NUMERIC(3,2) NOT NULL DEFAULT 0 CHECK (confidence >= 0 AND confidence <= 1),
  moderation_status TEXT NOT NULL DEFAULT 'pending'
    CHECK (moderation_status IN ('approved', 'pending', 'rejected')),
  last_confirmed_at TIMESTAMPTZ,
  last_reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (business_location_context_id, tag_id)
);

CREATE INDEX IF NOT EXISTS business_location_community_tags_recommendation_idx
  ON business_location_community_tags (business_location_context_id, confidence DESC)
  WHERE moderation_status = 'approved';

-- Private submissions are available to the moderation workflow only. The
-- public/API result uses the aggregates above; it never reveals names or raw
-- member feedback in a map card or recommendation.
CREATE TABLE IF NOT EXISTS community_tag_submissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  member_id UUID REFERENCES users(id) ON DELETE SET NULL,
  business_location_context_id UUID NOT NULL REFERENCES business_location_contexts(id) ON DELETE CASCADE,
  tag_id UUID NOT NULL REFERENCES community_tag_definitions(id) ON DELETE RESTRICT,
  evidence_note TEXT,
  status TEXT NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'approved', 'rejected')),
  submitted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  reviewed_at TIMESTAMPTZ,
  reviewed_by UUID REFERENCES users(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS community_tag_submissions_moderation_idx
  ON community_tag_submissions (status, submitted_at DESC);

-- Public lookup view: approved location and tag only, with minimum independent
-- member evidence. This is what the API should use for map/search/Kinfolk.
CREATE OR REPLACE VIEW approved_location_community_tags AS
SELECT
  blc.business_id,
  blc.location_id,
  cl.city_name,
  cl.state_code,
  cl.neighborhood_name,
  ctd.slug AS tag_slug,
  ctd.display_name AS tag_name,
  ctd.category,
  ctd.recommendation_scope,
  blct.confirmed_member_count,
  blct.recent_confirmed_member_count,
  blct.confidence,
  blct.last_confirmed_at
FROM business_location_community_tags blct
JOIN business_location_contexts blc ON blc.id = blct.business_location_context_id
JOIN community_locations cl ON cl.id = blc.location_id
JOIN community_tag_definitions ctd ON ctd.id = blct.tag_id
WHERE blct.moderation_status = 'approved'
  AND ctd.moderation_status = 'approved'
  AND blct.confirmed_member_count >= 3;

-- Seed a safe community-experience definition. It cannot be treated as a
-- medical promise because is_medical_claim is constrained to FALSE.
INSERT INTO community_tag_definitions (
  slug, display_name, category, description, recommendation_scope,
  is_medical_claim, moderation_status
) VALUES (
  'growing-hands',
  'Growing hands',
  'hair-care',
  'Approved community language for a hair-care professional repeatedly described as supporting healthy-feeling hair care. It is not a medical claim or a growth guarantee.',
  'experience',
  FALSE,
  'approved'
) ON CONFLICT (slug) DO UPDATE
SET display_name = EXCLUDED.display_name,
    description = EXCLUDED.description,
    moderation_status = EXCLUDED.moderation_status,
    updated_at = NOW();

COMMIT;
