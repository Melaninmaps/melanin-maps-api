import { useState } from "react";
import { Link } from "react-router-dom";

type Coordinates = { lat: number; lng: number };

type BookstoreDiscoveryResponse = {
  query: string;
  normalizedQuery: string;
  intent: "bookstore";
  radiusMiles: number;
  locationRequired: boolean;
  closestBookstore: {
    id: string;
    name: string;
    detailUrl: string;
    distanceMiles: number;
    city?: string | null;
    state?: string | null;
    addressLine1?: string | null;
    description?: string | null;
  } | null;
  nearbyResultCount: number;
  onlineRecommendation: {
    name: string;
    url: string;
    description: string;
    reason: string;
  } | null;
  message: string;
};

function isBookstoreQuery(value: string): boolean {
  return /\b(bookstore|book\s*-?\s*store|bookshop)\b/i.test(value.trim());
}

function getCurrentCoordinates(): Promise<Coordinates> {
  return new Promise((resolve, reject) => {
    if (!("geolocation" in navigator)) {
      reject(new Error("This browser cannot share location."));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => resolve({ lat: position.coords.latitude, lng: position.coords.longitude }),
      () => reject(new Error("Location was not shared. You can try again whenever you are ready.")),
      { enableHighAccuracy: false, timeout: 10_000, maximumAge: 10 * 60 * 1000 },
    );
  });
}

async function searchClosestBookstore(
  query: string,
  location: Coordinates | null,
): Promise<BookstoreDiscoveryResponse> {
  const params = new URLSearchParams({ q: query });
  if (location) {
    params.set("lat", String(location.lat));
    params.set("lng", String(location.lng));
  }

  const response = await fetch(`/api/directory/bookstores/closest?${params.toString()}`, {
    credentials: "include",
  });
  const payload = (await response.json()) as BookstoreDiscoveryResponse & { error?: string };

  if (!response.ok) throw new Error(payload.error || "Unable to search the directory.");
  return payload;
}

export default function BookstoreDiscoveryPanel({ query }: { query: string }) {
  const [result, setResult] = useState<BookstoreDiscoveryResponse | null>(null);
  const [status, setStatus] = useState<"idle" | "loading" | "error">("idle");
  const [error, setError] = useState<string | null>(null);

  if (!isBookstoreQuery(query)) return null;

  async function runSearch(location: Coordinates | null) {
    try {
      setStatus("loading");
      setError(null);
      setResult(await searchClosestBookstore(query, location));
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Unable to search the directory.");
    } finally {
      setStatus("idle");
    }
  }

  async function shareLocationAndSearch() {
    try {
      setStatus("loading");
      setError(null);
      const location = await getCurrentCoordinates();
      setResult(await searchClosestBookstore(query, location));
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Unable to get your location.");
    } finally {
      setStatus("idle");
    }
  }

  return (
    <section className="mt-6 rounded-2xl border border-amber-900/10 bg-white p-5 shadow-sm" aria-live="polite">
      {!result ? (
        <>
          <h2 className="font-serif text-2xl font-bold">Find the closest bookstore</h2>
          <p className="mt-2 text-sm leading-6 text-neutral-600">
            We use your approximate location only to rank nearby options. We do not show a nationwide list first.
          </p>
          <button
            type="button"
            onClick={() => void runSearch(null)}
            disabled={status === "loading"}
            className="mt-4 rounded-full bg-amber-700 px-5 py-3 font-semibold text-white disabled:opacity-60"
          >
            {status === "loading" ? "Checking directory…" : "Find a bookstore near me"}
          </button>
        </>
      ) : null}

      {result?.locationRequired ? (
        <div className="mt-2">
          <p className="text-sm leading-6 text-neutral-700">{result.message}</p>
          <button
            type="button"
            onClick={() => void shareLocationAndSearch()}
            disabled={status === "loading"}
            className="mt-4 rounded-full bg-amber-700 px-5 py-3 font-semibold text-white disabled:opacity-60"
          >
            {status === "loading" ? "Finding your closest bookstore…" : "Share location and continue"}
          </button>
        </div>
      ) : null}

      {result?.closestBookstore ? (
        <article className="mt-2">
          <p className="text-sm font-semibold text-emerald-700">Closest verified option</p>
          <h2 className="mt-1 font-serif text-2xl font-bold">{result.closestBookstore.name}</h2>
          <p className="mt-2 text-sm text-neutral-700">
            {result.closestBookstore.distanceMiles} miles away
            {result.closestBookstore.city ? ` · ${result.closestBookstore.city}${result.closestBookstore.state ? `, ${result.closestBookstore.state}` : ""}` : ""}
          </p>
          {result.closestBookstore.addressLine1 ? (
            <p className="mt-1 text-sm text-neutral-600">{result.closestBookstore.addressLine1}</p>
          ) : null}
          {result.closestBookstore.description ? (
            <p className="mt-3 text-sm leading-6 text-neutral-700">{result.closestBookstore.description}</p>
          ) : null}
          <Link
            className="mt-4 inline-block rounded-full bg-amber-700 px-5 py-3 font-semibold text-white"
            to={result.closestBookstore.detailUrl}
          >
            View bookstore details
          </Link>
          {result.nearbyResultCount > 1 ? (
            <p className="mt-3 text-sm text-neutral-600">
              {result.nearbyResultCount - 1} additional verified option{result.nearbyResultCount === 2 ? " is" : "s are"} nearby. The closest result remains first.
            </p>
          ) : null}
        </article>
      ) : null}

      {result?.onlineRecommendation ? (
        <article className="mt-2">
          <p className="text-sm font-semibold text-amber-800">No nearby verified community bookstore</p>
          <h2 className="mt-1 font-serif text-2xl font-bold">{result.onlineRecommendation.name}</h2>
          <p className="mt-2 text-sm leading-6 text-neutral-700">{result.onlineRecommendation.reason}</p>
          <p className="mt-2 text-sm leading-6 text-neutral-600">{result.onlineRecommendation.description}</p>
          <a
            className="mt-4 inline-block rounded-full bg-amber-700 px-5 py-3 font-semibold text-white"
            href={result.onlineRecommendation.url}
            target="_blank"
            rel="noreferrer"
          >
            Visit online bookstore
          </a>
        </article>
      ) : null}

      {error ? <p className="mt-4 text-sm text-red-700">{error}</p> : null}
    </section>
  );
}
