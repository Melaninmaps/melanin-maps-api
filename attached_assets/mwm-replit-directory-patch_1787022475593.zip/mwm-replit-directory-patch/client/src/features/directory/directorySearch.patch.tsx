/*
  APPLY THIS PATCH TO THE EXISTING DIRECTORY PAGE.

  It deliberately intercepts a bookstore query before the current
  `/api/search/universal` call. All other directory intents retain their
  current behavior.
*/

import { useState } from "react";
import BookstoreDiscoveryPanel from "./BookstoreDiscoveryPanel";

function isBookstoreQuery(query: string): boolean {
  return /\b(bookstore|book\s*-?\s*store|bookshop)\b/i.test(query.trim());
}

export function DirectoryPage() {
  const [query, setQuery] = useState("");
  const [submittedQuery, setSubmittedQuery] = useState("");
  const [searchMode, setSearchMode] = useState<"default" | "bookstore">("default");

  async function handleSearchSubmit(event: React.FormEvent) {
    event.preventDefault();
    const trimmedQuery = query.trim();
    if (trimmedQuery.length < 2) return;

    setSubmittedQuery(trimmedQuery);

    if (isBookstoreQuery(trimmedQuery)) {
      // Do not call the existing generic/AI universal search for this intent.
      // The panel requests a location and returns only the closest local result.
      setSearchMode("bookstore");
      return;
    }

    setSearchMode("default");
    await runExistingUniversalDirectorySearch(trimmedQuery);
  }

  return (
    <main>
      <form onSubmit={handleSearchSubmit}>
        <label htmlFor="directory-search" className="sr-only">Search the directory</label>
        <input
          id="directory-search"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Try: bookstore, churches in Philadelphia, OBGYN Atlanta"
        />
        <button type="submit">Search</button>
      </form>

      {searchMode === "bookstore" ? (
        <BookstoreDiscoveryPanel key={submittedQuery} query={submittedQuery} />
      ) : (
        <ExistingDirectoryResults />
      )}
    </main>
  );
}

// Keep the current implementation under this name. It should continue to
// handle restaurants, churches, health providers, and named-business queries.
declare function runExistingUniversalDirectorySearch(query: string): Promise<void>;
declare function ExistingDirectoryResults(): JSX.Element;
