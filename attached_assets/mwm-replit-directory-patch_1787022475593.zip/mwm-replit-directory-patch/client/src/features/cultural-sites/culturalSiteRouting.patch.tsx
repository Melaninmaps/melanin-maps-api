/*
  APPLY THESE CHANGES TO THE EXISTING ROUTER AND MAP POPUP COMPONENT.
  The example assumes React Router v6.
*/

// 1) In the application router:
import CulturalSiteDetailsPage from "./CulturalSiteDetailsPage";

// Add this route before the catch-all/not-found route.
<Route path="/cultural-sites/:id/:slug?" element={<CulturalSiteDetailsPage />} />;

// 2) In the map popup/card component, replace any legacy `View Details` link
// such as `/heritage/${site.slug}`, `/map/${site.id}`, or `/cultural/${site.name}`.
import { Link } from "react-router-dom";
import { culturalSiteDetailUrl } from "./CulturalSiteDetailsPage";

type MapCulturalSite = {
  id: string;
  slug: string;
  name: string;
  city?: string | null;
  state?: string | null;
  summary?: string | null;
  detailUrl?: string | null;
};

export function CulturalSiteMapPopup({ site }: { site: MapCulturalSite }) {
  const detailUrl = site.detailUrl || culturalSiteDetailUrl(site);

  return (
    <section className="rounded-lg bg-white p-4 shadow-lg">
      <p className="text-xs font-semibold uppercase tracking-wide text-amber-700">
        Heritage site
      </p>
      <h2 className="mt-1 font-serif text-lg font-bold">{site.name}</h2>
      {site.city ? <p className="text-sm text-neutral-600">{site.city}{site.state ? `, ${site.state}` : ""}</p> : null}
      {site.summary ? <p className="mt-3 line-clamp-3 text-sm text-neutral-700">{site.summary}</p> : null}

      <Link className="mt-4 inline-block font-semibold text-amber-800 underline" to={detailUrl}>
        View details →
      </Link>
    </section>
  );
}

// 3) In every API mapper that returns a cultural site for a map marker or card,
// return the canonical URL as well. The client should prefer this field.
function withCulturalSiteDetailUrl<T extends { id: string; slug: string }>(site: T) {
  return {
    ...site,
    detailUrl: `/cultural-sites/${encodeURIComponent(site.id)}/${encodeURIComponent(site.slug)}`,
  };
}
