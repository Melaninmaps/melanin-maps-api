import { useEffect, useMemo, useState } from "react";
import { Link, useLocation, useNavigate, useParams } from "react-router-dom";

type CulturalSite = {
  id: string;
  slug: string;
  name: string;
  city?: string | null;
  state?: string | null;
  summary?: string | null;
  description?: string | null;
  imageUrl?: string | null;
  websiteUrl?: string | null;
  detailUrl: string;
};

function safeExternalUrl(value: string | null | undefined): string | null {
  if (!value) return null;
  try {
    const url = new URL(value);
    return url.protocol === "https:" || url.protocol === "http:" ? url.toString() : null;
  } catch {
    return null;
  }
}

export function culturalSiteDetailUrl(site: Pick<CulturalSite, "id" | "slug">): string {
  return `/cultural-sites/${encodeURIComponent(site.id)}/${encodeURIComponent(site.slug)}`;
}

export default function CulturalSiteDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const [site, setSite] = useState<CulturalSite | null>(null);
  const [status, setStatus] = useState<"loading" | "ready" | "not-found" | "error">("loading");

  useEffect(() => {
    if (!id) {
      setStatus("not-found");
      return;
    }

    const controller = new AbortController();
    setStatus("loading");

    fetch(`/api/directory/cultural-sites/${encodeURIComponent(id)}`, {
      credentials: "include",
      signal: controller.signal,
    })
      .then(async (response) => {
        if (response.status === 404) {
          setStatus("not-found");
          return null;
        }
        if (!response.ok) throw new Error("Unable to load this cultural site.");
        return (await response.json()) as CulturalSite;
      })
      .then((payload) => {
        if (!payload) return;
        setSite(payload);
        setStatus("ready");

        // Legacy marker paths and manually typed malformed slugs both resolve
        // by ID, then immediately move to this record's canonical URL.
        if (location.pathname !== payload.detailUrl) {
          navigate(payload.detailUrl, { replace: true });
        }
      })
      .catch((error: unknown) => {
        if ((error as { name?: string }).name !== "AbortError") {
          setStatus("error");
        }
      });

    return () => controller.abort();
  }, [id, location.pathname, navigate]);

  const externalLearnMoreUrl = useMemo(() => safeExternalUrl(site?.websiteUrl), [site?.websiteUrl]);

  if (status === "loading") {
    return <main className="p-8 text-center">Loading cultural site…</main>;
  }

  if (status === "not-found") {
    return (
      <main className="p-8 text-center">
        <h1 className="text-3xl font-serif font-bold">Cultural site not found</h1>
        <p className="mt-3 text-neutral-600">This site may be unpublished or the link may be outdated.</p>
        <Link className="mt-6 inline-block underline" to="/map">
          Return to the map
        </Link>
      </main>
    );
  }

  if (status === "error" || !site) {
    return (
      <main className="p-8 text-center">
        <h1 className="text-3xl font-serif font-bold">We could not load this cultural site</h1>
        <p className="mt-3 text-neutral-600">Please return to the map and try again.</p>
        <Link className="mt-6 inline-block underline" to="/map">
          Return to the map
        </Link>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-4xl px-4 py-10">
      <Link className="text-sm underline" to="/map">
        ← Back to map
      </Link>
      {site.imageUrl ? (
        <img className="mt-5 aspect-[16/7] w-full rounded-xl object-cover" src={site.imageUrl} alt="" />
      ) : null}
      <p className="mt-6 text-sm font-semibold uppercase tracking-wide text-amber-700">
        Cultural site{site.city ? ` · ${site.city}${site.state ? `, ${site.state}` : ""}` : ""}
      </p>
      <h1 className="mt-2 text-4xl font-serif font-bold">{site.name}</h1>
      <p className="mt-6 whitespace-pre-line text-lg leading-8 text-neutral-700">
        {site.description || site.summary || "More information about this cultural site is coming soon."}
      </p>
      {externalLearnMoreUrl ? (
        <a
          className="mt-8 inline-block rounded-full bg-amber-700 px-5 py-3 font-semibold text-white"
          href={externalLearnMoreUrl}
          target="_blank"
          rel="noreferrer"
        >
          Learn more on the official site
        </a>
      ) : null}
    </main>
  );
}
