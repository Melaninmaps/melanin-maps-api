import assert from "node:assert/strict";
import {
  discoverClosestBookstore,
  isBookstoreIntent,
  normalizeDirectoryQuery,
} from "./server/directory/bookstoreDiscovery";
import type { DirectoryRepository } from "./server/directory/types";

const recordedSignals: unknown[] = [];
const repository: DirectoryRepository = {
  async findActiveBookstores() {
    return [
      {
        id: "urban-reader",
        name: "Urban Reader Bookstore",
        slug: "urban-reader-bookstore",
        category: "Shopping & Retail",
        subcategory: "Bookstore",
        description: "A community bookstore.",
        tags: ["black-owned"],
        latitude: 35.23,
        longitude: -80.84,
        city: "Charlotte",
        state: "NC",
        isActive: true,
      },
      {
        id: "distant-store",
        name: "Distant Store",
        slug: "distant-store",
        category: "Shopping & Retail",
        subcategory: "Bookshop",
        latitude: 40.71,
        longitude: -74.01,
        city: "New York",
        state: "NY",
        isActive: true,
      },
    ];
  },
  async findVerifiedOnlineBookstores() {
    return [
      {
        id: "approved-online",
        name: "Approved Online Bookstore",
        url: "https://example.test/online",
        description: "A verified online option.",
        priority: 1,
        isVerified: true,
      },
    ];
  },
  async recordDirectorySearchSignal(signal) {
    recordedSignals.push(signal);
  },
  async findPublishedCulturalSiteById() {
    return null;
  },
};

async function main() {
  assert.equal(normalizeDirectoryQuery("  Book   Store "), "book store");
  for (const phrase of ["Book Store", "bookstore", "BOOK-SHOP", "bookshop"]) {
    assert.equal(isBookstoreIntent(phrase), true);
  }

  const charlotteResult = await discoverClosestBookstore(repository, {
    query: "Book Store",
    location: { lat: 35.2271, lng: -80.8431 },
  });
  assert.equal(charlotteResult.closestBookstore?.name, "Urban Reader Bookstore");
  assert.equal(charlotteResult.onlineRecommendation, null);

  const noLocationResult = await discoverClosestBookstore(repository, {
    query: "Bookstore",
    location: null,
  });
  assert.equal(noLocationResult.locationRequired, true);
  assert.equal(noLocationResult.onlineRecommendation, null);

  const fallbackResult = await discoverClosestBookstore(repository, {
    query: "Bookshop",
    location: { lat: 29.7604, lng: -95.3698 },
    radiusMiles: 10,
  });
  assert.equal(fallbackResult.closestBookstore, null);
  assert.equal(fallbackResult.onlineRecommendation?.name, "Approved Online Bookstore");
  assert.ok(recordedSignals.length >= 2);

  console.log("Bookstore discovery smoke test passed.");
}

void main();
