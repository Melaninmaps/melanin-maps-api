-- PostgreSQL migration: location-first bookstore discovery and directory coverage.
-- Apply through the Replit project's normal migration command.

CREATE TABLE IF NOT EXISTS online_bookstores (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  url TEXT NOT NULL,
  description TEXT NOT NULL,
  priority INTEGER NOT NULL DEFAULT 100,
  is_verified BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT online_bookstores_url_unique UNIQUE (url)
);

-- Keep only coarse, non-identifying search telemetry. Do not store a member ID,
-- raw IP address, street address, or exact latitude/longitude in this table.
CREATE TABLE IF NOT EXISTS directory_search_signals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  intent TEXT NOT NULL CHECK (intent IN ('bookstore')),
  normalized_query TEXT NOT NULL,
  outcome TEXT NOT NULL CHECK (outcome IN ('nearby_match', 'online_fallback', 'location_required')),
  location_cell TEXT,
  nearest_distance_miles NUMERIC(6,1),
  nearby_result_count INTEGER NOT NULL DEFAULT 0,
  radius_miles INTEGER NOT NULL,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS directory_search_signals_bookstore_gap_idx
  ON directory_search_signals (intent, outcome, occurred_at DESC, location_cell)
  WHERE outcome = 'online_fallback';

-- Location columns must exist and be populated for any place that should be
-- eligible for a "closest to you" result. Adjust table/column names only if
-- the existing Replit schema uses different names.
ALTER TABLE businesses
  ADD COLUMN IF NOT EXISTS latitude DOUBLE PRECISION,
  ADD COLUMN IF NOT EXISTS longitude DOUBLE PRECISION;

CREATE INDEX IF NOT EXISTS businesses_active_coordinates_idx
  ON businesses (is_active, latitude, longitude)
  WHERE is_active = TRUE AND latitude IS NOT NULL AND longitude IS NOT NULL;

-- Seed only sources that have been editorially verified by your team.
-- Replace the illustrative values below with approved partners before running.
-- INSERT INTO online_bookstores (name, url, description, priority, is_verified)
-- VALUES (
--   'Approved Online Bookstore',
--   'https://example.org',
--   'A verified online option recommended when no community bookstore is nearby.',
--   10,
--   TRUE
-- )
-- ON CONFLICT (url) DO UPDATE
-- SET name = EXCLUDED.name,
--     description = EXCLUDED.description,
--     priority = EXCLUDED.priority,
--     is_verified = EXCLUDED.is_verified,
--     updated_at = NOW();
