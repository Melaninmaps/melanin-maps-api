/*
  APPLY AFTER every `/api/...` route has been registered and AFTER static files
  are served. This prevents direct visits or refreshes to
  `/cultural-sites/:id/:slug` from receiving a server-side 404.
*/

import path from "node:path";
import express, { type Express } from "express";

export function registerSpaFallback(app: Express): void {
  const clientDist = path.resolve(process.cwd(), "client", "dist");

  // Keep assets and API routes on their native handlers.
  app.use(express.static(clientDist));

  // Express 5-safe catch-all for browser routes only. The React router then
  // resolves the cultural-site details component from the canonical URL.
  app.get(/^\/(?!api\/).*/, (_request, response) => {
    response.sendFile(path.join(clientDist, "index.html"));
  });
}

/*
  In the main server file, the final setup order must be:

  registerDirectoryRoutes(app, directoryRepository);
  registerExistingApiRoutes(app);
  registerSpaFallback(app); // always last
*/
