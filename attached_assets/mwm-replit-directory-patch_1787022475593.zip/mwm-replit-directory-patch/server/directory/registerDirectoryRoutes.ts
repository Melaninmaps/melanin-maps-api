import { Router, type Request, type Response } from "express";
import {
  DEFAULT_BOOKSTORE_RADIUS_MILES,
  discoverClosestBookstore,
  isBookstoreIntent,
} from "./bookstoreDiscovery";
import type { Coordinates, DirectoryRepository } from "./types";

function optionalFiniteNumber(value: unknown): number | null {
  if (typeof value !== "string" || value.trim() === "") return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function parseLocation(query: Request["query"]): Coordinates | null {
  const lat = optionalFiniteNumber(query.lat);
  const lng = optionalFiniteNumber(query.lng);

  if (lat === null && lng === null) return null;
  if (lat === null || lng === null) {
    throw new Error("Send both lat and lng, or omit both to request location permission.");
  }

  return { lat, lng };
}

function parseRadius(query: Request["query"]): number {
  const requested = optionalFiniteNumber(query.radiusMiles);
  if (requested === null) return DEFAULT_BOOKSTORE_RADIUS_MILES;

  // A bounded radius prevents accidental nationwide dumps while allowing a
  // member to deliberately broaden an initially empty local result.
  return Math.min(Math.max(Math.round(requested), 5), 100);
}

function getRequiredQueryString(query: Request["query"], key: string): string {
  const value = query[key];
  if (typeof value !== "string" || value.trim().length < 2) {
    throw new Error(`A ${key} query parameter with at least two characters is required.`);
  }
  return value;
}

export function registerDirectoryRoutes(app: Router, repository: DirectoryRepository): void {
  /**
   * Dedicated directory route. The directory page calls this directly for
   * bookstore intent instead of sending the query to a generic/AI-only search.
   * Kinfolk can use the same route behind the scenes, but the response remains
   * a normal directory result, not a chat result.
   */
  app.get("/api/directory/bookstores/closest", async (req: Request, res: Response) => {
    try {
      const q = getRequiredQueryString(req.query, "q");
      if (!isBookstoreIntent(q)) {
        return res.status(422).json({
          error: "This endpoint is only for bookstore searches.",
          code: "UNSUPPORTED_DIRECTORY_INTENT",
        });
      }

      const result = await discoverClosestBookstore(repository, {
        query: q,
        location: parseLocation(req.query),
        radiusMiles: parseRadius(req.query),
      });

      return res.status(200).json(result);
    } catch (error) {
      return res.status(400).json({
        error: error instanceof Error ? error.message : "Invalid bookstore search request.",
        code: "INVALID_DIRECTORY_SEARCH",
      });
    }
  });

  /**
   * The single canonical source for a cultural-site detail link. The client
   * must always use `detailUrl` from this response rather than hand-building a
   * path from the display name or a legacy map marker property.
   */
  app.get("/api/directory/cultural-sites/:id", async (req: Request, res: Response) => {
    const culturalSite = await repository.findPublishedCulturalSiteById(req.params.id);

    if (!culturalSite) {
      return res.status(404).json({
        error: "Cultural site not found.",
        code: "CULTURAL_SITE_NOT_FOUND",
      });
    }

    return res.status(200).json({
      ...culturalSite,
      detailUrl: `/cultural-sites/${encodeURIComponent(culturalSite.id)}/${encodeURIComponent(
        culturalSite.slug,
      )}`,
    });
  });
}
