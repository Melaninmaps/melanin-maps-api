# Kinfolk Live Regression Fix Package

This package was created after inspecting the user-reported production regressions on Mapping With Melanin.

## What is confirmed

The deployed client turns every HTTP `413` response from `/api/kinfolk/transcribe` into a false “over 60 seconds” message. The client sends base64 audio inside JSON and does not provide verified duration to the API. The fix separates actual duration from byte-size/upload failures and uses multipart binary upload.

The deployed browser sends `Tell me about Philly nightlife` unchanged to `/api/kinfolk/chat`. The missing-location response is therefore created by backend local-intent resolution or its tool/prompt flow. The fix requires deterministic resolution of `Philly → Philadelphia, PA` before any clarification logic, then community-primary local retrieval.

## Included files

| File | Purpose |
| --- | --- |
| `REPLIT_PRECISION_FIX_SCRIPT.md` | The exact instruction to paste into Replit Agent. It includes required server/client changes and release tests. |
| `src/audio-guardrails.ts` | Reference implementation for duration, byte-size, and error-classification safeguards. |
| `src/local-intent.ts` | Reference implementation for Philadelphia aliases and community-primary local search planning. |
| `test/live-regression.test.ts` | Eight executable guardrail tests. |

## Verification result

`npm run typecheck && npm test` completed successfully: **8 of 8 tests passed**.

## Important deployment boundary

This package is a precise patch specification and a testable reference implementation. It is not yet applied to the production Mapping With Melanin/Replit project because that project was not attached for editing. After Replit applies the patch, rerun the real authenticated production checks named in the precision script, including a verified two-second recording and `Tell me about Philly nightlife`.
