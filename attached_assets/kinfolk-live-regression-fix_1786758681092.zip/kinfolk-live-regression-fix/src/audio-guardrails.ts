export const MAX_VOICE_DURATION_MS = 60_000;
export const MAX_VOICE_BYTES = 4 * 1024 * 1024;

export type VoiceProblemCode =
  | "AUDIO_DURATION_EXCEEDED"
  | "AUDIO_PAYLOAD_TOO_LARGE"
  | "AUDIO_UNREADABLE"
  | "AUDIO_TRANSCRIPTION_UNAVAILABLE";

export type VoicePreflight =
  | { ok: true }
  | { ok: false; code: VoiceProblemCode; message: string };

/**
 * Use elapsed wall-clock recording time as the canonical client duration. Do
 * not convert milliseconds to seconds more than once and do not infer time
 * from payload size. A byte limit and a duration limit are distinct checks.
 */
export function validateVoicePreflight(durationMs: number, byteSize: number): VoicePreflight {
  if (!Number.isFinite(durationMs) || durationMs < 0) {
    return { ok: false, code: "AUDIO_UNREADABLE", message: "Kinfolk could not verify this recording. Please try again." };
  }
  if (durationMs > MAX_VOICE_DURATION_MS) {
    return {
      ok: false,
      code: "AUDIO_DURATION_EXCEEDED",
      message: "That recording is over 60 seconds. Please send a shorter clip."
    };
  }
  if (byteSize > MAX_VOICE_BYTES) {
    return {
      ok: false,
      code: "AUDIO_PAYLOAD_TOO_LARGE",
      message: "This voice clip is too large to upload. Please try a shorter or lower-quality recording."
    };
  }
  return { ok: true };
}

export type RecordingSession = {
  startedAtMs: number;
  chunks: BlobPart[];
  mimeType: string;
};

/**
 * Create this only after MediaRecorder.start(). Keep it in the current-recording
 * ref, clear it in finally, and never reuse it for the next recording.
 */
export function startRecordingSession(mimeType: string, nowMs = performance.now()): RecordingSession {
  return { startedAtMs: nowMs, chunks: [], mimeType };
}

export function finishRecordingSession(session: RecordingSession, nowMs = performance.now()): {
  blob: Blob;
  durationMs: number;
} {
  const durationMs = Math.max(0, Math.round(nowMs - session.startedAtMs));
  return { blob: new Blob(session.chunks, { type: session.mimeType }), durationMs };
}

export function safeVoiceError(status: number, body: unknown): { code: VoiceProblemCode; message: string } {
  const data = typeof body === "object" && body !== null ? (body as { code?: string }) : {};
  if (data.code === "AUDIO_DURATION_EXCEEDED") {
    return { code: "AUDIO_DURATION_EXCEEDED", message: "That recording is over 60 seconds. Please send a shorter clip." };
  }
  if (data.code === "AUDIO_PAYLOAD_TOO_LARGE") {
    return {
      code: "AUDIO_PAYLOAD_TOO_LARGE",
      message: "This voice clip is too large to upload. Please try a shorter or lower-quality recording."
    };
  }
  if (status === 413) {
    return {
      code: "AUDIO_PAYLOAD_TOO_LARGE",
      message: "Kinfolk could not upload this voice clip because the request was too large. It was not classified as a duration limit."
    };
  }
  if (status === 400 || data.code === "AUDIO_UNREADABLE") {
    return { code: "AUDIO_UNREADABLE", message: "Kinfolk could not read that audio. Please try again or type your question." };
  }
  return {
    code: "AUDIO_TRANSCRIPTION_UNAVAILABLE",
    message: "Voice transcription is unavailable right now. You can still type your question."
  };
}

/**
 * Replaces base64-in-JSON. FormData avoids base64 expansion and lets the server
 * enforce byte and duration limits separately. Do not set Content-Type manually;
 * the browser supplies the multipart boundary.
 */
export async function submitVoiceClip(
  endpoint: string,
  blob: Blob,
  durationMs: number,
  fetchImpl: typeof fetch = fetch
): Promise<{ ok: true; text: string } | { ok: false; code: VoiceProblemCode; message: string }> {
  const preflight = validateVoicePreflight(durationMs, blob.size);
  if (!preflight.ok) return preflight;

  const form = new FormData();
  form.append("audio", blob, `kinfolk-voice.${blob.type.includes("mp4") ? "m4a" : "webm"}`);
  form.append("durationMs", String(Math.round(durationMs)));
  form.append("mimeType", blob.type || "audio/webm");

  const response = await fetchImpl(endpoint, { method: "POST", credentials: "include", body: form });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) return { ok: false, ...safeVoiceError(response.status, body) };

  const text = typeof body.text === "string" ? body.text.trim() : "";
  if (!text) return { ok: false, code: "AUDIO_UNREADABLE", message: "Kinfolk could not hear words in that clip. Please try again or type your question." };
  return { ok: true, text };
}
