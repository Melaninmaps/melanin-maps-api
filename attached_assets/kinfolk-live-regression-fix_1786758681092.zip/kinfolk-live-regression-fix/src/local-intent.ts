export type CommunityLens = {
  id: string;
  label: string;
  searchTerms: string[];
  priority: number;
};

export type Location = {
  city: string;
  state: string;
  country: "US";
  source: "explicit" | "alias" | "session";
};

export type LocalDiscoveryPlan = {
  kind: "local_discovery";
  category: "nightlife" | "dining" | "events" | "beauty" | "wellness" | "general";
  location?: Location;
  needsLocationClarification: boolean;
  communityQueries: string[];
  evidenceQueries: string[];
  systemDirective: string;
};

const CITY_ALIASES: Array<{ pattern: RegExp; location: Omit<Location, "source">; source: Location["source"] }> = [
  {
    pattern: /\b(?:philly|philadelphia)(?:\s*,?\s*(?:pa|pennsylvania))?\b/i,
    location: { city: "Philadelphia", state: "PA", country: "US" },
    source: "alias"
  },
  {
    pattern: /\b(?:nyc|new york city)(?:\s*,?\s*(?:ny|new york))?\b/i,
    location: { city: "New York", state: "NY", country: "US" },
    source: "alias"
  },
  {
    pattern: /\b(?:dc|d\.c\.|washington dc|washington,? d\.c\.)\b/i,
    location: { city: "Washington", state: "DC", country: "US" },
    source: "alias"
  }
];

const NIGHTLIFE = /\b(nightlife|club(?:s)?|bar(?:s)?|lounge(?:s)?|party|parties|late[- ]night|happy hour|music venue(?:s)?)\b/i;
const DINING = /\b(restaurant(?:s)?|food|dining|brunch|dinner|lunch|breakfast)\b/i;
const EVENTS = /\b(event(?:s)?|tonight|this weekend|concert(?:s)?|festival(?:s)?|show(?:s)?)\b/i;
const BEAUTY = /\b(beauty|hair|barber|nails|salon|spa)\b/i;
const WELLNESS = /\b(wellness|fitness|gym|yoga|therapy|health)\b/i;

function normalize(text: string): string {
  return text.toLowerCase().trim().replace(/\s+/g, " ");
}

export function extractLocation(message: string, sessionLocation?: Location): Location | undefined {
  for (const alias of CITY_ALIASES) {
    if (alias.pattern.test(message)) return { ...alias.location, source: alias.source };
  }
  return sessionLocation ? { ...sessionLocation, source: "session" } : undefined;
}

export function classifyLocalCategory(message: string): LocalDiscoveryPlan["category"] {
  if (NIGHTLIFE.test(message)) return "nightlife";
  if (DINING.test(message)) return "dining";
  if (EVENTS.test(message)) return "events";
  if (BEAUTY.test(message)) return "beauty";
  if (WELLNESS.test(message)) return "wellness";
  return "general";
}

export function isLocalDiscoveryIntent(message: string): boolean {
  return Boolean(
    NIGHTLIFE.test(message) ||
      DINING.test(message) ||
      EVENTS.test(message) ||
      BEAUTY.test(message) ||
      WELLNESS.test(message) ||
      /\b(?:near me|nearby|in [a-z]+)\b/i.test(message)
  );
}

function orderedActiveLenses(lenses: CommunityLens[]): CommunityLens[] {
  return [...lenses].sort((a, b) => a.priority - b.priority);
}

/**
 * Local queries start with community relevance. This changes retrieval order;
 * it does not infer a person's identity or exclude other worthwhile results.
 */
export function buildLocalDiscoveryPlan(
  message: string,
  activeLenses: CommunityLens[],
  sessionLocation?: Location
): LocalDiscoveryPlan | undefined {
  if (!isLocalDiscoveryIntent(message)) return undefined;

  const category = classifyLocalCategory(message);
  const location = extractLocation(message, sessionLocation);
  const cityPhrase = location ? `${location.city}, ${location.state}` : "";
  const lenses = orderedActiveLenses(activeLenses);

  if (!location) {
    return {
      kind: "local_discovery",
      category,
      needsLocationClarification: true,
      communityQueries: [],
      evidenceQueries: [],
      systemDirective:
        "No city, neighborhood, metro, or remembered session location was resolved. Ask one concise location question; do not ask for a community preference that is already available in the active profile."
    };
  }

  const communityQueries = lenses.flatMap((lens) => [
    `${lens.label} ${category} in ${cityPhrase}`,
    `${category} in ${cityPhrase} ${lens.searchTerms[0] ?? lens.label} community owned`
  ]);
  const defaultCommunityQuery = `community-owned ${category} in ${cityPhrase} Black and diaspora cultural scene`;

  return {
    kind: "local_discovery",
    category,
    location,
    needsLocationClarification: false,
    communityQueries: communityQueries.length ? communityQueries : [defaultCommunityQuery],
    evidenceQueries: [`best ${category} in ${cityPhrase}`, `${category} events in ${cityPhrase} official listings`],
    systemDirective:
      "A deterministic city resolver found a valid location. Never claim location is missing and never ask the member to repeat it. Run community-primary local retrieval first, then general/official retrieval. Lead with culturally relevant results supported by credible sources, include links and current hours/event dates when available, and state uncertainty when availability cannot be verified."
  };
}

export function debugLocationToken(message: string): string {
  return `${normalize(message)} → ${extractLocation(message)?.city ?? "UNRESOLVED"}`;
}
