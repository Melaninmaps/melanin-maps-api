# Replit Precision Fix Script — Kinfolk Live Regression

> **Copy this entire instruction into Replit Agent in the Mapping With Melanin project. Do not redesign the interface, replace the Kinfolk product behavior, or return a summary before the tests pass. First inspect the existing deployed routes and components, then make the smallest safe patch that satisfies every acceptance test below.**

## Mission

Fix two production regressions immediately.

1. A roughly two-second voice recording is receiving HTTP `413` and the client falsely tells the member it is “over 60 seconds.”
2. `Tell me about Philly nightlife` is treated as locationless even though `Philly` is an unambiguous alias for Philadelphia, Pennsylvania. Kinfolk then asks the member to repeat a city instead of searching.

The product rule remains unchanged: **Kinfolk is community-primary by default.** An explicit member profile changes retrieval and ranking before search. A member should not have to add `Black-owned`, `Mexican-owned`, or similar phrasing after the application already knows their active community lens.

## Non-negotiable diagnosis to preserve

The currently deployed client does this:

```ts
// Current anti-pattern — remove it.
const base64 = btoa(binaryAudioString);
await fetch('/api/kinfolk/transcribe', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ audio: base64, format })
});

// Current false claim — remove it.
if (response.status === 413) {
  showMessage('That clip is too long — try under 60 seconds.');
}
```

**Why this is wrong:** `413` means the request or payload was rejected as too large. It does **not** prove that a recording exceeded 60 seconds. Base64-in-JSON increases request size, and a proxy/body-size limit can reject a two-second clip. Only a verified duration check may produce an `AUDIO_DURATION_EXCEEDED` message.

## Required implementation changes

### A. Replace base64 JSON audio upload with multipart binary upload

Locate the component that calls `/api/kinfolk/transcribe`. Replace its blob-to-array-buffer-to-base64 loop with this behavior:

```ts
const MAX_VOICE_DURATION_MS = 60_000;
const MAX_VOICE_BYTES = 4 * 1024 * 1024;

const recordingStartedAtRef = useRef<number | null>(null);
const recordingSessionRef = useRef<{ chunks: BlobPart[]; mimeType: string } | null>(null);

function classifyVoiceError(status: number, body: { code?: string } | undefined) {
  if (body?.code === 'AUDIO_DURATION_EXCEEDED') {
    return 'That recording is over 60 seconds. Please send a shorter clip.';
  }
  if (body?.code === 'AUDIO_PAYLOAD_TOO_LARGE' || status === 413) {
    return 'This voice clip is too large to upload. Please try a shorter or lower-quality recording.';
  }
  if (body?.code === 'AUDIO_UNREADABLE' || status === 400) {
    return "Kinfolk could not read that audio. Please try again or type your question.";
  }
  return 'Voice transcription is unavailable right now. You can still type your question.';
}

async function uploadVoiceClip(blob: Blob, durationMs: number) {
  // Duration and bytes are two independent controls.
  if (durationMs > MAX_VOICE_DURATION_MS) {
    return { ok: false, message: 'That recording is over 60 seconds. Please send a shorter clip.' };
  }
  if (blob.size > MAX_VOICE_BYTES) {
    return { ok: false, message: 'This voice clip is too large to upload. Please try a shorter or lower-quality recording.' };
  }

  const form = new FormData();
  form.append('audio', blob, blob.type.includes('mp4') ? 'kinfolk-voice.m4a' : 'kinfolk-voice.webm');
  form.append('durationMs', String(Math.round(durationMs)));
  form.append('mimeType', blob.type || 'audio/webm');

  // Do not manually set Content-Type; the browser must add the multipart boundary.
  const response = await fetch('/api/kinfolk/transcribe', {
    method: 'POST',
    credentials: 'include',
    body: form
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) return { ok: false, message: classifyVoiceError(response.status, body) };
  return { ok: true, text: String(body.text ?? '').trim() };
}
```

When recording starts, save `performance.now()` to `recordingStartedAtRef.current` and create a new, empty `recordingSessionRef.current`. When recording stops, calculate duration exactly once:

```ts
const durationMs = Math.max(0, Math.round(performance.now() - (recordingStartedAtRef.current ?? performance.now())));
const session = recordingSessionRef.current;
const blob = new Blob(session?.chunks ?? [], { type: session?.mimeType || 'audio/webm' });

try {
  const result = await uploadVoiceClip(blob, durationMs);
  // Keep existing transcription/UI flow here.
} finally {
  // This prevents chunks or timers from a previous recording contaminating the next recording.
  recordingStartedAtRef.current = null;
  recordingSessionRef.current = null;
  clearInterval(recordingTimerRef.current ?? undefined);
  recordingTimerRef.current = null;
}
```

Keep a visible countdown or timer for the user if desired, but **do not use the UI counter as the server-policy source of truth**. The duration passed to upload must be one canonical value in milliseconds.

### B. Make the transcription API return distinct machine-readable errors

Change `POST /api/kinfolk/transcribe` to consume multipart audio. Use the project’s existing upload middleware or add a controlled multipart parser. The exact library is your choice, but the response contract below is mandatory.

```ts
const MAX_VOICE_DURATION_MS = 60_000;
const MAX_VOICE_BYTES = 4 * 1024 * 1024;

app.post('/api/kinfolk/transcribe', requireMember, upload.single('audio'), async (req, res) => {
  const durationMs = Number(req.body.durationMs);
  const audio = req.file;
  const requestId = crypto.randomUUID();

  if (!audio || !Number.isFinite(durationMs) || durationMs < 0) {
    return res.status(400).json({ code: 'AUDIO_UNREADABLE', requestId });
  }
  if (durationMs > MAX_VOICE_DURATION_MS) {
    return res.status(422).json({ code: 'AUDIO_DURATION_EXCEEDED', durationMs, requestId });
  }
  if (audio.size > MAX_VOICE_BYTES) {
    return res.status(413).json({ code: 'AUDIO_PAYLOAD_TOO_LARGE', byteSize: audio.size, requestId });
  }

  try {
    const text = await transcribeBinaryAudio({
      bytes: audio.buffer,
      mimeType: req.body.mimeType || audio.mimetype,
      filename: audio.originalname
    });
    return res.json({ text, durationMs, byteSize: audio.size, requestId });
  } catch (error) {
    log.error({ requestId, durationMs, byteSize: audio.size, error }, 'kinfolk_transcribe_failed');
    return res.status(502).json({ code: 'AUDIO_TRANSCRIPTION_UNAVAILABLE', requestId });
  }
});
```

If the host, reverse proxy, or framework rejects oversized requests before this route runs, raise its multipart body allowance slightly above `MAX_VOICE_BYTES` (for example, 6 MB) **and keep the 4 MB application limit**. This ensures Kinfolk, not an opaque proxy, returns the machine-readable error. Log `requestId`, `content-length`, decoded `byteSize`, client-reported `durationMs`, status, and the component that rejected the request. Never log the raw audio.

### C. Resolve city aliases before any “location missing” response

Locate the server code that handles `POST /api/kinfolk/chat`, local-business intent, and the prompt/tool decision that currently emits “I need a location first.” Add deterministic location resolution **before** model prompting, tool selection, or clarification logic.

```ts
type ResolvedLocation = {
  city: string;
  state: string;
  country: 'US';
  source: 'alias' | 'explicit' | 'session';
};

const CITY_ALIASES: Array<{ pattern: RegExp; city: string; state: string }> = [
  { pattern: /\b(?:philly|philadelphia)(?:\s*,?\s*(?:pa|pennsylvania))?\b/i, city: 'Philadelphia', state: 'PA' },
  { pattern: /\b(?:nyc|new york city)(?:\s*,?\s*(?:ny|new york))?\b/i, city: 'New York', state: 'NY' },
  { pattern: /\b(?:dc|d\.c\.|washington dc|washington,? d\.c\.)\b/i, city: 'Washington', state: 'DC' }
];

function resolveLocation(message: string, sessionLocation?: ResolvedLocation): ResolvedLocation | undefined {
  for (const alias of CITY_ALIASES) {
    if (alias.pattern.test(message)) {
      return { city: alias.city, state: alias.state, country: 'US', source: 'alias' };
    }
  }
  return sessionLocation ? { ...sessionLocation, source: 'session' } : undefined;
}

function localCategory(message: string) {
  if (/\b(nightlife|club(?:s)?|bar(?:s)?|lounge(?:s)?|party|parties|late[- ]night|happy hour|music venue(?:s)?)\b/i.test(message)) return 'nightlife';
  if (/\b(restaurant(?:s)?|food|dining|brunch|dinner|lunch|breakfast)\b/i.test(message)) return 'dining';
  if (/\b(event(?:s)?|tonight|this weekend|concert(?:s)?|festival(?:s)?|show(?:s)?)\b/i.test(message)) return 'events';
  return 'general';
}
```

### D. Replace the missing-location gate with this exact decision order

```ts
const location = resolveLocation(message, session.lastResolvedLocation);
const category = localCategory(message);
const isLocalIntent = category !== 'general' || /\b(near me|nearby)\b/i.test(message);

if (isLocalIntent && location) {
  // Save this for the next turn, but do not overwrite an explicit city in a later message.
  await saveSessionLocation(session.id, location);

  const activeLenses = getActiveCommunityLenses(member.profile); // explicit profile only
  const communityQueries = activeLenses.length
    ? activeLenses.sort((a, b) => a.priority - b.priority).flatMap((lens) => [
        `${lens.label} ${category} in ${location.city}, ${location.state}`,
        `${category} in ${location.city}, ${location.state} ${lens.searchTerms[0] ?? lens.label} community owned`
      ])
    : [`community-owned ${category} in ${location.city}, ${location.state} Black and diaspora cultural scene`];

  const evidenceQueries = [
    `best ${category} in ${location.city}, ${location.state}`,
    `${category} events in ${location.city}, ${location.state} official listings`
  ];

  const results = await searchAndRankLocal({
    city: location.city,
    state: location.state,
    category,
    communityQueries,
    evidenceQueries,
    activeLenses
  });

  log.info({
    event: 'kinfolk_local_resolution',
    message,
    intentClass: 'local_discovery',
    city: location.city,
    state: location.state,
    locationSource: location.source,
    category,
    activeLensIds: activeLenses.map((lens) => lens.id),
    resultCount: results.length
  });

  return res.json({
    reply: await composeLocalAnswer({ message, location, category, activeLenses, results }),
    recommendations: results,
    intentClass: 'local_discovery',
    location,
    locationSource: location.source
  });
}

if (isLocalIntent && !location) {
  // This is the only permitted missing-location question.
  return res.json({
    reply: 'Which city, neighborhood, or metro area should I use?',
    intentClass: 'local_discovery_needs_location'
  });
}
```

### E. Enforce Kinfolk’s response rules for city-known local discovery

Add this instruction to the local-answer composer/system prompt:

```text
When `intentClass=local_discovery` and a resolved location is present, the location is valid. Never say you need a city, neighborhood, or metro area. Do not ask the member to repeat it.

Lead with the active explicit community lenses in retrieval and ranking. For a member whose profile contains `Black woman`, a query for `Philly nightlife` must search and surface Black cultural, Black-owned, and diaspora-relevant nightlife context before generic city nightlife sources, while retaining current/official information for hours and event dates. If no explicit lens is active, Kinfolk still begins with community-centered discovery rather than asking whether the member wants minority-owned results.

Return practical results with source links. If live availability cannot be verified, say that clearly. Do not fabricate venues, hours, ownership, events, or dates.
```

## Mandatory tests — write and run these before deployment

Do not mark this task complete until all tests pass.

```ts
it('resolves Philly before the missing-location gate', async () => {
  const response = await chat({ message: 'Tell me about Philly nightlife', profile: blackWomanProfile });
  expect(response.intentClass).toBe('local_discovery');
  expect(response.location).toMatchObject({ city: 'Philadelphia', state: 'PA', source: 'alias' });
  expect(response.reply).not.toMatch(/need a location|what city|what neighborhood|what metro/i);
  expect(response.recommendations.length).toBeGreaterThan(0);
  expect(response.searchPlan.communityQueries[0]).toMatch(/Black woman.*nightlife.*Philadelphia/i);
});

it('does not ask again when a city appears in the user message', async () => {
  const response = await chat({ message: 'Any late-night places in Philadelphia?', profile: blackWomanProfile });
  expect(response.intentClass).toBe('local_discovery');
  expect(response.location.city).toBe('Philadelphia');
  expect(response.reply).not.toMatch(/need a location/i);
});

it('asks for a city only when no city or saved session location can be resolved', async () => {
  const response = await chat({ message: 'Tell me about nightlife', profile: blackWomanProfile });
  expect(response.intentClass).toBe('local_discovery_needs_location');
  expect(response.reply).toMatch(/which city, neighborhood, or metro area/i);
});

it('does not falsely call a 2-second recording over 60 seconds', async () => {
  const result = validateVoicePreflight(2_000, 18_000);
  expect(result).toEqual({ ok: true });
});

it('returns a duration message only after an actual duration violation', async () => {
  const result = validateVoicePreflight(60_001, 18_000);
  expect(result).toMatchObject({ ok: false, code: 'AUDIO_DURATION_EXCEEDED' });
  expect(result.message).toMatch(/over 60 seconds/i);
});

it('distinguishes payload size from duration', async () => {
  const result = validateVoicePreflight(2_000, 4 * 1024 * 1024 + 1);
  expect(result).toMatchObject({ ok: false, code: 'AUDIO_PAYLOAD_TOO_LARGE' });
  expect(result.message).not.toMatch(/60 seconds/i);
});

it('does not reinterpret a bare proxy 413 as a duration violation', async () => {
  expect(classifyVoiceError(413, {})).toMatch(/too large to upload/i);
  expect(classifyVoiceError(413, {})).not.toMatch(/over 60 seconds/i);
});
```

## Manual release checklist

| Test | Required result |
| --- | --- |
| Text: `Tell me about Philly nightlife` | Kinfolk recognizes Philadelphia, searches immediately, and returns local nightlife information. It does **not** ask for a city. |
| Text: `Black-owned nightlife in Philly` | Kinfolk recognizes Philadelphia and leads with Black-owned/Black cultural results backed by sources. |
| Text: `Tell me about nightlife` with no saved city | Kinfolk asks one concise location question. |
| Voice: verified 2-second recording | No “over 60 seconds” message. If upload fails, the message accurately refers to payload/upload/readability, with a request ID in server logs. |
| Voice: 61-second recording | Client blocks or server returns `AUDIO_DURATION_EXCEEDED`; only then does Kinfolk state the 60-second limit. |
| Voice: oversized binary under 60 seconds | Returns `AUDIO_PAYLOAD_TOO_LARGE`; never claims it is over 60 seconds. |

## Completion rule

Return the exact changed files, the test output, and the deployed build identifier. Do not state that the regression is fixed until the real deployed site passes the two text checks and the two-second voice recording check.
