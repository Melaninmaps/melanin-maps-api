import assert from "node:assert/strict";
import test from "node:test";
import { safeVoiceError, validateVoicePreflight } from "../src/audio-guardrails.js";
import { buildLocalDiscoveryPlan } from "../src/local-intent.js";

const blackWomanLens = {
  id: "black-woman",
  label: "Black woman",
  searchTerms: ["Black women", "African American women", "African diaspora"],
  priority: 0
};

const mexicanAmericanWomanLens = {
  id: "mexican-american-woman",
  label: "Mexican American woman",
  searchTerms: ["Mexican American women", "Mexican women", "Latine"],
  priority: 1
};

test("resolves Philly to Philadelphia before any location clarification", () => {
  const plan = buildLocalDiscoveryPlan("Tell me about Philly nightlife", [blackWomanLens]);
  assert.equal(plan?.kind, "local_discovery");
  assert.equal(plan?.needsLocationClarification, false);
  assert.deepEqual(plan?.location, { city: "Philadelphia", state: "PA", country: "US", source: "alias" });
  assert.match(plan?.communityQueries[0] ?? "", /Black woman nightlife in Philadelphia, PA/i);
  assert.match(plan?.systemDirective ?? "", /Never claim location is missing/i);
});

test("uses every active community lens in local nightlife planning", () => {
  const plan = buildLocalDiscoveryPlan("Philly nightlife", [blackWomanLens, mexicanAmericanWomanLens]);
  assert.ok(plan?.communityQueries.some((query) => /Black woman nightlife in Philadelphia, PA/i.test(query)));
  assert.ok(plan?.communityQueries.some((query) => /Mexican American woman nightlife in Philadelphia, PA/i.test(query)));
  assert.equal(plan?.needsLocationClarification, false);
});

test("asks for location only when neither message nor session resolves a city", () => {
  const plan = buildLocalDiscoveryPlan("Tell me about nightlife", [blackWomanLens]);
  assert.equal(plan?.needsLocationClarification, true);
  assert.match(plan?.systemDirective ?? "", /No city, neighborhood, metro, or remembered session location was resolved/i);
});

test("uses a remembered session location when the new local request omits a city", () => {
  const plan = buildLocalDiscoveryPlan("Tell me about nightlife", [blackWomanLens], {
    city: "Philadelphia",
    state: "PA",
    country: "US",
    source: "alias"
  });
  assert.equal(plan?.needsLocationClarification, false);
  assert.equal(plan?.location?.source, "session");
  assert.match(plan?.communityQueries[0] ?? "", /Philadelphia, PA/i);
});

test("does not classify a two-second recording as over 60 seconds", () => {
  assert.deepEqual(validateVoicePreflight(2_000, 18_000), { ok: true });
});

test("emits a duration error only when actual duration exceeds sixty seconds", () => {
  const result = validateVoicePreflight(60_001, 18_000);
  assert.equal(result.ok, false);
  if (!result.ok) {
    assert.equal(result.code, "AUDIO_DURATION_EXCEEDED");
    assert.match(result.message, /over 60 seconds/i);
  }
});

test("distinguishes an oversized short clip from a duration violation", () => {
  const result = validateVoicePreflight(2_000, 4 * 1024 * 1024 + 1);
  assert.equal(result.ok, false);
  if (!result.ok) {
    assert.equal(result.code, "AUDIO_PAYLOAD_TOO_LARGE");
    assert.doesNotMatch(result.message, /60 seconds/i);
  }
});

test("does not translate a bare 413 response into a false duration claim", () => {
  const result = safeVoiceError(413, {});
  assert.equal(result.code, "AUDIO_PAYLOAD_TOO_LARGE");
  assert.doesNotMatch(result.message, /60 seconds/i);
});
