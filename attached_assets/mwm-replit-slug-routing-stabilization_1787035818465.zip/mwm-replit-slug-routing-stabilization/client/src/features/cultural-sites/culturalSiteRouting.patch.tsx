// Apply this patch in the existing React Router declaration.
// The ID is canonical; the slug is readable and self-correcting.
import { Route } from "react-router-dom";
import { CulturalSiteDetailPage } from "./CulturalSiteDetailPage";

export const culturalSiteRoute = (
  <Route path="/cultural-sites/:id/:slug?" element={<CulturalSiteDetailPage />} />
);

// Apply this replacement wherever map cards, search results, or the left panel currently
// generate hrefs from a title/slug. `detailUrl` must come from /api/cultural-sites.
import { Link } from "react-router-dom";

type CulturalSiteCardProps = {
  site: { id: string; name: string; detailUrl: string };
};

export function CulturalSiteCardLink({ site }: CulturalSiteCardProps) {
  return <Link aria-label={`View details for ${site.name}`} to={site.detailUrl}>View details</Link>;
}
