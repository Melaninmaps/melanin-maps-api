import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

type CulturalSite = {
  id: string;
  slug: string;
  name: string;
  description: string | null;
  city: string | null;
  stateCode: string | null;
  imageUrl: string | null;
  learnMoreUrl: string | null;
  detailUrl: string;
};

export function CulturalSiteDetailPage() {
  const { id, slug } = useParams<{ id: string; slug?: string }>();
  const navigate = useNavigate();
  const [site, setSite] = useState<CulturalSite | null>(null);
  const [state, setState] = useState<"loading" | "not-found" | "error">("loading");

  useEffect(() => {
    if (!id) return;
    let active = true;
    fetch(`/api/cultural-sites/${encodeURIComponent(id)}`, { headers: { Accept: "application/json" } })
      .then(async (response) => {
        if (response.status === 404) throw new Error("not-found");
        if (!response.ok) throw new Error("request-failed");
        return response.json() as Promise<CulturalSite>;
      })
      .then((result) => {
        if (!active) return;
        if (slug !== result.slug) navigate(result.detailUrl, { replace: true });
        setSite(result);
        setState("loading");
      })
      .catch((error: Error) => {
        if (!active) return;
        setState(error.message === "not-found" ? "not-found" : "error");
      });
    return () => { active = false; };
  }, [id, slug, navigate]);

  if (state === "not-found") return <main className="page-shell"><h1>Cultural site not found</h1><p>This place may have been renamed or removed.</p><Link to="/map">Return to the map</Link></main>;
  if (state === "error") return <main className="page-shell"><h1>We could not load this cultural site</h1><p>Please try again. The map is still available while we reconnect.</p><Link to="/map">Return to the map</Link></main>;
  if (!site) return <main aria-busy="true" className="page-shell">Loading cultural site…</main>;

  return <main className="page-shell"><Link to="/map">Back to map</Link><article className="cultural-site-detail">{site.imageUrl ? <img alt="" src={site.imageUrl} /> : null}<p>{[site.city, site.stateCode].filter(Boolean).join(", ")}</p><h1>{site.name}</h1>{site.description ? <p>{site.description}</p> : null}{site.learnMoreUrl ? <a href={site.learnMoreUrl} rel="noreferrer" target="_blank">Learn more</a> : null}</article></main>;
}
