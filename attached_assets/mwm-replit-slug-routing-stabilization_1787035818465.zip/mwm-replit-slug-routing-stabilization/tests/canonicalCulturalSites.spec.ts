import { expect, test } from "@playwright/test";

// Configure these in Replit's test command with a real seeded cultural-site record.
const culturalSiteId = process.env.E2E_CULTURAL_SITE_ID!;
const culturalSiteSlug = process.env.E2E_CULTURAL_SITE_SLUG!;

test.describe("canonical cultural-site URLs", () => {
  test("the API returns a canonical detail URL with an ID and slug", async ({ request }) => {
    const response = await request.get(`/api/cultural-sites/${culturalSiteId}`);
    expect(response.ok()).toBeTruthy();
    const body = await response.json();
    expect(body.slug).toBe(culturalSiteSlug);
    expect(body.detailUrl).toBe(`/cultural-sites/${culturalSiteId}/${culturalSiteSlug}`);
  });

  test("a direct canonical cultural-site visit and browser refresh both render the detail page", async ({ page }) => {
    const path = `/cultural-sites/${culturalSiteId}/${culturalSiteSlug}`;
    await page.goto(path);
    await expect(page.getByRole("heading")).toBeVisible();
    await page.reload();
    await expect(page.getByRole("heading")).toBeVisible();
    await expect(page.getByText(/not found/i)).not.toBeVisible();
  });

  test("a stale readable slug self-corrects to the canonical URL rather than showing a 404", async ({ page }) => {
    await page.goto(`/cultural-sites/${culturalSiteId}/outdated-name`);
    await expect(page).toHaveURL(new RegExp(`/cultural-sites/${culturalSiteId}/${culturalSiteSlug}$`));
    await expect(page.getByRole("heading")).toBeVisible();
  });
});
