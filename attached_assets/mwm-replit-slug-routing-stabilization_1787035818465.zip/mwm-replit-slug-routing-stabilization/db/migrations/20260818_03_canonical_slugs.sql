BEGIN;

-- Production invariant: every canonical directory entity exposes a stable, non-empty
-- slug. The route format is /cultural-sites/:id/:slug, so the UUID stays authoritative
-- even if a title later changes.
CREATE OR REPLACE FUNCTION public.mwm_slugify(input text)
RETURNS text
LANGUAGE sql
IMMUTABLE
PARALLEL SAFE
AS $$
  SELECT trim(both '-' FROM regexp_replace(lower(coalesce(input, '')), '[^a-z0-9]+', '-', 'g'));
$$;

-- The exact table reported by the failing cultural-site and discovery code.
ALTER TABLE public.cultural_sites
  ADD COLUMN IF NOT EXISTS slug text;

-- Deterministic backfill. The ID suffix makes duplicate titles safe and means URLs do
-- not collide. Existing non-empty slugs remain untouched.
UPDATE public.cultural_sites
SET slug = left(
  CASE
    WHEN nullif(public.mwm_slugify(name), '') IS NOT NULL
      THEN public.mwm_slugify(name) || '-' || left(id::text, 8)
    ELSE 'cultural-site-' || left(id::text, 8)
  END,
  220
)
WHERE nullif(trim(slug), '') IS NULL;

ALTER TABLE public.cultural_sites
  ALTER COLUMN slug SET NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS cultural_sites_slug_key
  ON public.cultural_sites (slug);

-- The closest-business query may source from businesses rather than cultural_sites.
-- Add the same safe canonical lookup key instead of assuming a slug already exists.
ALTER TABLE public.businesses
  ADD COLUMN IF NOT EXISTS slug text;

UPDATE public.businesses
SET slug = left(
  CASE
    WHEN nullif(public.mwm_slugify(name), '') IS NOT NULL
      THEN public.mwm_slugify(name) || '-' || left(id::text, 8)
    ELSE 'business-' || left(id::text, 8)
  END,
  220
)
WHERE nullif(trim(slug), '') IS NULL;

CREATE UNIQUE INDEX IF NOT EXISTS businesses_slug_key
  ON public.businesses (slug)
  WHERE slug IS NOT NULL;

-- Fail the migration explicitly rather than leaving a UI that swallows the error.
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM public.cultural_sites WHERE nullif(trim(slug), '') IS NULL) THEN
    RAISE EXCEPTION 'cultural_sites.slug backfill incomplete';
  END IF;
END $$;

COMMIT;
