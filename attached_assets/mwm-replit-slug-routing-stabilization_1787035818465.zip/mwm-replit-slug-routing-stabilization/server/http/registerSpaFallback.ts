import type { Express, Request, Response, NextFunction } from "express";
import path from "node:path";

/**
 * Register this LAST: after every /api route and after express.static().
 * It is for the WEB deployment only. Do not install it on api.melaninmaps.com
 * if that deployment does not serve the compiled client files.
 */
export function registerSpaFallback(app: Express, clientDistDirectory: string) {
  app.use((request: Request, response: Response, next: NextFunction) => {
    if (request.method !== "GET") return next();
    if (request.path.startsWith("/api/")) return next();
    if (path.extname(request.path)) return next();
    if (!request.accepts("html")) return next();

    response.setHeader("Cache-Control", "no-cache");
    return response.sendFile(path.join(clientDistDirectory, "index.html"));
  });
}

// Server bootstrap order:
// app.use("/assets", express.static(path.join(clientDistDirectory, "assets"), { immutable: true, maxAge: "1y" }));
// registerCanonicalCulturalSiteRoutes(app, culturalSiteRepository);
// registerSpaFallback(app, clientDistDirectory); // MUST be last
