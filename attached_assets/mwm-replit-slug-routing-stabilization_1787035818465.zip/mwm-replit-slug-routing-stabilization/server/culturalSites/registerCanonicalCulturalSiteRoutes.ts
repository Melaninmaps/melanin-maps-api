import type { Express, Request, Response } from "express";
import { canonicalCulturalSitePath, CanonicalCulturalSiteRepository } from "./canonicalCulturalSiteRepository";

export function registerCanonicalCulturalSiteRoutes(app: Express, repository: CanonicalCulturalSiteRepository) {
  // Map/list endpoints always send a server-built detailUrl. The web client must never
  // recreate a URL from a display name or an untrusted ad hoc slug.
  app.get("/api/cultural-sites", async (request: Request, response: Response, next) => {
    try {
      const cityId = typeof request.query.cityId === "string" ? request.query.cityId : undefined;
      response.setHeader("Cache-Control", "no-store");
      response.json({ items: await repository.listMapCards(cityId) });
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/cultural-sites/:id", async (request: Request, response: Response, next) => {
    try {
      const site = await repository.findById(request.params.id);
      if (!site) return response.status(404).json({ code: "CULTURAL_SITE_NOT_FOUND" });
      response.setHeader("Cache-Control", "no-store");
      return response.json({ ...site, detailUrl: canonicalCulturalSitePath(site) });
    } catch (error) {
      next(error);
    }
  });

  // This redirect protects old links such as /cultural-sites/:slug after release.
  app.get("/cultural-sites/:legacySlug", async (request: Request, response: Response, next) => {
    try {
      const site = await repository.findBySlug(request.params.legacySlug);
      if (!site) return next();
      return response.redirect(301, canonicalCulturalSitePath(site));
    } catch (error) {
      next(error);
    }
  });
}
