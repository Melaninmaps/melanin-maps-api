import { expect, test } from "vitest";
import { buildDiasporaFirstResearchQuery, contextStorageDecision, prohibitsIdentityInference } from "../server/kinfolk/diasporaFirstResearchPolicy";
import { clarificationPlan, minimumContextQuestions } from "../server/kinfolk/intentClarification";
import { FOUNDATIONAL_TOPICS, REQUIRED_FEATURED_SLUGS } from "../seed/foundationalTopics";

test("heart disease is researched through the permanent Black women lens", () => {
  expect(buildDiasporaFirstResearchQuery("heart disease", "health", { subject: "general_research" })).toBe("Black women heart disease");
});

test("an explicit Black women query is not duplicated", () => {
  expect(buildDiasporaFirstResearchQuery("Black women heart disease", "health", { subject: "general_research" })).toBe("Black women heart disease");
});

test("cultural search intent does not create identity memory", () => {
  expect(prohibitsIdentityInference("Black-owned restaurants in Charlotte")).toBe(true);
  expect(contextStorageDecision({ subject: "someone_else", temporaryAttributes: { age_range: "65-plus" } })).toEqual({ persistSearchSubject: false, persistTemporaryAttributes: false, mayUseMemberMemory: false, requireExplicitRememberPermission: true });
});

test("health asks subject and consent before only optional minimum context", () => {
  const first = clarificationPlan("heart disease", "unknown");
  expect(first).toHaveLength(1);
  expect(first[0].id).toBe("subject");
  const afterSubject = clarificationPlan("heart disease", "me");
  expect(afterSubject[0].id).toBe("personalize-health");
  expect([...first, ...afterSubject].every((step) => step.skippable)).toBe(true);
  expect(minimumContextQuestions("health").every((step) => step.persistence === "temporary")).toBe(true);
});

test("the recoverable foundation has every required Start Here topic", () => {
  const slugs = new Set(FOUNDATIONAL_TOPICS.map((topic) => topic.slug));
  expect(FOUNDATIONAL_TOPICS).toHaveLength(28);
  for (const slug of REQUIRED_FEATURED_SLUGS) expect(slugs.has(slug)).toBe(true);
});
