import { Pool } from "pg";
import { seedFoundationalTopics, verifyFoundationalTopics } from "../server/library/seedFoundationalTopics";

async function main() {
  if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required");
  const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 1 });
  try {
    const mode = process.argv.includes("--verify") ? "verify" : "seed";
    const result = mode === "seed" ? await seedFoundationalTopics(pool) : await verifyFoundationalTopics(pool);
    console.log(JSON.stringify({ mode, ...result }, null, 2));
    if (!result.ok) process.exitCode = 1;
  } finally {
    await pool.end();
  }
}

main().catch((error) => {
  console.error("living-library-seed-failed", { name: error instanceof Error ? error.name : "Error", message: error instanceof Error ? error.message : String(error) });
  process.exitCode = 1;
});
