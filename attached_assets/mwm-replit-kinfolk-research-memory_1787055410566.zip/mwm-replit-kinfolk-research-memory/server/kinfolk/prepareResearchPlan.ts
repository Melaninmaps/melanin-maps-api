import { buildDiasporaFirstResearchQuery, type SearchContext } from "./diasporaFirstResearchPolicy";
import { clarificationPlan, identifyTopicDomain } from "./intentClarification";

export function prepareKinfolkResearchPlan(question: string, context: SearchContext) {
  const topic = identifyTopicDomain(question);
  return {
    topic,
    researchQuery: buildDiasporaFirstResearchQuery(question, topic, context),
    // Kinfolk can give a concise, source-cited general orientation immediately. The
    // clarifier is an offer to improve relevance, never a gate that withholds information.
    answerMode: "general-first" as const,
    clarification: clarificationPlan(question, context.subject),
    permanentLensVersion: "1.0.0",
    identityInferenceProhibited: true,
  };
}
