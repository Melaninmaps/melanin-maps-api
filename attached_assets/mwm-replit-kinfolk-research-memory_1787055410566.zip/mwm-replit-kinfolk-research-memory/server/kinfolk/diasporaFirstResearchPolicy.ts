export type SearchSubject = "me" | "someone_else" | "general_research" | "unknown";
export type TopicDomain = "health" | "travel" | "legal" | "housing" | "career" | "general";

export type MemberContext = {
  // Only values explicitly volunteered by the member and expressly approved for memory.
  rememberedAttributes?: Record<string, string>;
};

export type SearchContext = {
  subject: SearchSubject;
  // Temporary search-only context. Never copy this to member memory automatically.
  temporaryAttributes?: Record<string, string>;
  memberContext?: MemberContext;
};

export const KINFOLK_PERMANENT_RESEARCH_LENS = {
  version: "1.0.0",
  primaryQueryContext: "Black women",
  broaderCommunityContext: "African diaspora communities",
  rule: "Apply the cultural research lens to source discovery. Never convert the lens or a search term into a claim about the member's identity.",
} as const;

function includesBlackWomenContext(query: string) {
  return /\bblack\s+(women|woman)\b/i.test(query);
}

export function buildDiasporaFirstResearchQuery(memberQuestion: string, topic: TopicDomain, search: SearchContext) {
  const cleanQuestion = memberQuestion.trim().replace(/\s+/g, " ");
  if (!cleanQuestion) throw new Error("QUESTION_REQUIRED");
  const lens = includesBlackWomenContext(cleanQuestion) ? "" : `${KINFOLK_PERMANENT_RESEARCH_LENS.primaryQueryContext} `;
  const subjectContext = search.subject === "me" && search.memberContext?.rememberedAttributes
    ? relevantRememberedContext(topic, search.memberContext.rememberedAttributes)
    : "";
  const temporaryContext = search.temporaryAttributes ? Object.values(search.temporaryAttributes).filter(Boolean).join(" ") : "";
  return [lens + cleanQuestion, subjectContext, temporaryContext].filter(Boolean).join(" ");
}

function relevantRememberedContext(topic: TopicDomain, attributes: Record<string, string>) {
  // Memory is intentionally minimal and relevance-gated. It is not automatically used for
  // restaurants, general history, or other queries where it does not improve the answer.
  if (topic === "health") return [attributes.life_stage, attributes.accessibility_needs].filter(Boolean).join(" ");
  if (topic === "travel") return [attributes.travel_style, attributes.accessibility_needs].filter(Boolean).join(" ");
  return "";
}

export function prohibitsIdentityInference(question: string) {
  // Requested cultural/service attributes can improve the search, but are never profile facts.
  return /\b(black-owned|black\s+maternal|trans-friendly|halal|wheelchair-accessible|black\s+women)\b/i.test(question);
}

export function contextStorageDecision(search: SearchContext) {
  return {
    persistSearchSubject: false,
    persistTemporaryAttributes: false,
    mayUseMemberMemory: search.subject === "me",
    requireExplicitRememberPermission: true,
  };
}
