BEGIN;

-- Permanent context exists only when the member explicitly saves it for future relevance.
CREATE TABLE IF NOT EXISTS public.kinfolk_member_memory (
  member_id uuid NOT NULL,
  memory_key text NOT NULL,
  memory_value text NOT NULL,
  explicitly_shared_at timestamptz NOT NULL DEFAULT now(),
  remember_approved_at timestamptz NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (member_id, memory_key),
  CHECK (btrim(memory_key) <> ''),
  CHECK (btrim(memory_value) <> '')
);

-- Someone else's context and unapproved personal context remain short-lived search data.
CREATE TABLE IF NOT EXISTS public.kinfolk_search_context (
  id uuid PRIMARY KEY,
  member_id uuid,
  session_id text NOT NULL,
  subject text NOT NULL CHECK (subject IN ('me', 'someone_else', 'general_research', 'unknown')),
  attributes jsonb NOT NULL DEFAULT '{}'::jsonb,
  expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (expires_at <= created_at + interval '24 hours')
);
CREATE INDEX IF NOT EXISTS kinfolk_search_context_expiry_idx ON public.kinfolk_search_context(expires_at);

-- Scheduled cleanup must run at least daily. It is intentionally not archival.
COMMIT;
