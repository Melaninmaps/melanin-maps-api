import { useState } from "react";
import { Link } from "react-router-dom";
import { GoldFeatherBadge, GoldFeatherMark } from "../../components/brand/GoldFeatherMark";

type ExploreStop = {
  id: string;
  kind: "business" | "cultural-site" | "event" | "safety-note";
  title: string;
  description: string;
  detailUrl: string | null;
};

type ExplorePlan = {
  locationLabel: string | null;
  title: string;
  introduction: string;
  stops: ExploreStop[];
};

type DirectoryBusiness = {
  id: string;
  name: string;
  category: string;
  city: string;
  state: string;
  detailUrl: string;
};

/**
 * EXPLORE WITH PURPOSE: a discovery/planning surface. It never renders the
 * directory's full business grid. It combines a few relevant business links
 * with cultural places and events to help a member shape an outing.
 */
export function ExploreWithPurposePage() {
  const [prompt, setPrompt] = useState("");
  const [plan, setPlan] = useState<ExplorePlan | null>(null);
  const [loading, setLoading] = useState(false);

  async function buildPlan(event: React.FormEvent) {
    event.preventDefault();
    if (prompt.trim().length < 3) return;
    setLoading(true);
    try {
      const response = await fetch("/api/explore/plan", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
      });
      if (!response.ok) throw new Error("Explore plan unavailable");
      setPlan(await response.json());
    } catch (error: unknown) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-[#FAF6EF]">
      <section className="bg-[#2B1507] px-4 py-16 text-white">
        <div className="mx-auto max-w-4xl text-center">
          <div className="mx-auto flex w-fit items-center gap-2 rounded-full border border-[#CA922B]/60 bg-[#CA922B]/10 px-4 py-2 text-[#E4B64D]">
            <GoldFeatherMark label="Explore with purpose" size={17} />
            <span className="text-xs font-bold uppercase tracking-[0.16em]">Explore with purpose</span>
          </div>
          <h1 className="mt-6 font-serif text-5xl font-bold">Plan an experience rooted in place.</h1>
          <p className="mx-auto mt-4 max-w-2xl leading-7 text-[#F5EBD8]/80">
            Tell us what you want to experience. Explore combines a small number of relevant businesses with cultural sites and community happenings; it is not a directory dump.
          </p>
          <form className="mx-auto mt-8 flex max-w-2xl gap-3" onSubmit={buildPlan}>
            <input
              className="min-w-0 flex-1 rounded-xl px-4 py-4 text-[#2B1507]"
              onChange={(event) => setPrompt(event.target.value)}
              placeholder="Example: Black art, good food, and history in Charlotte this weekend"
              value={prompt}
            />
            <button className="rounded-xl bg-[#CA922B] px-5 py-4 font-semibold text-[#2B1507]" disabled={loading} type="submit">
              {loading ? "Building…" : "Build my plan"}
            </button>
          </form>
          <p className="mt-5 text-sm text-[#F5EBD8]/70">
            Looking for a specific business or service? <Link className="font-semibold underline" to="/businesses">Use the Business Directory.</Link>
          </p>
        </div>
      </section>

      {plan ? (
        <section className="mx-auto max-w-4xl px-4 py-10">
          <div className="flex items-center gap-3">
            <GoldFeatherBadge label="Purposeful plan" />
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.16em] text-[#CA922B]">Purposeful plan</p>
              <h2 className="font-serif text-3xl font-bold text-[#2B1507]">{plan.title}</h2>
            </div>
          </div>
          <p className="mt-4 leading-7 text-[#3A1F0E]/75">{plan.introduction}</p>
          <ol className="mt-7 space-y-4">
            {plan.stops.map((stop, index) => (
              <li className="rounded-2xl border border-[#3A1F0E]/10 bg-white p-5" key={stop.id}>
                <div className="flex gap-3">
                  <GoldFeatherMark label={`Plan stop ${index + 1}`} size={20} />
                  <div>
                    <p className="text-xs font-bold uppercase tracking-[0.14em] text-[#CA922B]">{stop.kind.replace("-", " ")}</p>
                    <h3 className="mt-1 text-xl font-bold text-[#2B1507]">{stop.title}</h3>
                    <p className="mt-2 leading-7 text-[#3A1F0E]/75">{stop.description}</p>
                    {stop.detailUrl ? <Link className="mt-3 inline-block font-semibold text-[#8D5C17] underline" to={stop.detailUrl}>Open details</Link> : null}
                  </div>
                </div>
              </li>
            ))}
          </ol>
        </section>
      ) : null}
    </main>
  );
}

/**
 * BUSINESS DIRECTORY: a precise, transactional lookup surface. It returns
 * actual active business records and directs members to their business pages.
 */
export function BusinessDirectoryPage() {
  const [query, setQuery] = useState("");
  const [businesses, setBusinesses] = useState<DirectoryBusiness[]>([]);
  const [loading, setLoading] = useState(false);

  async function search(event: React.FormEvent) {
    event.preventDefault();
    if (query.trim().length < 2) return;
    setLoading(true);
    try {
      const response = await fetch(`/api/directory/search?q=${encodeURIComponent(query.trim())}`, {
        credentials: "include",
      });
      const payload = await response.json();
      setBusinesses(payload.businesses ?? []);
    } catch (error: unknown) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-[#FAF6EF]">
      <section className="bg-[#2B1507] px-4 py-16 text-center text-white">
        <div className="mx-auto max-w-4xl">
          <div className="mx-auto flex w-fit items-center gap-2 rounded-full border border-[#CA922B]/60 bg-[#CA922B]/10 px-4 py-2 text-[#E4B64D]">
            <GoldFeatherMark label="Business Directory" size={17} />
            <span className="text-xs font-bold uppercase tracking-[0.16em]">Business Directory</span>
          </div>
          <h1 className="mt-6 font-serif text-5xl font-bold">Find the business you need.</h1>
          <p className="mx-auto mt-4 max-w-2xl leading-7 text-[#F5EBD8]/80">
            Search verified businesses and service providers by name, service, ownership, and location. This page is for direct lookup—not trip planning.
          </p>
          <form className="mx-auto mt-8 flex max-w-2xl gap-3" onSubmit={search}>
            <input
              className="min-w-0 flex-1 rounded-xl px-4 py-4 text-[#2B1507]"
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Example: bookstore near me, Black-owned dentist, tax attorney"
              value={query}
            />
            <button className="rounded-xl bg-[#CA922B] px-5 py-4 font-semibold text-[#2B1507]" disabled={loading} type="submit">
              {loading ? "Searching…" : "Search directory"}
            </button>
          </form>
          <p className="mt-5 text-sm text-[#F5EBD8]/70">
            Want an itinerary or cultural discovery? <Link className="font-semibold underline" to="/explore">Explore With Purpose.</Link>
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-10" aria-label="Business results">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {businesses.map((business) => (
            <Link className="rounded-2xl border border-[#3A1F0E]/10 bg-white p-5 hover:border-[#CA922B]/60" key={business.id} to={business.detailUrl}>
              <GoldFeatherMark label={`${business.name} business listing`} size={18} />
              <h2 className="mt-3 text-xl font-bold text-[#2B1507]">{business.name}</h2>
              <p className="mt-2 text-sm text-[#3A1F0E]/70">{business.category} · {business.city}, {business.state}</p>
            </Link>
          ))}
        </div>
      </section>
    </main>
  );
}
