import { useEffect, useState } from "react";
import { Link, useNavigate, useParams, useSearchParams } from "react-router-dom";
import { GoldFeatherBadge, GoldFeatherMark } from "../../components/brand/GoldFeatherMark";

type LibraryTopic = {
  id: string;
  slug: string;
  title: string;
  domain: string;
  isFollowed: boolean;
  entryCount: number;
  newestEntryAt: string | null;
};

type KnowledgeSource = {
  id: string;
  url: string;
  title: string;
  publisher: string | null;
  excerpt: string;
  sourceTier: "primary" | "public-service" | "community-expert";
};

type LibraryEntry = {
  id: string;
  title: string;
  summary: string;
  body: string;
  question: string;
  locationLabel: string | null;
  disclaimer: string | null;
  sourceCount: number;
  refreshedAt: string;
  sources: KnowledgeSource[];
};

function stripMwmEmoji(value: string): string {
  return value
    .replace(/\p{Extended_Pictographic}/gu, "")
    .replace(/\uFE0F|\u200D/g, "")
    .replace(/[ \t]+([,.;:!?])/g, "$1")
    .trim();
}

export function LibraryHomePage() {
  const [searchParams] = useSearchParams();
  const [topics, setTopics] = useState<LibraryTopic[]>([]);
  const query = searchParams.get("q") ?? "";

  useEffect(() => {
    const controller = new AbortController();
    const params = new URLSearchParams();
    if (query) params.set("q", query);

    fetch(`/api/library/topics?${params.toString()}`, { credentials: "include", signal: controller.signal })
      .then((response) => response.json())
      .then((payload) => setTopics(payload.topics ?? []))
      .catch((caught: unknown) => {
        const error = caught as { name?: string };
        if (error.name !== "AbortError") console.error("Unable to load Library topics", caught);
      });

    return () => controller.abort();
  }, [query]);

  return (
    <main className="mx-auto max-w-5xl px-4 py-10">
      <header className="max-w-2xl">
        <div className="flex items-center gap-3">
          <GoldFeatherBadge label="Living Library" />
          <p className="text-xs font-bold uppercase tracking-[0.16em] text-[#CA922B]">Living Library</p>
        </div>
        <h1 className="mt-4 font-serif text-4xl font-bold text-[#2B1507]">Knowledge that grows with the community</h1>
        <p className="mt-3 leading-7 text-[#3A1F0E]/75">
          Each topic is a living book built from source-cited Kinfolk research. Explore an existing book or ask Kinfolk a new question to add a verified entry.
        </p>
      </header>

      <form action="/library" className="mt-8 flex gap-3">
        <label className="sr-only" htmlFor="library-search">Search the Library</label>
        <input
          defaultValue={query}
          id="library-search"
          name="q"
          placeholder="Search topics and prior Kinfolk research"
          className="min-w-0 flex-1 rounded-xl border border-[#3A1F0E]/15 bg-white px-4 py-3 text-[#2B1507]"
        />
        <button className="rounded-xl bg-[#2B1507] px-5 py-3 font-semibold text-white" type="submit">
          Search
        </button>
      </form>

      <section aria-label="Library topics" className="mt-8 grid gap-4 sm:grid-cols-2">
        {topics.map((topic) => (
          <Link
            key={topic.id}
            to={`/library/topics/${encodeURIComponent(topic.slug)}`}
            className="group rounded-2xl bg-[#2B1507] p-5 text-white transition hover:-translate-y-0.5 hover:bg-[#3A1F0E] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#CA922B]"
          >
            <GoldFeatherMark label={`${topic.title} topic`} size={22} />
            <h2 className="mt-3 text-xl font-bold">{topic.title}</h2>
            <p className="mt-1 text-sm text-[#F5EBD8]/75">
              {topic.entryCount} research {topic.entryCount === 1 ? "entry" : "entries"}
            </p>
            <p className="mt-4 text-sm font-semibold text-[#CA922B]">Open this living book →</p>
          </Link>
        ))}
      </section>
    </main>
  );
}

function EntryCard({ entry }: { entry: LibraryEntry }) {
  const [expanded, setExpanded] = useState(false);
  const body = stripMwmEmoji(entry.body);

  return (
    <article id={`entry-${entry.id}`} className="rounded-2xl border border-[#3A1F0E]/10 bg-white p-5 shadow-sm">
      <div className="flex items-start gap-3">
        <GoldFeatherBadge label="Source-cited Library entry" />
        <div className="min-w-0 flex-1">
          <h2 className="font-serif text-2xl font-bold text-[#2B1507]">{stripMwmEmoji(entry.title)}</h2>
          <p className="mt-2 text-sm text-[#3A1F0E]/60">
            {entry.locationLabel ? `${entry.locationLabel} · ` : ""}Updated {new Date(entry.refreshedAt).toLocaleDateString()}
          </p>
        </div>
      </div>
      <p className="mt-4 leading-7 text-[#3A1F0E]">{stripMwmEmoji(entry.summary)}</p>

      {expanded ? (
        <div className="mt-4 whitespace-pre-wrap leading-7 text-[#3A1F0E]/85">{body}</div>
      ) : null}

      <button
        className="mt-4 inline-flex items-center gap-2 font-semibold text-[#8D5C17] underline"
        onClick={() => setExpanded((current) => !current)}
        type="button"
      >
        <GoldFeatherMark label={expanded ? "Read less" : "Read more"} size={16} />
        {expanded ? "Read less" : "Read more"}
      </button>

      {entry.disclaimer ? <p className="mt-4 text-sm italic text-[#3A1F0E]/65">{entry.disclaimer}</p> : null}

      {expanded && entry.sources.length > 0 ? (
        <section className="mt-5 border-t border-[#3A1F0E]/10 pt-4" aria-label="Sources">
          <h3 className="font-semibold text-[#2B1507]">Sources used</h3>
          <ul className="mt-3 space-y-3">
            {entry.sources.map((source) => (
              <li key={source.id}>
                <a className="font-semibold text-[#8D5C17] underline" href={source.url} rel="noreferrer" target="_blank">
                  {source.title}
                </a>
                <p className="mt-1 text-sm leading-6 text-[#3A1F0E]/70">
                  {source.publisher ? `${source.publisher} · ` : ""}{source.excerpt}
                </p>
              </li>
            ))}
          </ul>
        </section>
      ) : null}
    </article>
  );
}

export function LibraryTopicPage() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const [topic, setTopic] = useState<LibraryTopic | null>(null);
  const [entries, setEntries] = useState<LibraryEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!slug) return;
    const controller = new AbortController();
    setLoading(true);
    fetch(`/api/library/topics/${encodeURIComponent(slug)}`, { credentials: "include", signal: controller.signal })
      .then(async (response) => {
        if (response.status === 404) throw new Error("not-found");
        if (!response.ok) throw new Error("load-failed");
        return response.json();
      })
      .then((payload) => {
        setTopic(payload.topic);
        setEntries(payload.entries ?? []);
      })
      .catch((caught: unknown) => {
        const error = caught as { name?: string };
        if (error.name === "not-found") navigate("/library", { replace: true });
        else if (error.name !== "AbortError") console.error("Unable to load topic", caught);
      })
      .finally(() => setLoading(false));
    return () => controller.abort();
  }, [slug, navigate]);

  async function setFollow(following: boolean) {
    if (!topic) return;
    const response = await fetch(`/api/library/topics/${topic.id}/follow`, {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ following }),
    });
    if (response.ok) setTopic({ ...topic, isFollowed: following });
  }

  if (loading) return <main className="p-10 text-center">Loading this living book…</main>;
  if (!topic) return null;

  return (
    <main className="mx-auto max-w-4xl px-4 py-10">
      <Link className="text-sm font-semibold text-[#8D5C17] underline" to="/library">← All topics</Link>
      <header className="mt-5 flex flex-wrap items-start justify-between gap-4">
        <div className="flex items-center gap-3">
          <GoldFeatherBadge label={`${topic.title} living book`} />
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.16em] text-[#CA922B]">Living book</p>
            <h1 className="mt-1 font-serif text-4xl font-bold text-[#2B1507]">{topic.title}</h1>
          </div>
        </div>
        <button
          className="rounded-full border border-[#CA922B] px-4 py-2 font-semibold text-[#8D5C17]"
          onClick={() => void setFollow(!topic.isFollowed)}
          type="button"
        >
          {topic.isFollowed ? "Following" : "Follow this topic"}
        </button>
      </header>

      <p className="mt-4 max-w-2xl leading-7 text-[#3A1F0E]/75">
        This book brings together source-cited Kinfolk research. New questions become new entries, including location-specific entries such as “STEM in Charlotte.”
      </p>

      <section className="mt-8 space-y-5" aria-label={`${topic.title} research entries`}>
        {entries.length ? entries.map((entry) => <EntryCard key={entry.id} entry={entry} />) : (
          <p className="rounded-xl border border-dashed border-[#3A1F0E]/20 p-6 text-[#3A1F0E]/70">
            This book is ready for its first source-cited Kinfolk research entry.
          </p>
        )}
      </section>
    </main>
  );
}
