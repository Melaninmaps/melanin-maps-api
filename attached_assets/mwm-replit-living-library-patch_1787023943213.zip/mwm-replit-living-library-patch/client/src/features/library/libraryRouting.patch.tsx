/* Apply in the application router before the catch-all/not-found route. */
import { LibraryHomePage, LibraryTopicPage } from "./LivingLibraryPages";

<Route path="/library" element={<LibraryHomePage />} />;
<Route path="/library/topics/:slug" element={<LibraryTopicPage />} />;

/*
  Replace all static/no-op Library category buttons with this pattern:

  <Link to={`/library/topics/${category.slug}`}>...</Link>

  Do not use button elements with no onClick, `href="#"`, or a generic
  `setSelectedCategory` state that does not route to the relevant topic book.
  Topic counts must come from GET /api/library/topics rather than a hard-coded
  category configuration.
*/
