-- PostgreSQL migration: living, source-cited Library.
-- This schema stores reusable Kinfolk research entries, not chat transcripts.

CREATE TABLE IF NOT EXISTS library_topics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  domain TEXT NOT NULL,
  community_lens TEXT NOT NULL DEFAULT 'Black women and Black communities',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS library_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  topic_id UUID NOT NULL REFERENCES library_topics(id) ON DELETE CASCADE,
  question TEXT NOT NULL,
  normalized_question TEXT NOT NULL,
  title TEXT NOT NULL,
  summary TEXT NOT NULL,
  body TEXT NOT NULL,
  domain TEXT NOT NULL,
  community_lens TEXT NOT NULL,
  location_label TEXT,
  disclaimer TEXT,
  source_count INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  refreshed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS library_entries_reuse_idx
  ON library_entries (normalized_question, domain, community_lens, location_label, refreshed_at DESC);

CREATE INDEX IF NOT EXISTS library_entries_topic_idx
  ON library_entries (topic_id, refreshed_at DESC);

CREATE TABLE IF NOT EXISTS library_entry_sources (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  entry_id UUID NOT NULL REFERENCES library_entries(id) ON DELETE CASCADE,
  url TEXT NOT NULL,
  title TEXT NOT NULL,
  publisher TEXT,
  excerpt TEXT NOT NULL,
  source_tier TEXT NOT NULL,
  published_at TIMESTAMPTZ,
  retrieved_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT library_entry_sources_unique UNIQUE (entry_id, url)
);

CREATE TABLE IF NOT EXISTS library_topic_follows (
  topic_id UUID NOT NULL REFERENCES library_topics(id) ON DELETE CASCADE,
  member_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (topic_id, member_id)
);

-- One book starts each top-level topic. Future questions are saved as entries
-- inside these topics; location-specific questions remain filterable by their
-- `location_label` rather than being lost in a city-only static page.
INSERT INTO library_topics (slug, title, domain)
VALUES
  ('medical', 'Medical & Wellness', 'medical'),
  ('legal', 'Legal Information & Access', 'legal'),
  ('financial', 'Financial Foundations', 'financial'),
  ('education', 'Education & Opportunity', 'education'),
  ('stem', 'STEM', 'stem'),
  ('history', 'History & Heritage', 'history'),
  ('community', 'Community', 'general')
ON CONFLICT (slug) DO NOTHING;
