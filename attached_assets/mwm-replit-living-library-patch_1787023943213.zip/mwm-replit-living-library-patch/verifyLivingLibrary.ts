import assert from "node:assert/strict";
import { answerAndArchiveResearchQuestion } from "./server/library/livingLibrary";
import type { LibraryEntry, LibraryRepository } from "./server/library/types";

let savedEntry: LibraryEntry | null = null;
let searchQuery = "";

const repository: LibraryRepository = {
  async findReusableEntry() {
    return savedEntry;
  },
  async saveEntry(input) {
    savedEntry = {
      id: "entry-1",
      topicId: "topic-stem",
      question: input.question,
      normalizedQuestion: input.normalizedQuestion,
      title: input.title,
      summary: input.summary,
      body: input.body,
      domain: input.domain,
      communityLens: input.communityLens,
      locationLabel: input.locationLabel,
      disclaimer: input.disclaimer,
      sourceCount: input.sourceCount,
      sources: input.sources,
      createdAt: new Date(),
      refreshedAt: new Date(),
    };
    return savedEntry;
  },
  async listTopics() {
    return [];
  },
  async findTopicBySlug() {
    return null;
  },
  async listTopicEntries() {
    return [];
  },
  async setTopicFollow() {},
};

const researchProvider = {
  async search(input: { query: string }) {
    searchQuery = input.query;
    return [
      {
        url: "https://www.nsf.gov/example",
        title: "STEM opportunities",
        content: "A long enough official source about STEM opportunities, mentorship, education, and career pathways for people exploring science and technology. It describes program discovery, learning resources, community support, and practical steps that a person can use to understand the available pathways before making decisions.",
        publisher: "National Science Foundation",
        publishedAt: null,
      },
      {
        url: "https://www.nasa.gov/example",
        title: "STEM careers",
        content: "A long enough official source about STEM careers, practical learning, education pathways, and opportunities for current and future professionals. It provides additional detail about mentorship, skill-building, career exploration, and publicly available programs that strengthen the evidence used for a Library entry.",
        publisher: "NASA",
        publishedAt: null,
      },
    ];
  },
};

const writer = {
  async writeStructured() {
    return {
      title: "STEM pathways for the community",
      summary: "A concise source-cited summary.",
      body: "A fuller source-cited explanation that appears behind Read More.",
      citedSourceIndexes: [0, 1],
    };
  },
};

async function main() {
  const first = await answerAndArchiveResearchQuestion({
    question: "STEM opportunities",
    locationLabel: null,
    repository,
    researchProvider,
    writer,
  });

  assert.equal(first.reused, false);
  assert.equal(first.entry.domain, "stem");
  assert.equal(first.entry.sources.length, 2);
  assert.ok(searchQuery.startsWith("#Black women and minority women STEM opportunities"));

  const second = await answerAndArchiveResearchQuestion({
    question: "STEM opportunities",
    locationLabel: null,
    repository,
    researchProvider,
    writer,
  });

  assert.equal(second.reused, true);
  assert.equal(second.entry.id, "entry-1");
  console.log("Living Library smoke test passed.");
}

void main();
