import { describe, expect, it } from "vitest";
import { buildPurposefulExplorePlan, type ExploreRepository } from "./explorePlanner";

const repository: ExploreRepository = {
  async resolveLocationFromPrompt() {
    return { label: "Charlotte, NC", cityId: "charlotte" };
  },
  async findPurposefulCandidates() {
    return [
      { id: "history", kind: "cultural-site", title: "Historic site", description: "Context", detailUrl: "/cultural-sites/history", relevanceScore: 100 },
      { id: "event", kind: "event", title: "Community event", description: "What is happening", detailUrl: "/events/event", relevanceScore: 90 },
      { id: "business-1", kind: "business", title: "Business one", description: "Support", detailUrl: "/businesses/1", relevanceScore: 80 },
      { id: "business-2", kind: "business", title: "Business two", description: "Support", detailUrl: "/businesses/2", relevanceScore: 70 },
      { id: "business-3", kind: "business", title: "Business three", description: "Should not appear", detailUrl: "/businesses/3", relevanceScore: 60 },
    ];
  },
};

describe("Explore With Purpose", () => {
  it("creates a mixed plan and caps business stops at two", async () => {
    const plan = await buildPurposefulExplorePlan(repository, "Black art and dinner in Charlotte");
    expect(plan.locationLabel).toBe("Charlotte, NC");
    expect(plan.stops.map((stop) => stop.kind)).toEqual(["cultural-site", "event", "business", "business"]);
    expect(plan.stops.filter((stop) => stop.kind === "business")).toHaveLength(2);
  });
});
