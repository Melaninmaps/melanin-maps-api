export type ExploreCandidate = {
  id: string;
  kind: "business" | "cultural-site" | "event" | "safety-note";
  title: string;
  description: string;
  detailUrl: string | null;
  relevanceScore: number;
};

export interface ExploreRepository {
  resolveLocationFromPrompt(prompt: string): Promise<{ label: string; cityId: string } | null>;
  findPurposefulCandidates(input: {
    cityId: string | null;
    prompt: string;
    maxBusinesses: number;
    maxCulturalSites: number;
    maxEvents: number;
  }): Promise<ExploreCandidate[]>;
}

export type ExplorePlan = {
  locationLabel: string | null;
  title: string;
  introduction: string;
  stops: ExploreCandidate[];
};

/**
 * Explore is intentionally limited to a few mixed stops. A complete list of
 * businesses belongs to the Business Directory, not this experience planner.
 */
export async function buildPurposefulExplorePlan(
  repository: ExploreRepository,
  prompt: string,
): Promise<ExplorePlan> {
  const location = await repository.resolveLocationFromPrompt(prompt);
  const candidates = await repository.findPurposefulCandidates({
    cityId: location?.cityId ?? null,
    prompt,
    maxBusinesses: 2,
    maxCulturalSites: 2,
    maxEvents: 2,
  });

  const byKind = (kind: ExploreCandidate["kind"]) =>
    candidates.filter((candidate) => candidate.kind === kind).sort((left, right) => right.relevanceScore - left.relevanceScore);

  // The sequence creates an outing: a cultural grounding, a current happening,
  // and one or two businesses to support. It never displays a raw listing dump.
  const stops = [
    ...byKind("cultural-site").slice(0, 1),
    ...byKind("event").slice(0, 1),
    ...byKind("business").slice(0, 2),
    ...byKind("safety-note").slice(0, 1),
  ];

  return {
    locationLabel: location?.label ?? null,
    title: location ? `A purposeful way to explore ${location.label}` : "A purposeful way to explore",
    introduction: location
      ? "This plan pairs a few relevant places and community experiences. Open any stop for verified details, and use the Business Directory when you need a comprehensive service search."
      : "Add a city or area to receive a location-specific plan. Until then, these are the strongest available discovery paths rather than a complete business list.",
    stops,
  };
}
