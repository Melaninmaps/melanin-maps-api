export type ResearchDomain =
  | "medical"
  | "legal"
  | "financial"
  | "education"
  | "stem"
  | "history"
  | "general";

export type SourceTier = "primary" | "public-service" | "community-expert";

export type SourcePolicy = {
  domain: ResearchDomain;
  searchPrefix: string;
  allowDomains: string[];
  requiredTiers: SourceTier[];
  archiveTtlHours: number;
  disclaimer: string | null;
};

export const DEFAULT_COMMUNITY_LENS = "Black women and Black communities";
export const DEFAULT_RESEARCH_PREFIX = "#Black women and minority women";

const DOMAIN_POLICIES: Record<ResearchDomain, Omit<SourcePolicy, "domain" | "searchPrefix">> = {
  medical: {
    allowDomains: [
      "medlineplus.gov",
      "nih.gov",
      "cdc.gov",
      "clinicaltrials.gov",
      "who.int",
      "acog.org",
    ],
    requiredTiers: ["primary", "public-service"],
    archiveTtlHours: 168,
    disclaimer:
      "Educational information only. It is not a diagnosis or a substitute for care from a qualified clinician.",
  },
  legal: {
    allowDomains: [
      "usa.gov",
      "lawhelp.org",
      "lsc.gov",
      "law.cornell.edu",
      "courts.gov",
      "*.uscourts.gov",
      "*.gov",
    ],
    requiredTiers: ["primary", "public-service"],
    archiveTtlHours: 72,
    disclaimer:
      "General legal information only. Laws and procedures vary by jurisdiction; this is not legal advice.",
  },
  financial: {
    allowDomains: ["consumerfinance.gov", "investor.gov", "sec.gov", "irs.gov", "usa.gov"],
    requiredTiers: ["primary", "public-service"],
    archiveTtlHours: 72,
    disclaimer:
      "General financial education only. It is not individualized investment, tax, insurance, or financial advice.",
  },
  education: {
    allowDomains: ["ed.gov", "studentaid.gov", "nsf.gov", "nces.ed.gov", "*.edu", "*.gov"],
    requiredTiers: ["primary", "public-service", "community-expert"],
    archiveTtlHours: 336,
    disclaimer: null,
  },
  stem: {
    allowDomains: ["nsf.gov", "nasa.gov", "nih.gov", "aaas.org", "nacme.org", "*.edu", "*.gov"],
    requiredTiers: ["primary", "public-service", "community-expert"],
    archiveTtlHours: 336,
    disclaimer: null,
  },
  history: {
    allowDomains: ["loc.gov", "nps.gov", "si.edu", "archives.gov", "*.edu", "*.gov", "*.org"],
    requiredTiers: ["primary", "public-service", "community-expert"],
    archiveTtlHours: 720,
    disclaimer: null,
  },
  general: {
    allowDomains: ["*.gov", "*.edu", "*.org"],
    requiredTiers: ["primary", "public-service", "community-expert"],
    archiveTtlHours: 336,
    disclaimer: null,
  },
};

export function classifyResearchDomain(question: string): ResearchDomain {
  const value = question.toLocaleLowerCase("en-US");
  if (/\b(symptom|diagnosis|treatment|medicine|health|pregnan|mental health|doctor|clinical)\b/.test(value)) {
    return "medical";
  }
  if (/\b(law|legal|court|rights|eviction|custody|contract|attorney|lawsuit)\b/.test(value)) {
    return "legal";
  }
  if (/\b(invest|debt|credit|tax|insurance|retirement|mortgage|loan|financial)\b/.test(value)) {
    return "financial";
  }
  if (/\b(stem|science|technology|engineering|math|mathematics|coding)\b/.test(value)) {
    return "stem";
  }
  if (/\b(history|historic|archive|heritage|museum|civil rights)\b/.test(value)) {
    return "history";
  }
  if (/\b(school|college|university|scholarship|student|education)\b/.test(value)) {
    return "education";
  }
  return "general";
}

function includesCommunityLens(value: string): boolean {
  return /\b(black|african american|african-american|minority women|women of color|diaspora)\b/i.test(value);
}

/**
 * Kinfolk applies the community lens before external research. It does not
 * overwrite a lens that the member stated themselves.
 */
export function buildCommunityResearchQuery(question: string, domain: ResearchDomain): string {
  const trimmed = question.trim();
  const policy = DOMAIN_POLICIES[domain];
  // The #Black prefix is intentional product behavior: it applies the
  // community lens before Kinfolk queries the web, including for STEM.
  const communityContext = includesCommunityLens(trimmed) ? "" : `${DEFAULT_RESEARCH_PREFIX} `;
  return `${communityContext}${trimmed} ${policy.allowDomains
    .slice(0, 3)
    .map((domainName) => `site:${domainName.replace(/^\*\./, "")}`)
    .join(" OR ")}`;
}

export function getResearchPolicy(question: string): SourcePolicy {
  const domain = classifyResearchDomain(question);
  const policy = DOMAIN_POLICIES[domain];
  return {
    domain,
    searchPrefix: includesCommunityLens(question) ? "" : DEFAULT_RESEARCH_PREFIX,
    ...policy,
  };
}

export function isTrustedResearchUrl(url: string, policy: SourcePolicy): boolean {
  try {
    const hostname = new URL(url).hostname.toLocaleLowerCase("en-US");
    return policy.allowDomains.some((allowed) => {
      const normalized = allowed.replace(/^\*\./, "");
      return hostname === normalized || hostname.endsWith(`.${normalized}`);
    });
  } catch {
    return false;
  }
}
