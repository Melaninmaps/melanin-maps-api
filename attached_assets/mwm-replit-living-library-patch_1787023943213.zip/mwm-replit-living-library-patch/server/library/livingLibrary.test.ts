import { describe, expect, it, vi } from "vitest";
import { answerAndArchiveResearchQuestion } from "./livingLibrary";
import type { LibraryEntry, LibraryRepository } from "./types";

function entryFromSaved(input: Parameters<LibraryRepository["saveEntry"]>[0]): LibraryEntry {
  return {
    id: "entry-1",
    topicId: "topic-1",
    question: input.question,
    normalizedQuestion: input.normalizedQuestion,
    title: input.title,
    summary: input.summary,
    body: input.body,
    domain: input.domain,
    communityLens: input.communityLens,
    locationLabel: input.locationLabel,
    disclaimer: input.disclaimer,
    sourceCount: input.sourceCount,
    sources: input.sources,
    createdAt: new Date("2026-08-17T00:00:00.000Z"),
    refreshedAt: new Date("2026-08-17T00:00:00.000Z"),
  };
}

function createRepository(existing: LibraryEntry | null = null): LibraryRepository {
  return {
    findReusableEntry: vi.fn(async () => existing),
    saveEntry: vi.fn(async (input) => entryFromSaved(input)),
    listTopics: vi.fn(async () => []),
    findTopicBySlug: vi.fn(async () => null),
    listTopicEntries: vi.fn(async () => []),
    setTopicFollow: vi.fn(async () => undefined),
  };
}

const sources = [
  {
    url: "https://www.nsf.gov/example",
    title: "STEM opportunity source",
    content: "A sufficiently detailed official source about STEM pathways, access, and educational opportunity for students and professionals.",
    publisher: "National Science Foundation",
    publishedAt: null,
  },
  {
    url: "https://www.nasa.gov/example",
    title: "STEM careers source",
    content: "A sufficiently detailed official source about STEM careers, learning pathways, mentoring, and practical exploration opportunities.",
    publisher: "NASA",
    publishedAt: null,
  },
];

describe("living Library research", () => {
  it("applies the #Black women and minority women lens before a STEM web search", async () => {
    const repository = createRepository();
    const researchProvider = { search: vi.fn(async () => sources) };
    const writer = {
      writeStructured: vi.fn(async () => ({
        title: "STEM pathways",
        summary: "A source-cited summary.",
        body: "A fuller source-cited explanation.",
        citedSourceIndexes: [0, 1],
      })),
    };

    await answerAndArchiveResearchQuestion({
      question: "STEM opportunities",
      locationLabel: null,
      repository,
      researchProvider,
      writer,
    });

    expect(researchProvider.search).toHaveBeenCalledWith(
      expect.objectContaining({ query: expect.stringContaining("#Black women and minority women STEM opportunities") }),
    );
    expect(repository.saveEntry).toHaveBeenCalledWith(
      expect.objectContaining({ topicSlug: "stem", sourceCount: 2, communityLens: "Black women and Black communities" }),
    );
  });

  it("returns a current prior entry instead of losing or duplicating the same research", async () => {
    const reusable = entryFromSaved({
      topicSlug: "stem",
      question: "STEM opportunities",
      normalizedQuestion: "stem opportunities",
      title: "Existing STEM pathways",
      summary: "Existing summary",
      body: "Existing body",
      domain: "stem",
      communityLens: "Black women and Black communities",
      locationLabel: null,
      disclaimer: null,
      sourceCount: 1,
      sources: [],
    });
    const repository = createRepository(reusable);
    const researchProvider = { search: vi.fn() };
    const writer = { writeStructured: vi.fn() };

    const result = await answerAndArchiveResearchQuestion({
      question: "STEM opportunities",
      locationLabel: null,
      repository,
      researchProvider,
      writer,
    });

    expect(result.reused).toBe(true);
    expect(result.entry.id).toBe("entry-1");
    expect(researchProvider.search).not.toHaveBeenCalled();
  });

  it("labels legal research as general information and retains source links", async () => {
    const repository = createRepository();
    const researchProvider = {
      search: vi.fn(async () => [
        {
          url: "https://www.usa.gov/legal-aid",
          title: "Legal aid",
          content: "A detailed government page about finding legal support and public legal-help resources.",
          publisher: "USA.gov",
          publishedAt: null,
        },
        {
          url: "https://www.lawhelp.org/resource/example",
          title: "Legal help guide",
          content: "A detailed nonprofit legal-help guide about navigating a common legal issue and finding local assistance.",
          publisher: "LawHelp.org",
          publishedAt: null,
        },
      ]),
    };
    const writer = {
      writeStructured: vi.fn(async () => ({
        title: "Finding legal help",
        summary: "A sourced overview.",
        body: "A sourced explanation.",
        citedSourceIndexes: [0, 1],
      })),
    };

    const { entry } = await answerAndArchiveResearchQuestion({
      question: "How can I find legal help?",
      locationLabel: "Charlotte, NC",
      repository,
      researchProvider,
      writer,
    });

    expect(entry.disclaimer).toContain("not legal advice");
    expect(entry.sources.map((source) => source.url)).toEqual([
      "https://www.usa.gov/legal-aid",
      "https://www.lawhelp.org/resource/example",
    ]);
  });
});
