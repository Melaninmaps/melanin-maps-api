import assert from "node:assert/strict";
import { buildPurposefulExplorePlan } from "./server/explore/explorePlanner";

async function main() {
  const plan = await buildPurposefulExplorePlan(
    {
      async resolveLocationFromPrompt() {
        return { label: "Charlotte, NC", cityId: "charlotte" };
      },
      async findPurposefulCandidates() {
        return [
          { id: "cultural", kind: "cultural-site" as const, title: "Historic place", description: "Context", detailUrl: "/cultural-sites/1", relevanceScore: 100 },
          { id: "event", kind: "event" as const, title: "Community event", description: "Current happening", detailUrl: "/events/1", relevanceScore: 90 },
          { id: "business-1", kind: "business" as const, title: "Business one", description: "Support", detailUrl: "/businesses/1", relevanceScore: 80 },
          { id: "business-2", kind: "business" as const, title: "Business two", description: "Support", detailUrl: "/businesses/2", relevanceScore: 70 },
          { id: "business-3", kind: "business" as const, title: "Business three", description: "Must be excluded", detailUrl: "/businesses/3", relevanceScore: 60 },
        ];
      },
    },
    "Black art and dinner in Charlotte",
  );

  assert.equal(plan.locationLabel, "Charlotte, NC");
  assert.equal(plan.stops.filter((stop) => stop.kind === "business").length, 2);
  assert.deepEqual(plan.stops.map((stop) => stop.kind), ["cultural-site", "event", "business", "business"]);
  console.log("Explore planner smoke test passed.");
}

void main();
