import { useState } from "react";

type MusicExplorationOptionId =
  | "music_events"
  | "music_venues"
  | "artist_detail"
  | "dismiss";

type MusicExplorationOption = {
  id: MusicExplorationOptionId;
  label: string;
};

type MusicEvent = {
  id: string;
  name: string;
  startsAt: string;
  venueName: string | null;
  city: string;
  stateCode: string;
  category: string | null;
  organizerUrl: string | null;
  detailUrl: string | null;
};

type MusicVenue = {
  id: string;
  name: string;
  city: string;
  stateCode: string;
  category: string;
  addressLine1: string | null;
  detailUrl: string;
};

type ArtistDetail = {
  artist: string;
  summary: string;
  sourceUrl: string | null;
};

type ArtistPicker = {
  kind: "artist_picker";
  prompt: string;
  artists: string[];
};

type MusicResults =
  | { kind: "none"; items: [] }
  | { kind: "events"; items: MusicEvent[]; sourceNote: string }
  | { kind: "venues"; items: MusicVenue[]; sourceNote: null }
  | { kind: "artist_detail"; items: ArtistDetail[]; sourceNote: null }
  | { kind: "artist_picker"; items: ArtistPicker[]; sourceNote: null };

export type KinfolkMusicExplorationResponse = {
  intent: "culture_music_information";
  answer: string;
  sourceNote: string | null;
  explorationPrompt: string | null;
  explorationOptions: MusicExplorationOption[];
  results: MusicResults;
};

type Props = {
  response: KinfolkMusicExplorationResponse;
  question: string;
  memberCity: { city: string | null; stateCode: string | null };
  onResponse: (response: KinfolkMusicExplorationResponse) => void;
};

function formatEventDate(isoDate: string): string {
  const date = new Date(isoDate);
  return Number.isNaN(date.valueOf())
    ? "Date to be confirmed"
    : new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric", year: "numeric" }).format(date);
}

function smallSourceNote(note: string | null): JSX.Element | null {
  return note ? <p className="mt-4 text-xs leading-5 text-[#3A1F0E]/55">{note}</p> : null;
}

export function KinfolkMusicExplorationResponse({ response, question, memberCity, onResponse }: Props) {
  const [loadingOption, setLoadingOption] = useState<MusicExplorationOptionId | null>(null);
  const [requestError, setRequestError] = useState<string | null>(null);

  async function choose(optionId: MusicExplorationOptionId, selectedArtist?: string): Promise<void> {
    setLoadingOption(optionId);
    setRequestError(null);
    try {
      const result = await fetch("/api/kinfolk/music-exploration/actions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question,
          optionId,
          selectedArtist: selectedArtist ?? null,
          memberCity,
        }),
      });
      const payload = (await result.json()) as KinfolkMusicExplorationResponse | { error?: string };
      if (!result.ok || !("intent" in payload)) {
        throw new Error("error" in payload && payload.error ? payload.error : "Kinfolk could not load that option.");
      }
      onResponse(payload);
    } catch (error) {
      setRequestError(error instanceof Error ? error.message : "Kinfolk could not load that option. Please try again.");
    } finally {
      setLoadingOption(null);
    }
  }

  return (
    <section className="rounded-2xl border border-[#3A1F0E]/10 bg-white p-5 shadow-sm" data-testid="kinfolk-music-exploration">
      <p className="text-xs font-bold uppercase tracking-[0.16em] text-[#CA922B]">Kinfolk</p>
      <p className="mt-3 whitespace-pre-wrap leading-7 text-[#3A1F0E]" data-testid="kinfolk-direct-answer">
        {response.answer}
      </p>

      {smallSourceNote(response.sourceNote)}

      {response.explorationPrompt ? (
        <div className="mt-5 rounded-xl border border-[#CA922B]/30 bg-[#CA922B]/[0.06] p-4" data-testid="kinfolk-music-chooser">
          <p className="text-sm font-semibold text-[#3A1F0E]">{response.explorationPrompt}</p>
          <div className="mt-3 flex flex-wrap gap-2">
            {response.explorationOptions.map((option) => (
              <button
                className="rounded-full border border-[#CA922B]/45 bg-transparent px-3 py-2 text-sm font-semibold text-[#3A1F0E] transition hover:bg-[#CA922B]/15 disabled:cursor-wait disabled:opacity-60"
                data-testid={`kinfolk-music-option-${option.id}`}
                disabled={loadingOption !== null}
                key={option.id}
                onClick={() => void choose(option.id)}
                type="button"
              >
                {loadingOption === option.id ? "Loading…" : option.label}
              </button>
            ))}
          </div>
        </div>
      ) : null}

      {requestError ? <p className="mt-3 text-sm text-red-700" role="alert">{requestError}</p> : null}

      {response.results.kind === "events" ? (
        <div className="mt-5" data-testid="kinfolk-music-events">
          <p className="text-sm font-bold text-[#3A1F0E]">Local music events</p>
          {response.results.items.length === 0 ? (
            <p className="mt-2 text-sm text-[#3A1F0E]/70">I do not have a qualifying upcoming local music event to show right now.</p>
          ) : (
            <ul className="mt-3 grid gap-3">
              {response.results.items.map((event) => (
                <li className="rounded-xl border border-[#3A1F0E]/10 p-4" key={event.id}>
                  <p className="font-semibold text-[#3A1F0E]">{event.name}</p>
                  <p className="mt-1 text-sm text-[#3A1F0E]/70">
                    {formatEventDate(event.startsAt)}{event.venueName ? ` · ${event.venueName}` : ""} · {event.city}, {event.stateCode}
                  </p>
                  {event.organizerUrl ? <a className="mt-2 inline-block text-sm font-semibold text-[#8A5F15] underline" href={event.organizerUrl} rel="noreferrer" target="_blank">Organizer details</a> : null}
                </li>
              ))}
            </ul>
          )}
          {smallSourceNote(response.results.sourceNote)}
        </div>
      ) : null}

      {response.results.kind === "venues" ? (
        <div className="mt-5" data-testid="kinfolk-music-venues">
          <p className="text-sm font-bold text-[#3A1F0E]">Music venues and underground clubs</p>
          {response.results.items.length === 0 ? (
            <p className="mt-2 text-sm text-[#3A1F0E]/70">I do not have a qualifying local music space to show right now.</p>
          ) : (
            <ul className="mt-3 grid gap-3">
              {response.results.items.map((venue) => (
                <li key={venue.id}>
                  <a className="block rounded-xl border border-[#3A1F0E]/10 p-4 transition hover:border-[#CA922B]/60" href={venue.detailUrl}>
                    <p className="font-semibold text-[#3A1F0E]">{venue.name}</p>
                    <p className="mt-1 text-sm text-[#3A1F0E]/70">{venue.category}{venue.addressLine1 ? ` · ${venue.addressLine1}` : ""}</p>
                  </a>
                </li>
              ))}
            </ul>
          )}
        </div>
      ) : null}

      {response.results.kind === "artist_picker" ? (
        <div className="mt-5" data-testid="kinfolk-artist-picker">
          {response.results.items.map((picker) => (
            <div key={picker.kind}>
              <p className="text-sm font-bold text-[#3A1F0E]">{picker.prompt}</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {picker.artists.map((artist) => (
                  <button
                    className="rounded-full border border-[#CA922B]/45 bg-transparent px-3 py-2 text-sm font-semibold text-[#3A1F0E] transition hover:bg-[#CA922B]/15 disabled:cursor-wait disabled:opacity-60"
                    disabled={loadingOption !== null}
                    key={artist}
                    onClick={() => void choose("artist_detail", artist)}
                    type="button"
                  >
                    {loadingOption === "artist_detail" ? "Loading…" : artist}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      ) : null}

      {response.results.kind === "artist_detail" ? (
        <div className="mt-5" data-testid="kinfolk-artist-detail">
          {response.results.items.map((detail) => (
            <article className="rounded-xl border border-[#3A1F0E]/10 p-4" key={detail.artist}>
              <p className="font-semibold text-[#3A1F0E]">{detail.artist}</p>
              <p className="mt-2 text-sm leading-6 text-[#3A1F0E]/75">{detail.summary}</p>
              {detail.sourceUrl ? <a className="mt-2 inline-block text-sm font-semibold text-[#8A5F15] underline" href={detail.sourceUrl} rel="noreferrer" target="_blank">Learn more</a> : null}
            </article>
          ))}
        </div>
      ) : null}
    </section>
  );
}
