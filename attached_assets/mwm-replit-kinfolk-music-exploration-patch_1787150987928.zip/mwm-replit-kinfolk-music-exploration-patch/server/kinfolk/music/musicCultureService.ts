import {
  APPROVED_MUSIC_VENUE_CATEGORIES,
  MUSIC_EXPLORATION_OPTIONS,
  type MemberCityContext,
  type MusicCultureRepository,
  type MusicCultureResponse,
  type MusicCultureTurn,
  type MusicEvent,
  type MusicExplorationActionInput,
  type MusicExplorationOptionId,
  type MusicExplorationTurn,
  type MusicVenue,
  type ResolvedMusicCity,
} from "./types";

const MUSIC_CULTURE_PATTERN = /\b(rapper|rappers|rap|hip[ -]?hop|hiphop|artist|artists|music scene|music culture|atl music|atlanta music)\b/i;
const ATL_ALIAS_PATTERN = /\b(atl|atlanta)\b/i;
const MUSIC_EVENT_PATTERN = /\b(event|events|show|shows|concert|concerts|festival|festivals|tonight|this weekend)\b/i;
const MUSIC_VENUE_PATTERN = /\b(venue|venues|club|clubs|underground|listening room|live music|nightclub)\b/i;

/**
 * This intent deliberately runs before generic business discovery and before
 * guide generation. A culture/music question is not permission to preload
 * restaurants, bookstores, retail listings, or a city guide.
 */
export function isMusicCultureQuestion(question: string): boolean {
  return MUSIC_CULTURE_PATTERN.test(question);
}

export function shouldHandleAsMusicCulture(question: string): boolean {
  // A direct local event/venue request may still use this service, but the
  // member must choose a path when the first question is a cultural overview.
  return isMusicCultureQuestion(question) || (ATL_ALIAS_PATTERN.test(question) && (MUSIC_EVENT_PATTERN.test(question) || MUSIC_VENUE_PATTERN.test(question)));
}

function normalize(value: string): string {
  return value
    .toLocaleLowerCase("en-US")
    .replace(/[\u2010-\u2015]/g, "-")
    .replace(/[^\p{L}\p{N}\s-]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function includesAlias(question: string, alias: string): boolean {
  return ` ${normalize(question)} `.includes(` ${normalize(alias)} `);
}

export async function resolveMusicCity(input: {
  question: string;
  memberCity: MemberCityContext;
  repository: Pick<MusicCultureRepository, "listCityAliases">;
}): Promise<ResolvedMusicCity | null> {
  const aliases = await input.repository.listCityAliases();
  const normalizedQuestion = normalize(input.question);

  const directMatch = aliases
    .map((candidate) => ({ candidate, normalizedAlias: normalize(candidate.alias) }))
    .filter(({ normalizedAlias }) => normalizedAlias.length > 1)
    .sort((left, right) => right.normalizedAlias.length - left.normalizedAlias.length)
    .find(({ normalizedAlias }) => ` ${normalizedQuestion} `.includes(` ${normalizedAlias} `));

  if (directMatch) {
    const { cityId, name, stateCode } = directMatch.candidate;
    return { cityId, name, stateCode };
  }

  // ATL must resolve to Atlanta, Georgia even when the alias table was seeded
  // without an explicit "ATL" alias. No city prompt may follow an ATL question.
  if (ATL_ALIAS_PATTERN.test(input.question)) {
    const atlanta = aliases.find(
      (candidate) => normalize(candidate.name) === "atlanta" && candidate.stateCode.toUpperCase() === "GA",
    );
    if (atlanta) return { cityId: atlanta.cityId, name: atlanta.name, stateCode: atlanta.stateCode };
  }

  if (!input.memberCity.city) return null;
  const memberCity = aliases.find(
    (candidate) =>
      normalize(candidate.name) === normalize(input.memberCity.city ?? "") &&
      candidate.stateCode.toUpperCase() === (input.memberCity.stateCode ?? "").toUpperCase(),
  );
  return memberCity ? { cityId: memberCity.cityId, name: memberCity.name, stateCode: memberCity.stateCode } : null;
}

function directCulturalAnswer(question: string, city: ResolvedMusicCity | null): string {
  const location = city?.name === "Atlanta" && city.stateCode.toUpperCase() === "GA" ? "Atlanta and the wider metro scene" : city ? `${city.name}, ${city.stateCode}` : "the local scene";

  // The phrase "commonly connected" intentionally avoids claiming every artist
  // was born in Atlanta. The detailed artist path is where sourced biography
  // belongs. No generic source disclaimer is appended to this answer.
  if (/\b(rapper|rappers|rap|hip[ -]?hop|hiphop)\b/i.test(question)) {
    return `${location} has been central to hip-hop for decades. Artists commonly connected to Atlanta or the wider metro scene include OutKast, T.I., Ludacris, 2 Chainz, Future, Young Thug, Lil Baby, and 21 Savage. The city has shaped Southern hip-hop, trap, and many artists who came up in the Atlanta area.`;
  }

  return `${location} has a deep and evolving music culture. I can help you explore the artists, the local scene, or what is happening nearby without turning your question into a generic business list.`;
}

export async function createMusicCultureTurn(input: {
  question: string;
  memberCity: MemberCityContext;
  repository: Pick<MusicCultureRepository, "listCityAliases">;
}): Promise<MusicCultureTurn | null> {
  if (!shouldHandleAsMusicCulture(input.question)) return null;

  const resolvedCity = await resolveMusicCity(input);
  return {
    intent: "culture_music_information",
    resolvedCity,
    answer: directCulturalAnswer(input.question, resolvedCity),
    sourceNote: null,
    explorationPrompt: resolvedCity?.name === "Atlanta" && resolvedCity.stateCode.toUpperCase() === "GA"
      ? "Would you like to explore more of ATL music?"
      : "Would you like to explore more of the music scene?",
    explorationOptions: MUSIC_EXPLORATION_OPTIONS,
    results: { kind: "none", items: [] },
    guide: null,
  };
}

function isUpcoming(event: MusicEvent, nowIso: string): boolean {
  return Number.isFinite(Date.parse(event.startsAt)) && Date.parse(event.startsAt) >= Date.parse(nowIso);
}

function isAllowedVenue(venue: MusicVenue): boolean {
  return venue.isActive && venue.isVerified && APPROVED_MUSIC_VENUE_CATEGORIES.includes(venue.category as (typeof APPROVED_MUSIC_VENUE_CATEGORIES)[number]);
}

function compactEventSourceNote(): string {
  return "Event details can change. Confirm with the organizer before going.";
}

function emptyExploration(answer: string, city: ResolvedMusicCity | null): MusicExplorationTurn {
  return {
    intent: "culture_music_information",
    resolvedCity: city,
    answer,
    sourceNote: null,
    explorationPrompt: null,
    explorationOptions: [],
    results: { kind: "none", items: [] },
    guide: null,
  };
}

export async function selectMusicExploration(input: {
  action: MusicExplorationActionInput;
  repository: MusicCultureRepository;
  now?: Date;
}): Promise<MusicCultureResponse> {
  const city = await resolveMusicCity({
    question: input.action.question,
    memberCity: input.action.memberCity,
    repository: input.repository,
  });
  const answer = directCulturalAnswer(input.action.question, city);

  if (input.action.optionId === "dismiss") return emptyExploration(answer, city);

  if (!city) {
    return {
      ...emptyExploration(answer, null),
      sourceNote: null,
      results: {
        kind: "none",
        items: [],
      },
    };
  }

  if (input.action.optionId === "music_events") {
    const nowIso = (input.now ?? new Date()).toISOString();
    const events = (await input.repository.findUpcomingMusicEvents({ cityId: city.cityId, startsAfterIso: nowIso, limit: 12 }))
      .filter((event) => event.city === city.name && event.stateCode.toUpperCase() === city.stateCode.toUpperCase())
      .filter((event) => isUpcoming(event, nowIso))
      .slice(0, 6);

    return {
      ...emptyExploration(answer, city),
      sourceNote: compactEventSourceNote(),
      results: { kind: "events", items: events, sourceNote: compactEventSourceNote() },
    };
  }

  if (input.action.optionId === "music_venues") {
    const venues = (await input.repository.findVerifiedMusicVenues({
      cityId: city.cityId,
      allowedCategories: APPROVED_MUSIC_VENUE_CATEGORIES,
      limit: 12,
    }))
      .filter((venue) => venue.city === city.name && venue.stateCode.toUpperCase() === city.stateCode.toUpperCase())
      .filter(isAllowedVenue)
      .slice(0, 6);

    return {
      ...emptyExploration(answer, city),
      results: { kind: "venues", items: venues, sourceNote: null },
    };
  }

  // Artist detail never becomes a local business query. If an artist was not
  // selected, return a picker based solely on artists named in the first answer.
  if (!input.action.selectedArtist?.trim()) {
    return {
      ...emptyExploration(answer, city),
      results: {
        kind: "artist_picker",
        items: [
          {
            kind: "artist_picker",
            prompt: "Choose an artist to learn more about.",
            artists: ["OutKast", "T.I.", "Ludacris", "2 Chainz", "Future", "Young Thug", "Lil Baby", "21 Savage"],
          },
        ],
        sourceNote: null,
      },
    };
  }

  const details = await input.repository.findArtistDetails({
    cityId: city.cityId,
    artist: input.action.selectedArtist.trim(),
  });
  return {
    ...emptyExploration(answer, city),
    results: { kind: "artist_detail", items: details, sourceNote: null },
  };
}

/**
 * Guard for the existing main Kinfolk handler. Call this before generic
 * business recommendation and guide generation. A non-null response must be
 * returned immediately from the main handler.
 */
export async function maybeHandleMusicCultureQuestion(input: {
  question: string;
  memberCity: MemberCityContext;
  repository: Pick<MusicCultureRepository, "listCityAliases">;
}): Promise<MusicCultureTurn | null> {
  return createMusicCultureTurn(input);
}
