import type { Express, Request, Response } from "express";
import {
  maybeHandleMusicCultureQuestion,
  selectMusicExploration,
} from "./musicCultureService";
import type {
  MemberCityContext,
  MusicCultureRepository,
  MusicExplorationActionInput,
  MusicExplorationOptionId,
} from "./types";

const ALLOWED_ACTIONS = new Set<MusicExplorationOptionId>([
  "music_events",
  "music_venues",
  "artist_detail",
  "dismiss",
]);

function readMemberCity(req: Request): MemberCityContext {
  // Replace only this adapter with the existing authenticated member profile
  // lookup if the current handler already has it. Do not add a new profile API.
  const candidate = req.body?.memberCity;
  return {
    city: typeof candidate?.city === "string" ? candidate.city : null,
    stateCode: typeof candidate?.stateCode === "string" ? candidate.stateCode : null,
  };
}

function validQuestion(value: unknown): value is string {
  return typeof value === "string" && value.trim().length > 0 && value.trim().length <= 2_000;
}

function validAction(value: unknown): value is MusicExplorationOptionId {
  return typeof value === "string" && ALLOWED_ACTIONS.has(value as MusicExplorationOptionId);
}

/**
 * Register only the post-consent action route. The initial music turn must be
 * intercepted in the already-active main Kinfolk chat handler using the code
 * block below; do not create a second chat endpoint or alter the generic chat
 * API contract.
 */
export function registerMusicCultureRoutes(app: Express, repository: MusicCultureRepository): void {
  app.post("/api/kinfolk/music-exploration/actions", async (req: Request, res: Response) => {
    const question = req.body?.question;
    const optionId = req.body?.optionId;
    const selectedArtist = req.body?.selectedArtist;

    if (!validQuestion(question) || !validAction(optionId)) {
      return res.status(400).json({ error: "A question and valid music exploration option are required." });
    }
    if (selectedArtist !== undefined && selectedArtist !== null && typeof selectedArtist !== "string") {
      return res.status(400).json({ error: "selectedArtist must be a string when supplied." });
    }

    const action: MusicExplorationActionInput = {
      question: question.trim(),
      optionId,
      selectedArtist: typeof selectedArtist === "string" ? selectedArtist.trim() : null,
      memberCity: readMemberCity(req),
    };

    try {
      const response = await selectMusicExploration({ action, repository });
      return res.status(200).json(response);
    } catch (error) {
      console.error("Kinfolk music exploration action failed", {
        optionId: action.optionId,
        hasMemberCity: Boolean(action.memberCity.city),
        error: error instanceof Error ? error.message : String(error),
      });
      return res.status(500).json({ error: "Kinfolk could not load that music path right now. Please try again." });
    }
  });
}

/**
 * REQUIRED INSERTION IN THE EXISTING ACTIVE `POST /api/kinfolk/chat` HANDLER.
 *
 * Place this block immediately after question/member-location extraction and
 * BEFORE any generic LLM call, guide builder, business recommender, directory
 * query, or `mustVisitSpots` construction.
 *
 * Import:
 *   import { maybeHandleMusicCultureQuestion } from "./kinfolk/music/musicCultureService";
 *
 * Insert:
 *
 *   const musicTurn = await maybeHandleMusicCultureQuestion({
 *     question,
 *     memberCity: {
 *       city: member.profileCity ?? null,
 *       stateCode: member.profileStateCode ?? null,
 *     },
 *     repository: musicCultureRepository,
 *   });
 *   if (musicTurn) {
 *     return res.status(200).json({
 *       ...musicTurn,
 *       // Preserve the current Kinfolk chat envelope identifiers if required.
 *       message: musicTurn.answer,
 *     });
 *   }
 *
 * The `return` is mandatory. Without it, the generic guide/recommendation path
 * will continue and recreate the exact irrelevant cards this patch prevents.
 */
