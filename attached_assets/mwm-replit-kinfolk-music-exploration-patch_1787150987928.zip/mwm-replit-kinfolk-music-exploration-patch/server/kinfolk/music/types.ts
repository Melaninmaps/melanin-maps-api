export type MusicExplorationOptionId =
  | "music_events"
  | "music_venues"
  | "artist_detail"
  | "dismiss";

export type MusicCultureIntent = "culture_music_information";

export type ResolvedMusicCity = {
  cityId: string;
  name: string;
  stateCode: string;
};

export type MusicCityAlias = ResolvedMusicCity & {
  alias: string;
};

export type MusicExplorationOption = {
  id: MusicExplorationOptionId;
  label: string;
};

export type MusicEvent = {
  id: string;
  name: string;
  startsAt: string;
  venueName: string | null;
  city: string;
  stateCode: string;
  category: string | null;
  organizerUrl: string | null;
  detailUrl: string | null;
};

export type MusicVenue = {
  id: string;
  name: string;
  city: string;
  stateCode: string;
  category: string;
  addressLine1: string | null;
  detailUrl: string;
  isVerified: boolean;
  isActive: boolean;
};

export type ArtistDetail = {
  artist: string;
  summary: string;
  sourceUrl: string | null;
};

export type ArtistPicker = {
  kind: "artist_picker";
  prompt: string;
  artists: string[];
};

export type MusicExplorationResults =
  | { kind: "none"; items: [] }
  | { kind: "events"; items: MusicEvent[]; sourceNote: string }
  | { kind: "venues"; items: MusicVenue[]; sourceNote: null }
  | { kind: "artist_detail"; items: ArtistDetail[]; sourceNote: null }
  | { kind: "artist_picker"; items: ArtistPicker[]; sourceNote: null };

export type MusicCultureTurn = {
  intent: MusicCultureIntent;
  resolvedCity: ResolvedMusicCity | null;
  answer: string;
  sourceNote: null;
  explorationPrompt: string;
  explorationOptions: MusicExplorationOption[];
  results: { kind: "none"; items: [] };
  guide: null;
};

export type MusicExplorationTurn = {
  intent: MusicCultureIntent;
  resolvedCity: ResolvedMusicCity | null;
  answer: string;
  sourceNote: string | null;
  explorationPrompt: null;
  explorationOptions: [];
  results: MusicExplorationResults;
  guide: null;
};

export type MusicCultureResponse = MusicCultureTurn | MusicExplorationTurn;

export type MusicCultureRepository = {
  listCityAliases(): Promise<MusicCityAlias[]>;
  findUpcomingMusicEvents(input: {
    cityId: string;
    startsAfterIso: string;
    limit: number;
  }): Promise<MusicEvent[]>;
  findVerifiedMusicVenues(input: {
    cityId: string;
    allowedCategories: readonly string[];
    limit: number;
  }): Promise<MusicVenue[]>;
  findArtistDetails(input: {
    cityId: string;
    artist: string;
  }): Promise<ArtistDetail[]>;
};

export type MemberCityContext = {
  city: string | null;
  stateCode: string | null;
};

export type MusicExplorationActionInput = {
  question: string;
  optionId: MusicExplorationOptionId;
  selectedArtist?: string | null;
  memberCity: MemberCityContext;
};

export const MUSIC_EXPLORATION_OPTIONS: MusicExplorationOption[] = [
  { id: "music_events", label: "See local music events" },
  { id: "music_venues", label: "Explore music venues & underground clubs" },
  { id: "artist_detail", label: "Learn more about these artists" },
  { id: "dismiss", label: "Not right now" },
];

export const APPROVED_MUSIC_VENUE_CATEGORIES = [
  "live_music",
  "music_venue",
  "nightclub",
  "listening_room",
  "underground_music",
] as const;
