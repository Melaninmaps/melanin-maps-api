import { describe, expect, it, vi } from "vitest";
import {
  createMusicCultureTurn,
  selectMusicExploration,
} from "./musicCultureService";
import type { MusicCultureRepository } from "./types";

function repository(): MusicCultureRepository {
  return {
    listCityAliases: vi.fn(async () => [
      { cityId: "atlanta", name: "Atlanta", stateCode: "GA", alias: "Atlanta" },
      { cityId: "atlanta", name: "Atlanta", stateCode: "GA", alias: "ATL" },
    ]),
    findUpcomingMusicEvents: vi.fn(async () => [
      {
        id: "event-1",
        name: "Atlanta Hip-Hop Showcase",
        startsAt: "2026-09-01T20:00:00.000Z",
        venueName: "Music Hall",
        city: "Atlanta",
        stateCode: "GA",
        category: "hip_hop",
        organizerUrl: "https://example.com/events/1",
        detailUrl: "/events/event-1",
      },
      {
        id: "event-2",
        name: "Old Event",
        startsAt: "2026-01-01T20:00:00.000Z",
        venueName: "Old Hall",
        city: "Atlanta",
        stateCode: "GA",
        category: "hip_hop",
        organizerUrl: "https://example.com/events/2",
        detailUrl: "/events/event-2",
      },
    ]),
    findVerifiedMusicVenues: vi.fn(async () => [
      {
        id: "venue-1",
        name: "Atlanta Listening Room",
        city: "Atlanta",
        stateCode: "GA",
        category: "listening_room",
        addressLine1: "100 Music Way",
        detailUrl: "/businesses/venue-1/atlanta-listening-room",
        isVerified: true,
        isActive: true,
      },
      {
        id: "restaurant-1",
        name: "Sweet Auburn BBQ",
        city: "Atlanta",
        stateCode: "GA",
        category: "restaurant",
        addressLine1: "200 Food Way",
        detailUrl: "/businesses/restaurant-1/sweet-auburn-bbq",
        isVerified: true,
        isActive: true,
      },
      {
        id: "bookstore-1",
        name: "Spelman Bookstore & Café",
        city: "Atlanta",
        stateCode: "GA",
        category: "bookstore",
        addressLine1: "300 Books Way",
        detailUrl: "/businesses/bookstore-1/spelman-bookstore",
        isVerified: true,
        isActive: true,
      },
    ]),
    findArtistDetails: vi.fn(async ({ artist }) => [
      {
        artist,
        summary: `${artist} is commonly associated with Atlanta hip-hop culture.`,
        sourceUrl: "https://example.com/artist",
      },
    ]),
  };
}

describe("Kinfolk music culture exploration", () => {
  it("answers the Atlanta rappers question directly without a source disclaimer, guide, or preloaded results", async () => {
    const data = repository();

    const response = await createMusicCultureTurn({
      question: "what rappers are from ATL",
      memberCity: { city: null, stateCode: null },
      repository: data,
    });

    expect(response).not.toBeNull();
    expect(response?.intent).toBe("culture_music_information");
    expect(response?.resolvedCity).toMatchObject({ name: "Atlanta", stateCode: "GA" });
    expect(response?.answer).toContain("OutKast");
    expect(response?.sourceNote).toBeNull();
    expect(response?.guide).toBeNull();
    expect(response?.results).toEqual({ kind: "none", items: [] });
    expect(response?.explorationOptions.map((option) => option.id)).toEqual([
      "music_events",
      "music_venues",
      "artist_detail",
      "dismiss",
    ]);
    expect(data.findUpcomingMusicEvents).not.toHaveBeenCalled();
    expect(data.findVerifiedMusicVenues).not.toHaveBeenCalled();
  });

  it("does not retrieve anything when the member chooses not right now", async () => {
    const data = repository();

    const response = await selectMusicExploration({
      action: {
        question: "what rappers are from ATL",
        optionId: "dismiss",
        memberCity: { city: null, stateCode: null },
      },
      repository: data,
      now: new Date("2026-08-19T00:00:00.000Z"),
    });

    expect(response.results).toEqual({ kind: "none", items: [] });
    expect(data.findUpcomingMusicEvents).not.toHaveBeenCalled();
    expect(data.findVerifiedMusicVenues).not.toHaveBeenCalled();
  });

  it("returns only future local music events after consent and uses a small material source note", async () => {
    const data = repository();

    const response = await selectMusicExploration({
      action: {
        question: "what rappers are from ATL",
        optionId: "music_events",
        memberCity: { city: null, stateCode: null },
      },
      repository: data,
      now: new Date("2026-08-19T00:00:00.000Z"),
    });

    expect(response.results.kind).toBe("events");
    if (response.results.kind !== "events") throw new Error("Expected music events");
    expect(response.results.items.map((event) => event.name)).toEqual(["Atlanta Hip-Hop Showcase"]);
    expect(response.results.sourceNote).toBe("Event details can change. Confirm with the organizer before going.");
  });

  it("filters restaurants and bookstores from music-venue results", async () => {
    const data = repository();

    const response = await selectMusicExploration({
      action: {
        question: "what rappers are from ATL",
        optionId: "music_venues",
        memberCity: { city: null, stateCode: null },
      },
      repository: data,
      now: new Date("2026-08-19T00:00:00.000Z"),
    });

    expect(response.results.kind).toBe("venues");
    if (response.results.kind !== "venues") throw new Error("Expected music venues");
    expect(response.results.items.map((venue) => venue.name)).toEqual(["Atlanta Listening Room"]);
    expect(response.results.items.map((venue) => venue.category)).toEqual(["listening_room"]);
  });

  it("opens a cultural artist path instead of a business query", async () => {
    const data = repository();

    const response = await selectMusicExploration({
      action: {
        question: "what rappers are from ATL",
        optionId: "artist_detail",
        selectedArtist: "OutKast",
        memberCity: { city: null, stateCode: null },
      },
      repository: data,
      now: new Date("2026-08-19T00:00:00.000Z"),
    });

    expect(response.results.kind).toBe("artist_detail");
    if (response.results.kind !== "artist_detail") throw new Error("Expected artist details");
    expect(response.results.items[0]?.artist).toBe("OutKast");
    expect(data.findVerifiedMusicVenues).not.toHaveBeenCalled();
  });
});
