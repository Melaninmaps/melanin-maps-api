# Validated Resource Notes

## Eczema imagery

- The **Eczema in Skin of Color** Image Library is a patient-facing gallery with examples of atopic dermatitis across Black, Brown, Hispanic/Latino, and White skin. Its cards include examples such as atopic dermatitis on a Black baby’s elbow, a Hispanic baby’s face, brown skin, and Black skin.
- The library is an appropriate **external view-image destination** for queries such as `eczema`, rather than storing or reproducing clinical photographs in the application.
- Routing should label the destination descriptively: `View clinician-reviewed eczema images across darker skin tones` and make clear that photographs are educational rather than diagnostic.

Source: https://eczemainskinofcolor.org/image-library/

## Pregnancy blood-pressure safety

- CDC’s pregnancy high-blood-pressure guidance identifies preeclampsia symptoms including persistent headache, visual changes, upper stomach pain, nausea or vomiting, face or hand swelling, sudden weight gain, and trouble breathing.
- It notes that eclampsia is a medical emergency and directs people with postpartum preeclampsia symptoms to contact a clinician or call 9-1-1 right away.
- The assistant must not diagnose, should render a prominent urgent-care message for symptom-bearing pregnancy or postpartum queries, and should link to the full CDC source.

Source: https://www.cdc.gov/high-blood-pressure/about/high-blood-pressure-during-pregnancy.html

## Design consequence

For all health topics, Kenfolk should pair broad evidence with opt-in, culturally responsive context. It must not infer the user’s race, ethnicity, gender, pregnancy status, or medical condition. It should treat the default inclusion lens as a retrieval and representation rule, not an assertion about the individual user.

## Hypertension population context

- CDC reports differences in hypertension prevalence and blood-pressure control across population groups. The application can surface this as clearly labeled **population context**, linked to the underlying public-health source.
- This context must never be converted into an individual prediction, diagnosis, or default claim about the person asking. The response should offer it as: `If you want community context, here is a population-level resource.`

Source: https://www.cdc.gov/high-blood-pressure/data-research/facts-stats/index.html
