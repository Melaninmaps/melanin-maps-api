import type { Intent, Lens, MemberProfile, SearchPlan, SearchQuery } from "./types.js";
import { entityIndex } from "./library.js";

const healthTerms = [
  "eczema",
  "rash",
  "dermatitis",
  "blood pressure",
  "hypertension",
  "preeclampsia",
  "pregnan",
  "postpartum",
  "diabetes",
  "asthma",
  "pain",
  "symptom"
];

const imageTerms = ["image", "images", "picture", "pictures", "photo", "photos", "show me", "what does"];
const urgentTerms = [
  "severe headache",
  "vision changes",
  "blurry vision",
  "seeing spots",
  "trouble breathing",
  "shortness of breath",
  "chest pain",
  "upper stomach pain",
  "upper abdominal pain",
  "pregnant and swelling",
  "postpartum headache"
];

export function normalize(text: string): string {
  return text.toLowerCase().trim().replace(/\s+/g, " ");
}

export function detectIntent(query: string): Intent {
  const normalized = normalize(query);
  if (entityIndex[normalized]) return "entity";
  if (healthTerms.some((term) => normalized.includes(term))) return "health";
  if (/(news|today|latest|this week)/.test(normalized)) return "news";
  if (/(near me|nearby|in my area|local)/.test(normalized)) return "local";
  if (imageTerms.some((term) => normalized.includes(term))) return "image";
  return "general";
}

export function detectImageIntent(query: string): boolean {
  const normalized = normalize(query);
  return imageTerms.some((term) => normalized.includes(term));
}

export function isUrgentHealthQuery(query: string): boolean {
  const normalized = normalize(query);
  const pregnancyRelated = /(pregnan|postpartum|preeclampsia)/.test(normalized);
  return pregnancyRelated && urgentTerms.some((term) => normalized.includes(term));
}

function profileTerms(lenses: Lens[]): string[] {
  return lenses.flatMap((lens) => [lens.label, ...lens.searchTerms]).filter(Boolean);
}

function conditionSpecificQueries(query: string, lenses: Lens[]): string[] {
  const normalized = normalize(query);
  const lensTerms = profileTerms(lenses);
  const primaryLens = lensTerms[0] ?? "diaspora communities";

  if (/(eczema|dermatitis)/.test(normalized)) {
    return [
      "eczema in skin of color clinician reviewed images",
      `eczema ${primaryLens} trusted health resources`,
      `atopic dermatitis ${primaryLens} brown dark skin`
    ];
  }

  if (/(blood pressure|hypertension)/.test(normalized)) {
    return [
      `high blood pressure ${primaryLens} trusted health resources`,
      `hypertension ${primaryLens} community health`,
      `blood pressure ${primaryLens} population context CDC`
    ];
  }

  if (/preeclampsia|pregnan|postpartum/.test(normalized)) {
    return [
      `preeclampsia ${primaryLens} maternal health trusted resources`,
      `pregnancy blood pressure ${primaryLens} community health`,
      "preeclampsia urgent warning signs CDC"
    ];
  }

  return [`${query} ${primaryLens} trusted resources`, `${query} ${primaryLens} community context`];
}

function entityQueries(query: string, lenses: Lens[]): SearchQuery[] {
  const candidates = entityIndex[normalize(query)] ?? [];
  const lensText = profileTerms(lenses).join(" ");
  return candidates.map((candidate, index) => ({
    text: candidate.searchQuery,
    role: index === 0 ? "entity" : "general",
    reason:
      index === 0
        ? `Entity candidate prioritized by the active community/cultural lens: ${lensText || "none"}.`
        : "Alternate candidate retained to prevent false identity merging."
  }));
}

function dedupeQueries(queries: SearchQuery[]): SearchQuery[] {
  const seen = new Set<string>();
  return queries.filter((query) => {
    const key = normalize(query.text);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

/**
 * This is the critical Kinfolk behavior: the active lens is read and converted
 * to search queries before any call to a web provider. The evidence query is
 * retained alongside it so relevance does not lower the factual quality bar.
 */
export function buildSearchPlan(query: string, profile: MemberProfile): SearchPlan {
  const intent = detectIntent(query);
  const imageRequested = detectImageIntent(query);
  const urgentHealthFlag = isUrgentHealthQuery(query);
  const activeLenses = profile.active
    ? profile.lenses
        .filter((lens) => profile.activeLensIds.includes(lens.id))
        .sort((a, b) => a.priority - b.priority)
    : [];

  if (intent === "entity") {
    return {
      intent,
      activeLenses,
      imageRequested,
      urgentHealthFlag,
      queries: entityQueries(query, activeLenses)
    };
  }

  const queries: SearchQuery[] = [];
  if (activeLenses.length > 0) {
    for (const expansion of conditionSpecificQueries(query, activeLenses)) {
      queries.push({
        text: expansion,
        role: imageRequested && /(eczema|dermatitis|skin)/.test(normalize(query)) ? "image" : "community_primary",
        lensId: activeLenses[0].id,
        reason: `Primary pre-search expansion based on the active Kinfolk lens: ${activeLenses.map((lens) => lens.label).join(", ")}.`
      });
    }
  }

  queries.push({
    text: intent === "health" ? `${query} official health guidance` : query,
    role: intent === "health" ? "evidence" : "general",
    reason: "Authoritative evidence track retained for accuracy and source verification."
  });

  if (imageRequested && intent !== "health") {
    queries.push({
      text: `${query} images ${profileTerms(activeLenses).join(" ")}`.trim(),
      role: "image",
      reason: "Requested image search with the active community lens applied."
    });
  }

  return { intent, activeLenses, queries: dedupeQueries(queries), imageRequested, urgentHealthFlag };
}
