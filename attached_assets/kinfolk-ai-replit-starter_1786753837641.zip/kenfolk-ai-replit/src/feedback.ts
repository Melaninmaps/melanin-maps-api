import { randomUUID } from "node:crypto";
import type { FeedbackEvent, LibraryProposal } from "./types.js";

const feedbackEvents: FeedbackEvent[] = [];
const proposals = new Map<string, LibraryProposal>();

/**
 * The flywheel has two loops:
 * 1) a private member loop (preference signals inform that member’s ranking);
 * 2) a reviewed community-library loop. Signals can propose a source, but only
 *    an editor/clinician review can promote it to the shared library.
 */
export function recordFeedback(event: FeedbackEvent, activeLensIds: string[]): LibraryProposal | undefined {
  feedbackEvents.push(event);

  const canPropose =
    Boolean(event.resultUrl) &&
    activeLensIds.length > 0 &&
    (event.action === "helpful" || event.action === "more_like_this");

  if (!canPropose || !event.resultUrl) return undefined;

  const existing = [...proposals.values()].find(
    (proposal) =>
      proposal.url === event.resultUrl &&
      proposal.status === "proposed" &&
      proposal.proposedForLensIds.some((lensId) => activeLensIds.includes(lensId))
  );

  if (existing) {
    existing.supportingFeedbackCount += 1;
    return existing;
  }

  const proposal: LibraryProposal = {
    id: randomUUID(),
    url: event.resultUrl,
    proposedForLensIds: activeLensIds,
    supportingFeedbackCount: 1,
    status: "proposed",
    createdAt: event.createdAt
  };
  proposals.set(proposal.id, proposal);
  return proposal;
}

export function listLibraryProposals(): LibraryProposal[] {
  return [...proposals.values()].sort((a, b) => b.supportingFeedbackCount - a.supportingFeedbackCount);
}

export function getPrivateFeedback(memberId: string): FeedbackEvent[] {
  return feedbackEvents.filter((event) => event.memberId === memberId);
}
