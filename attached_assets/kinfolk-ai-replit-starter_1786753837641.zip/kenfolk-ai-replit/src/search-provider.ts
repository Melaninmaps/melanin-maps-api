import type { SearchQuery, WebResult } from "./types.js";

type TavilyResult = {
  title?: string;
  url?: string;
  content?: string;
  score?: number;
  favicon?: string;
};

type TavilySearchResponse = {
  results?: TavilyResult[];
};

export class SearchProviderError extends Error {}

/**
 * A live-web adapter. Add TAVILY_API_KEY to Replit Secrets before starting the
 * service. The rest of Kinfolk depends only on this function, so another
 * provider can replace it without changing ranking or profile logic.
 */
export async function searchWeb(query: SearchQuery, imageRequested: boolean): Promise<WebResult[]> {
  const apiKey = process.env.TAVILY_API_KEY;
  if (!apiKey) {
    throw new SearchProviderError(
      "TAVILY_API_KEY is not configured. Add it to Replit Secrets to enable live web search."
    );
  }

  const response = await fetch("https://api.tavily.com/search", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      query: query.text,
      search_depth: query.role === "evidence" ? "advanced" : "basic",
      max_results: 5,
      include_raw_content: false,
      include_images: imageRequested || query.role === "image",
      include_image_descriptions: imageRequested || query.role === "image",
      safe_search: true,
      topic: "general"
    })
  });

  if (!response.ok) {
    const message = await response.text();
    throw new SearchProviderError(`Live web search failed (${response.status}): ${message}`);
  }

  const payload = (await response.json()) as TavilySearchResponse;
  return (payload.results ?? [])
    .filter((result): result is TavilyResult & { title: string; url: string } => Boolean(result.title && result.url))
    .map((result) => ({
      title: result.title!,
      url: result.url!,
      content: result.content ?? "",
      providerScore: result.score ?? 0,
      favicon: result.favicon,
      sourceQuery: query
    }));
}

export async function searchAllQueries(queries: SearchQuery[], imageRequested: boolean): Promise<WebResult[]> {
  const batches = await Promise.all(queries.map((query) => searchWeb(query, imageRequested)));
  const seen = new Set<string>();
  return batches.flat().filter((result) => {
    if (seen.has(result.url)) return false;
    seen.add(result.url);
    return true;
  });
}
