import express from "express";
import { z } from "zod";
import { kinfolkSearch } from "./engine.js";
import { listLibraryProposals, recordFeedback } from "./feedback.js";
import { SearchProviderError } from "./search-provider.js";

const app = express();
app.use(express.json({ limit: "256kb" }));

const LensSchema = z.object({
  id: z.string().min(1),
  label: z.string().min(1).max(80),
  searchTerms: z.array(z.string().min(1).max(80)).max(12),
  region: z.string().max(80).optional(),
  language: z.string().max(24).optional(),
  priority: z.number().int().min(0).max(10)
});

const ProfileSchema = z.object({
  id: z.string().min(1).max(128),
  displayName: z.string().max(80).optional(),
  active: z.boolean(),
  activeLensIds: z.array(z.string().min(1)).max(6),
  lenses: z.array(LensSchema).max(6),
  preferredDomains: z.array(z.string().min(1).max(128)).max(20),
  blockedDomains: z.array(z.string().min(1).max(128)).max(50),
  locale: z.string().min(2).max(32)
});

const SearchRequestSchema = z.object({
  query: z.string().trim().min(1).max(500),
  profile: ProfileSchema
});

const FeedbackSchema = z.object({
  memberId: z.string().min(1).max(128),
  query: z.string().trim().min(1).max(500),
  resultUrl: z.string().url().optional(),
  resourceCardId: z.string().optional(),
  action: z.enum(["helpful", "not_helpful", "hide", "more_like_this", "report"]),
  note: z.string().max(500).optional(),
  createdAt: z.string().datetime(),
  activeLensIds: z.array(z.string().min(1)).max(6)
});

app.get("/health", (_request, response) => {
  response.json({ status: "ok", service: "kinfolk-ai-profile-first-search" });
});

app.post("/v1/search", async (request, response) => {
  const parsed = SearchRequestSchema.safeParse(request.body);
  if (!parsed.success) {
    response.status(400).json({ error: "Invalid search request", details: parsed.error.flatten() });
    return;
  }

  try {
    const result = await kinfolkSearch(parsed.data.query, parsed.data.profile);
    response.json(result);
  } catch (error) {
    if (error instanceof SearchProviderError) {
      response.status(503).json({ error: error.message });
      return;
    }
    console.error(error);
    response.status(500).json({ error: "Kinfolk could not complete this search." });
  }
});

app.post("/v1/feedback", (request, response) => {
  const parsed = FeedbackSchema.safeParse(request.body);
  if (!parsed.success) {
    response.status(400).json({ error: "Invalid feedback event", details: parsed.error.flatten() });
    return;
  }

  const { activeLensIds, ...event } = parsed.data;
  const proposal = recordFeedback(event, activeLensIds);
  response.status(202).json({
    saved: true,
    libraryProposal: proposal
      ? { id: proposal.id, status: proposal.status, message: "Saved for editorial review; feedback cannot auto-publish a shared source." }
      : undefined
  });
});

app.get("/v1/library/proposals", (request, response) => {
  if (!process.env.ADMIN_TOKEN || request.header("x-admin-token") !== process.env.ADMIN_TOKEN) {
    response.status(401).json({ error: "Admin authorization required." });
    return;
  }
  response.json({ proposals: listLibraryProposals() });
});

const port = Number(process.env.PORT ?? 3000);
app.listen(port, () => {
  console.log(`Kinfolk AI listening on port ${port}`);
});
