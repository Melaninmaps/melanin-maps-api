import type { EntityCandidate, ResourceCard } from "./types.js";

/**
 * This library is intentionally small. In production, place it in a reviewed
 * database table with source owner, medical/editorial review date, and an
 * approval workflow. Never allow raw click data to publish a resource.
 */
export const reviewedLibrary: ResourceCard[] = [
  {
    id: "eczema-skin-of-color-gallery",
    title: "Eczema in Skin of Color — Image Library",
    url: "https://eczemainskinofcolor.org/image-library/",
    description:
      "Clinician-facing and patient-facing educational images of eczema across Black, Brown, Hispanic/Latino, and White skin.",
    tags: ["eczema", "atopic dermatitis", "dermatology", "skin"],
    intent: ["health", "image"],
    representationTags: [
      "Black",
      "African diaspora",
      "Brown skin",
      "Hispanic/Latino",
      "Latine",
      "skin of color"
    ],
    type: "image_gallery",
    reviewed: true,
    safetyNote: "Educational images only; they cannot diagnose a rash."
  },
  {
    id: "cdc-pregnancy-hypertension",
    title: "CDC — High Blood Pressure During Pregnancy",
    url: "https://www.cdc.gov/high-blood-pressure/about/high-blood-pressure-during-pregnancy.html",
    description:
      "Public-health information about high blood pressure, preeclampsia, and urgent warning signs during and after pregnancy.",
    tags: ["blood pressure", "hypertension", "pregnancy", "preeclampsia", "postpartum"],
    intent: ["health"],
    representationTags: ["all communities", "Black women", "Latine", "maternal health"],
    type: "health_source",
    reviewed: true,
    safetyNote: "For symptoms such as severe headache, vision changes, trouble breathing, or upper abdominal pain during/postpartum pregnancy, seek urgent medical care."
  },
  {
    id: "cdc-hypertension-facts",
    title: "CDC — High Blood Pressure Facts",
    url: "https://www.cdc.gov/high-blood-pressure/data-research/facts-stats/index.html",
    description:
      "Population-level hypertension facts and differences in blood-pressure control by demographic group in the United States.",
    tags: ["blood pressure", "hypertension", "heart health", "population context"],
    intent: ["health"],
    representationTags: ["Black adults", "Hispanic adults", "all communities"],
    type: "health_source",
    reviewed: true,
    safetyNote: "Population data describe groups, not an individual diagnosis or outcome."
  }
];

export const entityIndex: Record<string, EntityCandidate[]> = {
  "michelle williams": [
    {
      canonicalName: "Michelle Williams",
      disambiguator: "Singer and former member of Destiny's Child",
      searchQuery: "Michelle Williams Destiny's Child singer",
      culturalContextTags: ["Black", "Black woman", "music", "R&B", "Destiny's Child"],
      verifiedSummary:
        "Michelle Williams is an American singer and a former member of the R&B group Destiny's Child."
    },
    {
      canonicalName: "Michelle Williams",
      disambiguator: "Actor known for Dawson's Creek",
      searchQuery: "Michelle Williams Dawson's Creek actor",
      culturalContextTags: ["acting", "television", "Dawson's Creek"],
      verifiedSummary:
        "Michelle Williams is an American actor known for roles including Jen Lindley in Dawson's Creek."
    }
  ]
};

export function findReviewedResources(
  normalizedQuery: string,
  intent: "health" | "image" | "entity" | "news" | "local" | "general",
  lenses: string[]
): ResourceCard[] {
  const queryWords = normalizedQuery.toLowerCase().split(/\s+/).filter(Boolean);

  return reviewedLibrary
    .filter((card) => card.reviewed && card.intent.includes(intent))
    .filter((card) => queryWords.some((word) => card.tags.some((tag) => tag.includes(word))))
    .map((card) => {
      const representationMatch = lenses.some((lens) =>
        card.representationTags.some((tag) => tag.toLowerCase().includes(lens.toLowerCase()))
      );
      return { card, representationMatch };
    })
    .sort((a, b) => Number(b.representationMatch) - Number(a.representationMatch))
    .map(({ card }) => card);
}
