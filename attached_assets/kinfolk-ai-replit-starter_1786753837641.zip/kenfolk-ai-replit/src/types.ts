export type Intent =
  | "health"
  | "image"
  | "entity"
  | "news"
  | "local"
  | "general";

export type Lens = {
  id: string;
  label: string;
  searchTerms: string[];
  region?: string;
  language?: string;
  priority: number;
};

export type MemberProfile = {
  id: string;
  displayName?: string;
  active: boolean;
  activeLensIds: string[];
  lenses: Lens[];
  preferredDomains: string[];
  blockedDomains: string[];
  locale: string;
};

export type SearchQuery = {
  text: string;
  role: "community_primary" | "evidence" | "image" | "entity" | "general";
  lensId?: string;
  reason: string;
};

export type SearchPlan = {
  intent: Intent;
  activeLenses: Lens[];
  queries: SearchQuery[];
  imageRequested: boolean;
  urgentHealthFlag: boolean;
};

export type WebResult = {
  title: string;
  url: string;
  content: string;
  providerScore: number;
  sourceQuery: SearchQuery;
  favicon?: string;
};

export type RankedResult = WebResult & {
  credibilityScore: number;
  communityScore: number;
  personalizationScore: number;
  finalScore: number;
  reasons: string[];
};

export type ResourceCard = {
  id: string;
  title: string;
  url: string;
  description: string;
  tags: string[];
  intent: Intent[];
  representationTags: string[];
  type: "image_gallery" | "health_source" | "community_source" | "entity_source";
  reviewed: boolean;
  safetyNote?: string;
};

export type EntityCandidate = {
  canonicalName: string;
  disambiguator: string;
  searchQuery: string;
  culturalContextTags: string[];
  verifiedSummary: string;
};

export type SearchResponse = {
  answerLead: string;
  activeLensDisclosure: string;
  plan: Pick<SearchPlan, "intent" | "queries" | "imageRequested" | "urgentHealthFlag">;
  results: RankedResult[];
  resourceCards: ResourceCard[];
  entityCandidates?: EntityCandidate[];
  safetyMessage?: string;
  nextAction: string;
};

export type FeedbackEvent = {
  memberId: string;
  query: string;
  resultUrl?: string;
  resourceCardId?: string;
  action: "helpful" | "not_helpful" | "hide" | "more_like_this" | "report";
  note?: string;
  createdAt: string;
};

export type LibraryProposal = {
  id: string;
  url: string;
  proposedForLensIds: string[];
  supportingFeedbackCount: number;
  status: "proposed" | "approved" | "rejected";
  createdAt: string;
};
