import type { Lens, MemberProfile, RankedResult, WebResult } from "./types.js";

const trustedDomains = [
  ".gov",
  ".edu",
  "nih.gov",
  "cdc.gov",
  "who.int",
  "acog.org",
  "heart.org",
  "nationaleczema.org",
  "eczemainskinofcolor.org",
  "skinofcolorsociety.org"
];

function hostOf(url: string): string {
  try {
    return new URL(url).hostname.toLowerCase();
  } catch {
    return "";
  }
}

function includesTerm(text: string, term: string): boolean {
  return text.toLowerCase().includes(term.toLowerCase());
}

function credibility(result: WebResult): { score: number; reasons: string[] } {
  const host = hostOf(result.url);
  const providerScore = Math.min(Math.max(result.providerScore, 0), 1);
  const trusted = trustedDomains.some((domain) => host === domain || host.endsWith(`.${domain}`));
  const govOrEdu = host.endsWith(".gov") || host.endsWith(".edu");
  const score = Math.min(1, providerScore * 0.45 + (trusted ? 0.4 : 0) + (govOrEdu ? 0.15 : 0));
  const reasons = [trusted ? "Recognized public-health, academic, or reviewed community source." : "Live-web source; verify editorial quality."];
  return { score, reasons };
}

function communityRelevance(result: WebResult, lenses: Lens[]): { score: number; reasons: string[] } {
  if (lenses.length === 0) return { score: 0, reasons: [] };

  const searchable = `${result.title} ${result.content} ${result.sourceQuery.text}`;
  const matchedLabels = lenses
    .filter((lens) => [lens.label, ...lens.searchTerms].some((term) => includesTerm(searchable, term)))
    .map((lens) => lens.label);
  const primaryTrack = result.sourceQuery.role === "community_primary" || result.sourceQuery.role === "image";
  const score = Math.min(1, (primaryTrack ? 0.6 : 0) + Math.min(0.4, matchedLabels.length * 0.25));
  const reasons = [
    ...(primaryTrack ? ["Retrieved through the profile-first community search track."] : []),
    ...(matchedLabels.length ? [`Directly matches the active lens: ${matchedLabels.join(", ")}.`] : [])
  ];
  return { score, reasons };
}

function personalizedPreference(result: WebResult, profile: MemberProfile): { score: number; reasons: string[] } {
  const host = hostOf(result.url);
  if (profile.preferredDomains.some((domain) => host === domain || host.endsWith(`.${domain}`))) {
    return { score: 1, reasons: ["Matches a member-preferred source domain."] };
  }
  return { score: 0, reasons: [] };
}

/**
 * Community relevance has a meaningful weight, but it cannot override a very
 * weak evidence score. This is how Kinfolk puts the community first without
 * lowering the factual standard.
 */
export function rankResults(results: WebResult[], profile: MemberProfile, lenses: Lens[]): RankedResult[] {
  return results
    .filter((result) => {
      const host = hostOf(result.url);
      return !profile.blockedDomains.some((domain) => host === domain || host.endsWith(`.${domain}`));
    })
    .map((result) => {
      const credibilityPart = credibility(result);
      const communityPart = communityRelevance(result, lenses);
      const personalizationPart = personalizedPreference(result, profile);
      const finalScore =
        credibilityPart.score * 0.5 + communityPart.score * 0.4 + personalizationPart.score * 0.1;

      return {
        ...result,
        credibilityScore: Number(credibilityPart.score.toFixed(3)),
        communityScore: Number(communityPart.score.toFixed(3)),
        personalizationScore: Number(personalizationPart.score.toFixed(3)),
        finalScore: Number(finalScore.toFixed(3)),
        reasons: [...credibilityPart.reasons, ...communityPart.reasons, ...personalizationPart.reasons]
      };
    })
    .sort((a, b) => b.finalScore - a.finalScore);
}
