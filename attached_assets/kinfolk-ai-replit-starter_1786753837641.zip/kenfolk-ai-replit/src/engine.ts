import { composeAnswer } from "./response-composer.js";
import { entityIndex, findReviewedResources } from "./library.js";
import { buildSearchPlan, normalize } from "./planner.js";
import { rankResults } from "./ranker.js";
import { searchAllQueries } from "./search-provider.js";
import type { EntityCandidate, MemberProfile, SearchResponse } from "./types.js";

function activeLensDisclosure(profile: MemberProfile): string {
  const lenses = profile.lenses.filter((lens) => profile.activeLensIds.includes(lens.id));
  return lenses.length
    ? `Searched with your Kinfolk lens first: ${lenses.map((lens) => lens.label).join(" + ")}.`
    : "No Kinfolk community lens is active; this search used general relevance and source quality.";
}

function emergencyMessage(urgentHealthFlag: boolean): string | undefined {
  if (!urgentHealthFlag) return undefined;
  return "Urgent: if you are pregnant or postpartum and have a severe headache, vision changes, upper-abdominal pain, chest pain, or trouble breathing, seek emergency medical care now. In the U.S., call 9-1-1 or contact your maternity care team immediately.";
}

function rankEntityCandidates(query: string, profile: MemberProfile): EntityCandidate[] | undefined {
  const candidates = entityIndex[normalize(query)];
  if (!candidates) return undefined;

  const profileTerms = profile.lenses
    .filter((lens) => profile.activeLensIds.includes(lens.id))
    .flatMap((lens) => [lens.label, ...lens.searchTerms])
    .map((term) => term.toLowerCase());

  return [...candidates].sort((a, b) => {
    const score = (candidate: EntityCandidate) =>
      candidate.culturalContextTags.reduce(
        (total, tag) => total + Number(profileTerms.some((term) => tag.toLowerCase().includes(term) || term.includes(tag.toLowerCase()))),
        0
      );
    return score(b) - score(a);
  });
}

export async function kinfolkSearch(query: string, profile: MemberProfile): Promise<SearchResponse> {
  const plan = buildSearchPlan(query, profile);
  const disclosure = activeLensDisclosure(profile);
  const activeLensLabels = plan.activeLenses.flatMap((lens) => [lens.label, ...lens.searchTerms]);
  const entityCandidates = rankEntityCandidates(query, profile);

  const libraryIntent = plan.intent === "image" ? "image" : plan.intent;
  const resourceCards = [
    ...findReviewedResources(normalize(query), libraryIntent, activeLensLabels),
    ...(plan.imageRequested && libraryIntent !== "image"
      ? findReviewedResources(normalize(query), "image", activeLensLabels)
      : [])
  ].filter((card, index, cards) => cards.findIndex((other) => other.id === card.id) === index);

  const liveResults = await searchAllQueries(plan.queries, plan.imageRequested);
  const results = rankResults(liveResults, profile, plan.activeLenses);
  const safetyMessage = emergencyMessage(plan.urgentHealthFlag);
  const answerLead = await composeAnswer({
    query,
    plan,
    activeLensDisclosure: disclosure,
    results,
    resourceCards,
    entityCandidates,
    safetyMessage
  });

  const nextAction =
    plan.intent === "entity" && entityCandidates && entityCandidates.length > 1
      ? `Choose a person: ${entityCandidates.map((candidate) => candidate.disambiguator).join(" or ")}.`
      : plan.imageRequested
        ? "Open the reviewed image gallery, then tell Kinfolk whether you want symptom information, treatment questions for a clinician, or more images."
        : plan.intent === "health"
          ? "Tell Kinfolk whether you want community context, a clinician discussion guide, pregnancy/postpartum information, or nearby care resources."
          : "Tell Kinfolk whether the primary sources fit your community lens; your feedback can improve future ranking.";

  return {
    answerLead,
    activeLensDisclosure: disclosure,
    plan: {
      intent: plan.intent,
      queries: plan.queries,
      imageRequested: plan.imageRequested,
      urgentHealthFlag: plan.urgentHealthFlag
    },
    results,
    resourceCards,
    entityCandidates,
    safetyMessage,
    nextAction
  };
}
