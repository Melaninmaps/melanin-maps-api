import assert from "node:assert/strict";
import test from "node:test";
import { buildSearchPlan } from "../src/planner.js";
import { rankResults } from "../src/ranker.js";
import type { MemberProfile, WebResult } from "../src/types.js";

const blackWomanProfile: MemberProfile = {
  id: "demo-black-woman",
  active: true,
  activeLensIds: ["black-woman"],
  lenses: [
    {
      id: "black-woman",
      label: "Black woman",
      searchTerms: ["Black women", "African American women", "African diaspora"],
      priority: 0
    }
  ],
  preferredDomains: [],
  blockedDomains: [],
  locale: "en-US"
};

test("blood-pressure query builds community-primary tracks before the evidence track", () => {
  const plan = buildSearchPlan("blood pressure", blackWomanProfile);
  assert.equal(plan.intent, "health");
  assert.equal(plan.queries[0].role, "community_primary");
  assert.match(plan.queries[0].text, /Black woman|Black women/i);
  assert.equal(plan.queries.at(-1)?.role, "evidence");
});

test("eczema image query creates a profile-first image route", () => {
  const plan = buildSearchPlan("eczema show me pictures", blackWomanProfile);
  assert.equal(plan.intent, "health");
  assert.equal(plan.imageRequested, true);
  assert.equal(plan.queries[0].role, "image");
  assert.match(plan.queries[0].text, /skin of color/i);
});

test("Michelle Williams defaults to the Destiny's Child entity search and preserves an alternate candidate", () => {
  const plan = buildSearchPlan("Michelle Williams", blackWomanProfile);
  assert.equal(plan.intent, "entity");
  assert.match(plan.queries[0].text, /Destiny's Child/i);
  assert.ok(plan.queries.some((query) => /Dawson's Creek/i.test(query.text)));
});

test("credible community-primary source ranks above an equally credible generic source", () => {
  const webResults: WebResult[] = [
    {
      title: "Generic high blood pressure guidance",
      url: "https://www.cdc.gov/high-blood-pressure/general",
      content: "Official health guidance",
      providerScore: 0.9,
      sourceQuery: { text: "blood pressure official health guidance", role: "evidence", reason: "evidence" }
    },
    {
      title: "High blood pressure resources for Black women",
      url: "https://www.cdc.gov/high-blood-pressure/black-women",
      content: "Community context for Black women",
      providerScore: 0.9,
      sourceQuery: { text: "high blood pressure Black women trusted resources", role: "community_primary", reason: "lens" }
    }
  ];

  const ranked = rankResults(webResults, blackWomanProfile, blackWomanProfile.lenses);
  assert.equal(ranked[0].title, "High blood pressure resources for Black women");
});
