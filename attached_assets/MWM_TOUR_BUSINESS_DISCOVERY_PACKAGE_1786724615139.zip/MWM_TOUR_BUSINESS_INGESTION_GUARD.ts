/* MWM TOUR INGESTION GUARD
 * Route every natural-language, screenshot, URL, and social lead through this
 * function before any business row is inserted or updated.
 */

type CandidateStatus = "VERIFIED_ADD" | "EXISTING_UPDATE" | "MANUAL_REVIEW" | "REJECTED" | "NO_MATCH";
type CandidateSource = "natural_language" | "screenshot" | "url" | "social_url" | "admin_search";

type Evidence = {
  url: string | null;
  sourceType: string;
  field: string;
  extractedAt: string;
  excerpt: string | null;
  supports: boolean;
};

type Candidate = {
  name: string;
  normalizedName: string;
  category: string | null;
  city: string | null;
  state: string | null;
  address: string | null;
  latitude: number | null;
  longitude: number | null;
  phone: string | null;
  website: string | null;
  socialProfiles: Array<{ platform: "tiktok" | "instagram" | "facebook"; url: string; handle: string | null }>;
  ownershipClaim: string | null;
  ownershipEvidence: Evidence[];
  sourceEvidence: Evidence[];
  sourceInput: CandidateSource;
};

function normalizeIdentity(value: string | null | undefined): string {
  return String(value ?? "")
    .normalize("NFKD").replace(/[\u0300-\u036f]/g, "")
    .toLowerCase().replace(/&/g, " and ")
    .replace(/[^a-z0-9]+/g, " ").trim().replace(/\s+/g, " ");
}

function normalizeUrl(value: string | null | undefined): string | null {
  if (!value) return null;
  try {
    const u = new URL(value.startsWith("http") ? value : `https://${value}`);
    u.hash = "";
    u.search = "";
    u.pathname = u.pathname.replace(/\/$/, "");
    return u.toString().toLowerCase();
  } catch { return null; }
}

function domain(value: string | null): string | null {
  const normalized = normalizeUrl(value);
  if (!normalized) return null;
  try { return new URL(normalized).hostname.replace(/^www\./, ""); } catch { return null; }
}

function socialEvidence(candidate: Candidate): Evidence[] {
  return candidate.socialProfiles.map((profile) => ({
    url: profile.url,
    sourceType: "social_profile",
    field: "social_profile",
    extractedAt: new Date().toISOString(),
    excerpt: profile.handle,
    supports: true,
  }));
}

function hasEvidence(candidate: Candidate, field: string): boolean {
  return [...candidate.sourceEvidence, ...candidate.ownershipEvidence, ...socialEvidence(candidate)]
    .some((e) => e.field === field && e.supports === true);
}

function hasLocation(candidate: Candidate): boolean {
  return Boolean(candidate.address && candidate.city && candidate.state)
    || (candidate.latitude != null && candidate.longitude != null);
}

function hasIdentityEvidence(candidate: Candidate): boolean {
  return hasEvidence(candidate, "identity") || candidate.socialProfiles.length > 0;
}

function hasOwnershipEvidence(candidate: Candidate, requestedOwnership: string | null): boolean {
  return !requestedOwnership || candidate.ownershipEvidence.some((e) => e.field === "ownership" && e.supports);
}

function distanceMeters(a: Candidate, b: Candidate): number | null {
  if (a.latitude == null || a.longitude == null || b.latitude == null || b.longitude == null) return null;
  const R = 6371000;
  const rad = (x: number) => x * Math.PI / 180;
  const dLat = rad(b.latitude - a.latitude);
  const dLon = rad(b.longitude - a.longitude);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.latitude)) * Math.cos(rad(b.latitude)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

function isSameBusiness(candidate: Candidate, existing: Candidate): boolean {
  const candidateDomain = domain(candidate.website);
  const existingDomain = domain(existing.website);
  if (candidateDomain && existingDomain && candidateDomain === existingDomain) return true;
  if (candidate.phone && existing.phone && candidate.phone.replace(/\D/g, "") === existing.phone.replace(/\D/g, "")) return true;
  const sameName = normalizeIdentity(candidate.name) === normalizeIdentity(existing.name);
  if (!sameName) return false;
  const meters = distanceMeters(candidate, existing);
  if (meters != null && meters <= 100) return true;
  if (candidate.address && existing.address && normalizeIdentity(candidate.address) === normalizeIdentity(existing.address)) return true;
  const candidateSocial = new Set(candidate.socialProfiles.map((p) => normalizeUrl(p.url)).filter(Boolean));
  return existing.socialProfiles.some((p) => candidateSocial.has(normalizeUrl(p.url)));
}

export async function ingestCandidate(
  candidate: Candidate,
  requestedOwnership: string | null,
  requestedCount: number,
  existingRecords: Candidate[],
  insertCanonical: (candidate: Candidate, dedupeKey: string) => Promise<{ id: string }>,
  updateCanonical: (id: string, candidate: Candidate) => Promise<void>,
  queueReview: (candidate: Candidate, reason: string) => Promise<void>,
) {
  if (!candidate.name.trim() || !hasIdentityEvidence(candidate) || !hasLocation(candidate)) {
    await queueReview(candidate, "missing_identity_or_location_evidence");
    return { status: "MANUAL_REVIEW" as CandidateStatus, reason: "missing_identity_or_location_evidence" };
  }
  if (!hasOwnershipEvidence(candidate, requestedOwnership)) {
    await queueReview(candidate, "ownership_not_verified");
    return { status: "MANUAL_REVIEW" as CandidateStatus, reason: "ownership_not_verified" };
  }

  const existing = existingRecords.find((row) => isSameBusiness(candidate, row));
  if (existing) {
    // Preserve user-supplied social URLs even when the existing record has no website.
    await updateCanonical(existing as any, candidate);
    return { status: "EXISTING_UPDATE" as CandidateStatus, canonicalId: (existing as any).id };
  }

  const dedupeKey = [
    normalizeIdentity(candidate.name),
    normalizeIdentity(candidate.address),
    candidate.city?.toLowerCase() ?? "",
    candidate.state?.toLowerCase() ?? "",
    domain(candidate.website) ?? "",
    candidate.phone?.replace(/\D/g, "") ?? "",
  ].join("|");

  const inserted = await insertCanonical(candidate, dedupeKey);
  return { status: "VERIFIED_ADD" as CandidateStatus, canonicalId: inserted.id };
}

export function noPaddingMessage(requested: number, verified: number, review: number): string {
  if (verified >= requested) return `I verified ${verified} businesses.`;
  return `I verified ${verified} business${verified === 1 ? "" : "es"}. I found ${review} additional lead${review === 1 ? "" : "s"} requiring review, so I did not create unverified records to reach the requested ${requested}.`;
}
