import type { Express, Request, Response, NextFunction } from "express";
import type { Pool } from "pg";

// This adapter expects the canonical community_locations index introduced with the
// location-first release: id, label, normalized_terms text[], latitude, longitude.
// If the existing app calls it cities/service_areas, map this query to that canonical table;
// do not add another competing location source.
export function registerLocationResolutionRoutes(app: Express, pool: Pool) {
  app.get("/api/locations/resolve", async (request: Request, response: Response, next: NextFunction) => {
    try {
      const q = typeof request.query.q === "string" ? request.query.q.trim().toLowerCase() : "";
      if (q.length < 2) return response.status(400).json({ code: "AREA_QUERY_REQUIRED" });
      const { rows } = await pool.query(
        `SELECT id, label, latitude, longitude
         FROM community_locations
         WHERE $1 = ANY(normalized_terms)
            OR label ILIKE $2
         ORDER BY CASE WHEN lower(label) = $1 THEN 0 ELSE 1 END, label
         LIMIT 1`,
        [q, `%${q}%`],
      );
      if (!rows[0]) return response.status(404).json({ code: "AREA_NOT_FOUND" });
      response.setHeader("Cache-Control", "no-store");
      return response.json(rows[0]);
    } catch (error) { return next(error); }
  });

  app.get("/api/locations/reverse", async (request: Request, response: Response, next: NextFunction) => {
    try {
      const latitude = Number(request.query.lat);
      const longitude = Number(request.query.lng);
      if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) return response.status(400).json({ code: "COORDINATES_REQUIRED" });
      const { rows } = await pool.query(
        `SELECT id, label, latitude, longitude,
          (6371 * acos(least(1, greatest(-1,
            cos(radians($1)) * cos(radians(latitude)) * cos(radians(longitude) - radians($2)) +
            sin(radians($1)) * sin(radians(latitude))
          )))) AS distance_km
         FROM community_locations
         WHERE latitude IS NOT NULL AND longitude IS NOT NULL
         ORDER BY distance_km ASC
         LIMIT 1`,
        [latitude, longitude],
      );
      if (!rows[0] || Number(rows[0].distance_km) > 80) return response.status(404).json({ code: "NO_SUPPORTED_AREA_NEARBY" });
      response.setHeader("Cache-Control", "no-store");
      return response.json(rows[0]);
    } catch (error) { return next(error); }
  });
}
