import { expect, test } from "@playwright/test";

for (const route of ["/businesses", "/explore", "/events"]) {
  test(`${route} shows typed area text with a visible foreground color`, async ({ page }) => {
    await page.goto(route);
    const areaInput = page.getByRole("searchbox", { name: "Search area" });
    await areaInput.fill("Charlotte, NC");
    await expect(areaInput).toHaveValue("Charlotte, NC");
    await expect(areaInput).toHaveCSS("color", "rgb(40, 20, 10)");
    await expect(areaInput).toHaveCSS("-webkit-text-fill-color", "rgb(40, 20, 10)");
  });
}

test("Businesses resolves a typed city and visibly reports the selected area", async ({ page }) => {
  await page.route("**/api/locations/resolve?q=Charlotte%2C%20NC", async (route) => route.fulfill({ json: { id: "charlotte-nc", label: "Charlotte, NC", latitude: 35.2271, longitude: -80.8431 } }));
  await page.goto("/businesses");
  await page.getByRole("searchbox", { name: "Search area" }).fill("Charlotte, NC");
  await page.getByRole("button", { name: "Search area" }).click();
  await expect(page.getByText("Showing results for Charlotte, NC.")).toBeVisible();
});

test("location permission denial gives a visible manual-area instruction rather than silently failing", async ({ page, context }) => {
  await context.grantPermissions([], { origin: "https://www.mappingwithmelanin.com" });
  await page.goto("/explore");
  await page.getByRole("button", { name: "Use my location" }).click();
  await expect(page.getByText(/location permission was not granted|enter a city/i)).toBeVisible();
});
