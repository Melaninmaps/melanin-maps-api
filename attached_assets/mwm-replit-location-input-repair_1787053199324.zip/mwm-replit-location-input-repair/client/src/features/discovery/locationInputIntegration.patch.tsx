import { LocationSearchBar } from "../location/LocationSearchBar";
import "../../styles/location-search.css";

// BUSINESSES PAGE
// Replace the two existing invisible inputs, "Search area" button, and "Use my location"
// button with this one shared control. Delete this literal sentence from the empty state:
// "We will not show a nationwide list and label it local."
// Keep only the concise location instruction if copy is needed:
// <p className="location-guidance">Location first.</p>
<LocationSearchBar
  queryLabel="What are you looking for?"
  queryPlaceholder="Search businesses or services"
  areaPlaceholder="City, neighborhood, or ZIP"
  initialQuery={searchQuery}
  initialAreaLabel={locationContext.label ?? ""}
  submitLabel="Search area"
  onResolved={({ query, area }) => {
    setSearchQuery(query);
    setLocationContext(area);
    runBusinessSearch({ query, areaId: area.id });
  }}
/>;

// EXPLORE PAGE
// Explore does not duplicate business search. It only needs an area. Replace its current
// invisible location input and "Explore this area" button with this control.
<LocationSearchBar
  queryLabel="Explore theme"
  queryPlaceholder=""
  areaPlaceholder="City or neighborhood"
  initialAreaLabel={locationContext.label ?? ""}
  showQuery={false}
  submitLabel="Explore this area"
  onResolved={({ area }) => {
    setLocationContext(area);
    loadPurposefulExplorePlan({ areaId: area.id, selectedThemes });
  }}
/>;

// EVENTS PAGE
// Use the same area resolver. Date and topic filters remain separate from location.
<LocationSearchBar
  queryLabel="Event search"
  queryPlaceholder=""
  areaPlaceholder="City or neighborhood"
  initialAreaLabel={locationContext.label ?? ""}
  showQuery={false}
  submitLabel="Show events"
  onResolved={({ area }) => {
    setLocationContext(area);
    loadEvents({ areaId: area.id, dateRange, categories: selectedCategories });
  }}
/>;

// All three pages must use the same location context provider. Do not leave any old
// `navigator.geolocation` calls or page-local CSS input colors in place, or the bugs will
// reappear in one of the flows.
