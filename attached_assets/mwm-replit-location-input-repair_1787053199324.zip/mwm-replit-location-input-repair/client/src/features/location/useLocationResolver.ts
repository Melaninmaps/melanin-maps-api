import { useCallback, useState } from "react";

export type ResolvedArea = {
  id: string;
  label: string;
  latitude: number;
  longitude: number;
};

type ResolutionState = "idle" | "locating" | "resolving" | "ready" | "error";

export function useLocationResolver() {
  const [state, setState] = useState<ResolutionState>("idle");
  const [error, setError] = useState<string | null>(null);

  const resolveAreaText = useCallback(async (areaText: string): Promise<ResolvedArea | null> => {
    const q = areaText.trim();
    if (!q) { setError("Enter a city, neighborhood, or ZIP code first."); setState("error"); return null; }
    setError(null); setState("resolving");
    try {
      const response = await fetch(`/api/locations/resolve?q=${encodeURIComponent(q)}`, { headers: { Accept: "application/json" } });
      if (response.status === 404) throw new Error("We could not find that area. Try a city and state, for example Charlotte, NC.");
      if (!response.ok) throw new Error("We could not search that area right now. Please try again.");
      const result = await response.json() as ResolvedArea;
      setState("ready");
      return result;
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "We could not search that area right now."); setState("error"); return null;
    }
  }, []);

  const useBrowserLocation = useCallback(async (): Promise<ResolvedArea | null> => {
    if (!window.isSecureContext || !navigator.geolocation) {
      setError("Location sharing requires a supported browser over a secure connection. You can enter a city instead."); setState("error"); return null;
    }
    setError(null); setState("locating");
    const position = await new Promise<GeolocationPosition | null>((resolve) => {
      navigator.geolocation.getCurrentPosition(resolve, (geolocationError) => {
        const message = geolocationError.code === geolocationError.PERMISSION_DENIED
          ? "Location permission was not granted. Enter a city or neighborhood instead."
          : geolocationError.code === geolocationError.TIMEOUT
            ? "Location lookup timed out. Enter a city or try again."
            : "Your location could not be determined. Enter a city or neighborhood instead.";
        setError(message); setState("error"); resolve(null);
      }, { enableHighAccuracy: false, timeout: 10_000, maximumAge: 300_000 });
    });
    if (!position) return null;

    setState("resolving");
    try {
      const { latitude, longitude } = position.coords;
      const response = await fetch(`/api/locations/reverse?lat=${encodeURIComponent(latitude)}&lng=${encodeURIComponent(longitude)}`, { headers: { Accept: "application/json" } });
      if (!response.ok) throw new Error("We found your approximate location but could not identify the area. Enter a city instead.");
      const result = await response.json() as ResolvedArea;
      setState("ready");
      return result;
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "We could not identify your area."); setState("error"); return null;
    }
  }, []);

  return { state, error, resolveAreaText, useBrowserLocation };
}
