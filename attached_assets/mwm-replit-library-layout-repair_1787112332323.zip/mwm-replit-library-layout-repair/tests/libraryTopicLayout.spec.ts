import { expect, test } from "vitest";
import { readFileSync } from "node:fs";

const css = readFileSync("client/src/features/library/libraryTopicPage.css", "utf8");
const page = readFileSync("client/src/features/library/ReadableLibraryTopicPage.tsx", "utf8");

test("uses readable light Library text on the dark topic surface", () => {
  expect(css).toContain("--library-copy:#fff2dd");
  expect(css).toContain("--library-surface:#fffaf0");
  expect(css).not.toMatch(/color:\s*#240c04;\s*\/\* topic copy/i);
});

test("keeps the footer in normal flow after the main content", () => {
  expect(css).toContain(".app-shell__main { flex:1 0 auto; }");
  expect(css).toContain(".app-shell__footer { flex:0 0 auto; margin-top:auto; position:static; }");
  expect(css).not.toMatch(/\.app-shell__footer\s*\{[^}]*position:\s*fixed/i);
});

test("makes a topic book distinct from the full Library and restores topic discovery", () => {
  expect(page).toContain("← All topics");
  expect(page).toContain("Living Library · Topic book");
  expect(page).toContain("Related foundations");
});

test("does not pretend an empty foundation has entries", () => {
  expect(page).toContain("This foundation is ready to grow.");
  expect(page).toContain("topic.entries.length");
});
