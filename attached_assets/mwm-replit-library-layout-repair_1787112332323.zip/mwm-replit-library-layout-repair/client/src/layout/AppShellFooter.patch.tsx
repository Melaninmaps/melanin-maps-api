// App shell replacement. Keep the footer outside every page component and after <main>.
export function AppShell({ children }: { children: React.ReactNode }) {
  return <div className="app-shell"><SiteHeader /><main className="app-shell__main">{children}</main><SiteFooter /></div>;
}

// Do not use any of the following for the global footer:
// position: fixed; bottom: 0; height: 40vh; min-height: 420px;
// Do not insert <SiteFooter /> inside a Library route or topic component.
