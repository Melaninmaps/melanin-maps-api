export type CommunityIntelligenceTopic =
  | "music"
  | "art"
  | "market_pricing"
  | "health"
  | "housing"
  | "legal"
  | "education"
  | "home_service"
  | "travel"
  | "business_discovery"
  | "general";

export type RequestType =
  | "general_information"
  | "local_discovery"
  | "current_events"
  | "price_or_trend"
  | "artist_or_place_detail"
  | "professional_support"
  | "practical_how_to"
  | "community_context";

export type FreshnessNeed = "durable" | "current" | "live";
export type RiskLevel = "ordinary" | "decision_support" | "high_stakes";
export type LocationState = "provided" | "inferred" | "optional" | "needed" | "not_needed";

export type ExplorationOptionId =
  | "music_events"
  | "music_venues"
  | "artist_detail"
  | "art_events"
  | "galleries_studios_artwalks"
  | "local_artists"
  | "housing_price_trends"
  | "homebuyer_resources"
  | "local_housing_support"
  | "grocery_price_sources"
  | "local_affordability_resources"
  | "art_market_context"
  | "health_basics"
  | "clinician_questions"
  | "community_informed_support"
  | "local_professional_options"
  | "legal_resources"
  | "education_pathways"
  | "local_events"
  | "dismiss";

export type ExplorationOption = {
  id: ExplorationOptionId;
  label: string;
  requiresConsent: true;
};

export type ResearchPlan = {
  needed: boolean;
  diasporicLensRequired: boolean;
  queryGuidance: string[];
  allowedSources: Array<"living_library" | "reputable_web" | "verified_directory" | "verified_events" | "moderated_community_signals">;
};

export type SourceNotePolicy =
  | { kind: "none" }
  | { kind: "current_detail"; text: "Current details can change. Confirm with the original source before acting." }
  | { kind: "high_stakes"; text: string };

export type KinfolkCommunityIntelligencePlan = {
  topic: CommunityIntelligenceTopic;
  requestType: RequestType;
  locationState: LocationState;
  resolvedLocation: { city: string; stateCode: string | null } | null;
  freshnessNeed: FreshnessNeed;
  riskLevel: RiskLevel;
  needsClarification: boolean;
  clarificationQuestion: string | null;
  directAnswerInstruction: string;
  explorationPrompt: string | null;
  explorationOptions: ExplorationOption[];
  researchPlan: ResearchPlan;
  sourceNotePolicy: SourceNotePolicy;
  forbidAutoResults: true;
  forbidGenericGuide: true;
  forbidUnrelatedBusinessFallback: true;
  communityLearningDestination: "living_library" | "moderated_community_signal" | "coverage_gap" | "none";
};

export type KinfolkCommunityIntelligenceInput = {
  question: string;
  memberCity: string | null;
  memberStateCode: string | null;
  preferredTone: "warm_standard" | "community_conversational" | "concise_professional";
};
