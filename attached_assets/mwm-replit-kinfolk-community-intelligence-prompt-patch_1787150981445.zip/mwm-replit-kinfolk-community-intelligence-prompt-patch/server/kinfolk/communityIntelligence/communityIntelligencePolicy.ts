import type {
  CommunityIntelligenceTopic,
  ExplorationOption,
  FreshnessNeed,
  KinfolkCommunityIntelligenceInput,
  KinfolkCommunityIntelligencePlan,
  RequestType,
  RiskLevel,
} from "./types";

const MUSIC_PATTERN = /\b(rapper|rappers|rap|hip[ -]?hop|hiphop|music scene|music culture|artist|artists|concert|venue|club|underground)\b/i;
const ART_PATTERN = /\b(art scene|art|artist|artists|gallery|galleries|museum|mural|murals|studio|studios|art walk|exhibit|exhibition)\b/i;
const HEALTH_PATTERN = /\b(health|medical|doctor|symptom|clinic|pregnan|therapy|mental health|medicine|diagnosis|heart|alopecia|hair loss|thinning hair)\b/i;
const LEGAL_PATTERN = /\b(law|legal|rights|court|attorney|lawyer|eviction|lease|custody|contract|sue|lawsuit)\b/i;
const HOUSING_PATTERN = /\b(housing|home price|rent|mortgage|homebuyer|real estate|property value|eviction|lease)\b/i;
const MARKET_PATTERN = /\b(market|pricing|prices|cost of living|affordability|affordable|grocery|groceries|retail)\b/i;
const EDUCATION_PATTERN = /\b(school|college|university|scholarship|student|education|stem|science|engineering|math|trade school|trades)\b/i;
const HOME_SERVICE_PATTERN = /\b(plumb|pipe|drain|leak|water heater|toilet|faucet|sewer)\b/i;
const CURRENT_PATTERN = /\b(today|tonight|this weekend|current|now|upcoming|open|hours|available|price|pricing|cost|market)\b/i;
const URGENT_HEALTH_PATTERN = /\b(chest pain|cannot breathe|can'?t breathe|overdose|suicid|self harm|severe bleeding|stroke)\b/i;
const ATL_PATTERN = /\b(atl|atlanta)\b/i;

const DISMISS: ExplorationOption = { id: "dismiss", label: "Not right now", requiresConsent: true };

function options(...items: Array<Omit<ExplorationOption, "requiresConsent">>): ExplorationOption[] {
  return [...items.map((item) => ({ ...item, requiresConsent: true as const })), DISMISS];
}

function topicFor(question: string): CommunityIntelligenceTopic {
  // More specific topic patterns must come before broad "artist" matching.
  if (HEALTH_PATTERN.test(question)) return "health";
  if (LEGAL_PATTERN.test(question)) return "legal";
  if (HOUSING_PATTERN.test(question)) return "housing";
  if (ART_PATTERN.test(question) && !/\b(rapper|rap|hip[ -]?hop|music)\b/i.test(question)) return "art";
  if (MUSIC_PATTERN.test(question)) return "music";
  if (MARKET_PATTERN.test(question)) return "market_pricing";
  if (EDUCATION_PATTERN.test(question)) return "education";
  if (HOME_SERVICE_PATTERN.test(question)) return "home_service";
  return "general";
}

function resolveLocation(input: KinfolkCommunityIntelligenceInput): { city: string; stateCode: string | null } | null {
  if (ATL_PATTERN.test(input.question)) return { city: "Atlanta", stateCode: "GA" };
  return input.memberCity ? { city: input.memberCity, stateCode: input.memberStateCode } : null;
}

function isAmbiguousMarketQuestion(question: string): boolean {
  const hasMarket = MARKET_PATTERN.test(question);
  const specified = /\b(housing|home|rent|mortgage|real estate|grocery|groceries|food|art market|retail|stock|investment)\b/i.test(question);
  return hasMarket && !specified;
}

function researchQueryGuidance(topic: CommunityIntelligenceTopic, location: string | null): string[] {
  const place = location ? ` ${location}` : "";
  // Diaspora-first is permanent: the first research query always starts with
  // the Black-women lens, then the policy can add a topic-specific community
  // query. The retrieval layer must run this query before any general query.
  const topicPhrase: Record<CommunityIntelligenceTopic, string> = {
    music: "music and hip-hop",
    art: "art and artists",
    market_pricing: "market pricing and affordability",
    health: "health information",
    housing: "housing and homeownership",
    legal: "legal rights and resources",
    education: "education and career pathways",
    home_service: "home repair guidance",
    travel: "travel and local culture",
    business_discovery: "business discovery",
    general: "community information",
  };
  return [
    `Black women ${topicPhrase[topic]}${place}`.trim(),
    `Black diaspora ${topicPhrase[topic]}${place}`.trim(),
  ];
}

function planBase(input: KinfolkCommunityIntelligenceInput, topic: CommunityIntelligenceTopic): Omit<KinfolkCommunityIntelligencePlan, "requestType" | "freshnessNeed" | "riskLevel" | "needsClarification" | "clarificationQuestion" | "directAnswerInstruction" | "explorationPrompt" | "explorationOptions" | "sourceNotePolicy" | "communityLearningDestination"> {
  const resolvedLocation = resolveLocation(input);
  return {
    topic,
    locationState: resolvedLocation ? (ATL_PATTERN.test(input.question) ? "provided" : "inferred") : "optional",
    resolvedLocation,
    researchPlan: {
      needed: true,
      diasporicLensRequired: true,
      queryGuidance: researchQueryGuidance(topic, resolvedLocation?.city ?? null),
      allowedSources: ["living_library", "reputable_web", "verified_directory", "verified_events", "moderated_community_signals"],
    },
    forbidAutoResults: true,
    forbidGenericGuide: true,
    forbidUnrelatedBusinessFallback: true,
  };
}

function currentness(question: string): FreshnessNeed {
  return CURRENT_PATTERN.test(question) ? "current" : "durable";
}

export function resolveCommunityIntelligencePlan(input: KinfolkCommunityIntelligenceInput): KinfolkCommunityIntelligencePlan {
  const topic = topicFor(input.question);
  const base = planBase(input, topic);

  if (topic === "music") {
    return {
      ...base,
      requestType: /\b(event|events|show|concert|festival)\b/i.test(input.question)
        ? "current_events"
        : /\b(venue|venues|club|clubs|underground)\b/i.test(input.question)
          ? "local_discovery"
          : "artist_or_place_detail",
      freshnessNeed: currentness(input.question),
      riskLevel: "ordinary",
      needsClarification: false,
      clarificationQuestion: null,
      directAnswerInstruction: "Answer the music or artist question directly and accurately. Distinguish birthplace, upbringing, and scene association when material. Do not invent underground artists, current events, venues, or biographical claims. Do not create a guide or business list.",
      explorationPrompt: base.resolvedLocation?.city === "Atlanta" ? "Would you like to explore more of ATL music?" : "Would you like to explore more of the music scene?",
      explorationOptions: options(
        { id: "music_events", label: "See local music events" },
        { id: "music_venues", label: "Explore music venues & underground clubs" },
        { id: "artist_detail", label: "Learn more about these artists" },
      ),
      sourceNotePolicy: currentness(input.question) === "current"
        ? { kind: "current_detail", text: "Current details can change. Confirm with the original source before acting." }
        : { kind: "none" },
      communityLearningDestination: "coverage_gap",
    };
  }

  if (topic === "art") {
    return {
      ...base,
      requestType: /\b(event|events|exhibit|exhibition|opening|this weekend|today|tonight)\b/i.test(input.question) ? "current_events" : "artist_or_place_detail",
      freshnessNeed: currentness(input.question),
      riskLevel: "ordinary",
      needsClarification: false,
      clarificationQuestion: null,
      directAnswerInstruction: "Answer the art question directly with cultural context. Do not turn an art question into a generic shopping or restaurant guide. Do not invent exhibit dates, gallery hours, or artist representation.",
      explorationPrompt: base.resolvedLocation ? "Would you like to explore more of the local art scene?" : "Would you like to explore art events, places, or artists?",
      explorationOptions: options(
        { id: "art_events", label: "See current art events" },
        { id: "galleries_studios_artwalks", label: "Explore galleries, studios & art walks" },
        { id: "local_artists", label: "Learn about local artists" },
      ),
      sourceNotePolicy: currentness(input.question) === "current"
        ? { kind: "current_detail", text: "Current details can change. Confirm with the original source before acting." }
        : { kind: "none" },
      communityLearningDestination: "coverage_gap",
    };
  }

  if (topic === "market_pricing" || topic === "housing") {
    if (topic === "market_pricing" && isAmbiguousMarketQuestion(input.question)) {
      return {
        ...base,
        requestType: "price_or_trend",
        freshnessNeed: "current",
        riskLevel: "decision_support",
        needsClarification: true,
        clarificationQuestion: "When you say market pricing, do you mean housing, groceries, art, or retail pricing?",
        directAnswerInstruction: "Ask only the clarification question. Do not provide prices, a guide, or local businesses until the member identifies the market.",
        explorationPrompt: null,
        explorationOptions: [],
        sourceNotePolicy: { kind: "none" },
        communityLearningDestination: "none",
      };
    }

    const housing = topic === "housing" || /\b(housing|home|rent|mortgage|real estate)\b/i.test(input.question);
    return {
      ...base,
      requestType: "price_or_trend",
      freshnessNeed: "current",
      riskLevel: "decision_support",
      needsClarification: false,
      clarificationQuestion: null,
      directAnswerInstruction: housing
        ? "Explain the available housing-market context in plain language. State the period and source for any current number. Do not give individualized financial, tax, or investment advice and do not preload realtors or businesses."
        : "Explain the identified market or affordability context in plain language. State the period and source for any current number. Do not preload businesses.",
      explorationPrompt: housing ? "Would you like to explore the next step?" : "Would you like to explore this market further?",
      explorationOptions: housing
        ? options(
            { id: "housing_price_trends", label: "See neighborhood trends" },
            { id: "homebuyer_resources", label: "Explore homebuyer resources" },
            { id: "local_housing_support", label: "Find local housing support" },
          )
        : options(
            { id: "grocery_price_sources", label: "See current price sources" },
            { id: "local_affordability_resources", label: "Explore affordability resources" },
            { id: "art_market_context", label: "Learn about the local art market" },
          ),
      sourceNotePolicy: { kind: "current_detail", text: "Current details can change. Confirm with the original source before acting." },
      communityLearningDestination: "living_library",
    };
  }

  if (topic === "health") {
    const urgent = URGENT_HEALTH_PATTERN.test(input.question);
    return {
      ...base,
      requestType: urgent ? "professional_support" : "general_information",
      freshnessNeed: "durable",
      riskLevel: "high_stakes",
      needsClarification: false,
      clarificationQuestion: null,
      directAnswerInstruction: urgent
        ? "State the urgent next step plainly: if there may be an immediate emergency, contact local emergency services now. Do not provide a diagnosis, a business list, or a generic guide."
        : "Provide educational health information in a calm, non-diagnostic way. Explain uncertainty where appropriate and help the member prepare questions for a clinician. Do not diagnose or preload professionals.",
      explorationPrompt: urgent ? null : "Would you like help with the next step?",
      explorationOptions: urgent
        ? []
        : options(
            { id: "health_basics", label: "Understand the basics" },
            { id: "clinician_questions", label: "Prepare questions for a care visit" },
            { id: "community_informed_support", label: "Explore community-informed support" },
            { id: "local_professional_options", label: "See local professional options" },
          ),
      sourceNotePolicy: { kind: "high_stakes", text: "This is educational information, not a diagnosis or a substitute for professional care." },
      communityLearningDestination: "living_library",
    };
  }

  if (topic === "legal") {
    return {
      ...base,
      requestType: "professional_support",
      freshnessNeed: "current",
      riskLevel: "high_stakes",
      needsClarification: false,
      clarificationQuestion: null,
      directAnswerInstruction: "Provide general educational information and immediate practical questions/documents to organize. Do not give legal advice or preload attorneys.",
      explorationPrompt: "Would you like help with the next step?",
      explorationOptions: options({ id: "legal_resources", label: "See local legal resources" }),
      sourceNotePolicy: { kind: "high_stakes", text: "This is general information, not legal advice. Laws and deadlines depend on the facts and location." },
      communityLearningDestination: "living_library",
    };
  }

  if (topic === "education") {
    return {
      ...base,
      requestType: "general_information",
      freshnessNeed: "durable",
      riskLevel: "ordinary",
      needsClarification: false,
      clarificationQuestion: null,
      directAnswerInstruction: "Answer the education or pathway question directly. Do not convert it into a generic business list.",
      explorationPrompt: "Would you like to explore the next step?",
      explorationOptions: options({ id: "education_pathways", label: "Explore pathways and opportunities" }),
      sourceNotePolicy: { kind: "none" },
      communityLearningDestination: "living_library",
    };
  }

  return {
    ...base,
    requestType: "general_information",
    freshnessNeed: "durable",
    riskLevel: "ordinary",
    needsClarification: false,
    clarificationQuestion: null,
    directAnswerInstruction: "Answer the member's actual question directly. Do not create a guide, business list, or promotional path unless the member explicitly asks for one.",
    explorationPrompt: null,
    explorationOptions: [],
    sourceNotePolicy: { kind: "none" },
    communityLearningDestination: "none",
  };
}
