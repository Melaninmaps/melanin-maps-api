import {
  buildCommunityIntelligenceSystemPrompt,
  buildCommunityIntelligenceUserPrompt,
  KINFOLK_COMMUNITY_INTELLIGENCE_RESPONSE_SCHEMA,
  type KinfolkCommunityIntelligenceModelResponse,
  validateCommunityIntelligenceModelResponse,
} from "./communityIntelligencePrompt";
import { resolveCommunityIntelligencePlan } from "./communityIntelligencePolicy";
import type { KinfolkCommunityIntelligenceInput } from "./types";

export type KinfolkStructuredModel = {
  complete(input: {
    messages: Array<{ role: "system" | "user"; content: string }>;
    responseFormat: typeof KINFOLK_COMMUNITY_INTELLIGENCE_RESPONSE_SCHEMA;
  }): Promise<string>;
};

export type CommunityIntelligenceAnswerInput = KinfolkCommunityIntelligenceInput & {
  retrievedContext: string;
};

/**
 * Server-only orchestration. Wire the existing Kinfolk LLM client into the
 * KinfolkStructuredModel adapter; never call the LLM from React/client code.
 */
export async function answerWithCommunityIntelligencePrompt(input: {
  model: KinfolkStructuredModel;
  request: CommunityIntelligenceAnswerInput;
}): Promise<KinfolkCommunityIntelligenceModelResponse> {
  const plan = resolveCommunityIntelligencePlan(input.request);
  const raw = await input.model.complete({
    messages: [
      { role: "system", content: buildCommunityIntelligenceSystemPrompt(plan) },
      {
        role: "user",
        content: buildCommunityIntelligenceUserPrompt({
          question: input.request.question,
          retrievedContext: input.request.retrievedContext,
        }),
      },
    ],
    responseFormat: KINFOLK_COMMUNITY_INTELLIGENCE_RESPONSE_SCHEMA,
  });

  let parsed: KinfolkCommunityIntelligenceModelResponse;
  try {
    parsed = JSON.parse(raw) as KinfolkCommunityIntelligenceModelResponse;
  } catch {
    throw new Error("Kinfolk model returned invalid community-intelligence JSON.");
  }
  return validateCommunityIntelligenceModelResponse({ plan, response: parsed });
}
