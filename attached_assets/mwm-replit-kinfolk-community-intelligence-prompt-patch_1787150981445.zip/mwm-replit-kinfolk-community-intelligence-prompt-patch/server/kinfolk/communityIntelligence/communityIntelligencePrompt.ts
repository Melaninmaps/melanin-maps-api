import type {
  ExplorationOption,
  KinfolkCommunityIntelligencePlan,
} from "./types";

export type KinfolkCommunityIntelligenceModelResponse = {
  answer: string;
  sourceNote: string | null;
  needsClarification: boolean;
  clarificationQuestion: string | null;
  explorationPrompt: string | null;
  explorationOptions: ExplorationOption[];
  guide: null;
  autoResults: [];
};

const FORBIDDEN_GENERIC_DISCLAIMER = "I can give general context, but I could not verify a source for the specific factual details.";

export const KINFOLK_COMMUNITY_INTELLIGENCE_RESPONSE_SCHEMA = {
  type: "json_schema",
  json_schema: {
    name: "kinfolk_community_intelligence_response",
    strict: true,
    schema: {
      type: "object",
      additionalProperties: false,
      required: [
        "answer",
        "sourceNote",
        "needsClarification",
        "clarificationQuestion",
        "explorationPrompt",
        "explorationOptions",
        "guide",
        "autoResults",
      ],
      properties: {
        answer: { type: "string" },
        sourceNote: { anyOf: [{ type: "string" }, { type: "null" }] },
        needsClarification: { type: "boolean" },
        clarificationQuestion: { anyOf: [{ type: "string" }, { type: "null" }] },
        explorationPrompt: { anyOf: [{ type: "string" }, { type: "null" }] },
        explorationOptions: {
          type: "array",
          items: {
            type: "object",
            additionalProperties: false,
            required: ["id", "label", "requiresConsent"],
            properties: {
              id: { type: "string" },
              label: { type: "string" },
              requiresConsent: { type: "boolean" },
            },
          },
        },
        guide: { type: "null" },
        autoResults: { type: "array", maxItems: 0 },
      },
    },
  },
} as const;

function planSummary(plan: KinfolkCommunityIntelligencePlan): string {
  return JSON.stringify({
    topic: plan.topic,
    requestType: plan.requestType,
    locationState: plan.locationState,
    resolvedLocation: plan.resolvedLocation,
    freshnessNeed: plan.freshnessNeed,
    riskLevel: plan.riskLevel,
    needsClarification: plan.needsClarification,
    clarificationQuestion: plan.clarificationQuestion,
    directAnswerInstruction: plan.directAnswerInstruction,
    explorationPrompt: plan.explorationPrompt,
    explorationOptions: plan.explorationOptions,
    sourceNotePolicy: plan.sourceNotePolicy,
    forbidAutoResults: plan.forbidAutoResults,
    forbidGenericGuide: plan.forbidGenericGuide,
    forbidUnrelatedBusinessFallback: plan.forbidUnrelatedBusinessFallback,
    researchPlan: plan.researchPlan,
    communityLearningDestination: plan.communityLearningDestination,
  });
}

/**
 * This is the shared Kinfolk system prompt. It is a policy template, not a
 * hidden sales or business-discovery instruction. The handler supplies a plan
 * created by resolveCommunityIntelligencePlan and relevant cited/retrieved
 * context. No client-side model call is permitted.
 */
export function buildCommunityIntelligenceSystemPrompt(plan: KinfolkCommunityIntelligencePlan): string {
  return `You are Kinfolk, Mapping With Melanin's community-intelligence companion.

Your job is to answer the member's actual question clearly, respectfully, and in a culturally aware way. You are not a sales funnel, a generic city-guide generator, or a directory card generator.

NON-NEGOTIABLE RESPONSE ORDER
1. Understand the member's precise subject, request, supplied location, freshness need, and risk level.
2. Answer the actual question first.
3. Ask exactly one clarification question only when the supplied policy says clarification is needed. Do not retrieve results or add options in that case.
4. Offer only the policy-approved optional next paths after the direct answer. Every path is optional and must require explicit member selection.
5. Never preload a directory result, event, business, guide, must-visit spot, promotion, or recommendation card. The server retrieves content only after the member chooses a path.

COMMUNITY-INTELLIGENCE RULES
- Use research-backed knowledge for durable information.
- Use current local sources only for time-sensitive details, such as events, prices, hours, openings, schedules, or availability.
- Use Community-Sourced information only when it is moderated or explicitly supplied as approved context. Never promote an unverified member statement to fact.
- When the current evidence is thin, answer what can be supported and leave room for a relevant community-sourced coverage path. Do not invent names, venues, events, underground artists, prices, availability, biographies, or local listings.
- The research plan is diaspora-first. When research is required, the retrieval layer searches the Black-women lens first, then the broader Black-diaspora context, before any general search. Do not claim a search occurred unless retrieved context is actually supplied.

SOURCE-NOTE RULES
- Never append this sentence or a paraphrase of it: "${FORBIDDEN_GENERIC_DISCLAIMER}"
- Omit unsupported claims instead of writing a generic source disclaimer.
- The sourceNote field must be null unless the policy specifically permits it.
- For current/live details, use only the exact small note provided by the policy.
- For high-stakes topics, use only the policy's specific educational/legal/medical note. Do not repeat it in unrelated cultural answers.

NO-IRRELEVANT-FALLBACK RULES
- Do not turn music, art, history, market, health, housing, or education questions into generic business promotion.
- Do not create “Your Guide To,” “Must-Visit Spots,” generic business lists, or unrelated restaurants/bookstores/retail cards.
- Do not label distant or nationwide results as local.
- Do not ask for a city if the member's city has already been resolved.
- Do not use Unicode emoji or pictographs in Kinfolk-owned text; the client supplies MWM gold-outline visual accents.

HIGH-STAKES RULES
- Medical: provide educational information, not a diagnosis; do not preload clinicians; urgent symptoms require the policy-directed urgent next step.
- Legal: provide general information, not legal advice; do not preload attorneys.
- Market pricing/housing: state the period and source for any current number; do not give individualized financial, tax, or investment advice; do not preload realtors or businesses.

Return JSON only and follow the response schema exactly.

ACTIVE COMMUNITY-INTELLIGENCE PLAN:
${planSummary(plan)}`;
}

export function buildCommunityIntelligenceUserPrompt(input: {
  question: string;
  retrievedContext: string;
}): string {
  return `MEMBER QUESTION:
${input.question}

APPROVED RETRIEVED CONTEXT:
${input.retrievedContext || "No retrieved context was supplied for this first-turn answer."}

Produce the direct answer and only the policy-approved optional paths. Never create results or a guide in this response.`;
}

function sameOptions(actual: ExplorationOption[], expected: ExplorationOption[]): boolean {
  return actual.length === expected.length && actual.every((item, index) =>
    item.id === expected[index]?.id &&
    item.label === expected[index]?.label &&
    item.requiresConsent === true,
  );
}

/**
 * Rejects a model output that tries to recreate the generic guide, silently
 * change exploration options, or attach a boilerplate disclaimer.
 */
export function validateCommunityIntelligenceModelResponse(input: {
  plan: KinfolkCommunityIntelligencePlan;
  response: KinfolkCommunityIntelligenceModelResponse;
}): KinfolkCommunityIntelligenceModelResponse {
  const { plan, response } = input;
  const combinedText = [response.answer, response.sourceNote ?? "", response.clarificationQuestion ?? ""].join(" ");

  if (!response.answer.trim()) throw new Error("Kinfolk community-intelligence response requires a direct answer.");
  if (/your guide to|must-visit spots/i.test(combinedText)) throw new Error("Kinfolk response attempted forbidden generic guide language.");
  if (combinedText.toLocaleLowerCase("en-US").includes(FORBIDDEN_GENERIC_DISCLAIMER.toLocaleLowerCase("en-US"))) {
    throw new Error("Kinfolk response attempted forbidden generic source disclaimer.");
  }
  if (response.guide !== null || response.autoResults.length !== 0) {
    throw new Error("Kinfolk response attempted preloaded results or a guide.");
  }

  if (plan.needsClarification) {
    if (!response.needsClarification || response.clarificationQuestion !== plan.clarificationQuestion) {
      throw new Error("Kinfolk response must use the exact approved clarification question.");
    }
    if (response.explorationPrompt !== null || response.explorationOptions.length !== 0) {
      throw new Error("Kinfolk response cannot offer paths before the required clarification.");
    }
    if (response.sourceNote !== null) throw new Error("Kinfolk clarification cannot append a source note.");
    return response;
  }

  if (response.needsClarification || response.clarificationQuestion !== null) {
    throw new Error("Kinfolk response introduced an unapproved clarification question.");
  }
  if (response.explorationPrompt !== plan.explorationPrompt || !sameOptions(response.explorationOptions, plan.explorationOptions)) {
    throw new Error("Kinfolk response changed the approved optional exploration paths.");
  }

  if (plan.sourceNotePolicy.kind === "none" && response.sourceNote !== null) {
    throw new Error("Kinfolk response attached an unapproved source note.");
  }
  if (plan.sourceNotePolicy.kind !== "none" && response.sourceNote !== plan.sourceNotePolicy.text) {
    throw new Error("Kinfolk response source note does not match the contextual policy.");
  }
  return response;
}
