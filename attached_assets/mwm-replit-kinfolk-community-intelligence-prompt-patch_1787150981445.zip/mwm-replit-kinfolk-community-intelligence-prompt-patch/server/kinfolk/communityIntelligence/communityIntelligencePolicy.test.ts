import { describe, expect, it } from "vitest";
import { resolveCommunityIntelligencePlan } from "./communityIntelligencePolicy";
import { validateCommunityIntelligenceModelResponse } from "./communityIntelligencePrompt";

const standard = {
  memberCity: null,
  memberStateCode: null,
  preferredTone: "warm_standard" as const,
};

describe("Kinfolk community-intelligence policy", () => {
  it("answers ATL music questions directly without a boilerplate source note or automatic guide", () => {
    const plan = resolveCommunityIntelligencePlan({ ...standard, question: "what rappers are from ATL" });

    expect(plan.topic).toBe("music");
    expect(plan.resolvedLocation).toEqual({ city: "Atlanta", stateCode: "GA" });
    expect(plan.needsClarification).toBe(false);
    expect(plan.sourceNotePolicy).toEqual({ kind: "none" });
    expect(plan.forbidAutoResults).toBe(true);
    expect(plan.forbidGenericGuide).toBe(true);
    expect(plan.forbidUnrelatedBusinessFallback).toBe(true);
    expect(plan.explorationOptions.map((option) => option.id)).toEqual([
      "music_events",
      "music_venues",
      "artist_detail",
      "dismiss",
    ]);
    expect(plan.researchPlan.queryGuidance[0]).toContain("Black women music and hip-hop Atlanta");
  });

  it("keeps art questions out of generic business promotion and offers only art-relevant paths", () => {
    const plan = resolveCommunityIntelligencePlan({ ...standard, question: "What is the ATL art scene like?" });

    expect(plan.topic).toBe("art");
    expect(plan.explorationOptions.map((option) => option.id)).toEqual([
      "art_events",
      "galleries_studios_artwalks",
      "local_artists",
      "dismiss",
    ]);
    expect(plan.directAnswerInstruction).toMatch(/generic shopping or restaurant guide/i);
  });

  it("asks exactly one clarification for an ambiguous market-pricing question", () => {
    const plan = resolveCommunityIntelligencePlan({ ...standard, question: "What is ATL market pricing?" });

    expect(plan.topic).toBe("market_pricing");
    expect(plan.needsClarification).toBe(true);
    expect(plan.clarificationQuestion).toBe("When you say market pricing, do you mean housing, groceries, art, or retail pricing?");
    expect(plan.explorationOptions).toEqual([]);
    expect(plan.sourceNotePolicy).toEqual({ kind: "none" });
  });

  it("uses current-detail policy for a specified housing market question without preloading realtors", () => {
    const plan = resolveCommunityIntelligencePlan({ ...standard, question: "What are Atlanta housing market prices?" });

    expect(plan.topic).toBe("housing");
    expect(plan.freshnessNeed).toBe("current");
    expect(plan.sourceNotePolicy).toEqual({
      kind: "current_detail",
      text: "Current details can change. Confirm with the original source before acting.",
    });
    expect(plan.explorationOptions.map((option) => option.id)).toEqual([
      "housing_price_trends",
      "homebuyer_resources",
      "local_housing_support",
      "dismiss",
    ]);
    expect(plan.directAnswerInstruction).toMatch(/Do not preload realtors/i);
  });

  it("keeps health information educational, adds the contextual high-stakes note, and requires consent for local options", () => {
    const plan = resolveCommunityIntelligencePlan({ ...standard, question: "What should I consider about thinning hair?" });

    expect(plan.topic).toBe("health");
    expect(plan.riskLevel).toBe("high_stakes");
    expect(plan.sourceNotePolicy).toEqual({
      kind: "high_stakes",
      text: "This is educational information, not a diagnosis or a substitute for professional care.",
    });
    expect(plan.explorationOptions.map((option) => option.id)).toEqual([
      "health_basics",
      "clinician_questions",
      "community_informed_support",
      "local_professional_options",
      "dismiss",
    ]);
  });

  it("rejects the forbidden generic source disclaimer and any preloaded guide", () => {
    const plan = resolveCommunityIntelligencePlan({ ...standard, question: "what rappers are from ATL" });

    expect(() => validateCommunityIntelligenceModelResponse({
      plan,
      response: {
        answer: "Atlanta has many rappers. I can give general context, but I could not verify a source for the specific factual details.",
        sourceNote: null,
        needsClarification: false,
        clarificationQuestion: null,
        explorationPrompt: plan.explorationPrompt,
        explorationOptions: plan.explorationOptions,
        guide: null,
        autoResults: [],
      },
    })).toThrow(/forbidden generic source disclaimer/i);

    expect(() => validateCommunityIntelligenceModelResponse({
      plan,
      response: {
        answer: "Atlanta has many rappers.",
        sourceNote: null,
        needsClarification: false,
        clarificationQuestion: null,
        explorationPrompt: plan.explorationPrompt,
        explorationOptions: plan.explorationOptions,
        guide: null,
        autoResults: [{}] as [],
      },
    })).toThrow(/preloaded results or a guide/i);
  });

  it("accepts a policy-conforming music response with no automatic results", () => {
    const plan = resolveCommunityIntelligencePlan({ ...standard, question: "what rappers are from ATL" });

    const response = validateCommunityIntelligenceModelResponse({
      plan,
      response: {
        answer: "Atlanta and the wider metro scene have been central to hip-hop for decades.",
        sourceNote: null,
        needsClarification: false,
        clarificationQuestion: null,
        explorationPrompt: plan.explorationPrompt,
        explorationOptions: plan.explorationOptions,
        guide: null,
        autoResults: [],
      },
    });

    expect(response.answer).toContain("Atlanta");
  });
});
