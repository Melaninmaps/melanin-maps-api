import { expect, test } from "vitest";
import { OUTCOME_PREVIEW_SCENES } from "../client/src/features/preview/outcomePreviewScenes";

test("shows five value moments without feature-menu demos", () => {
  expect(OUTCOME_PREVIEW_SCENES).toHaveLength(5);
  expect(OUTCOME_PREVIEW_SCENES.map((scene) => scene.id)).toEqual(["need-to-nearby", "voice-to-context", "business-to-discovery", "culture-to-trail", "research-to-library"]);
});

test("uses curated preview states and never depends on a live Kinfolk or search response", () => {
  const sceneSource = JSON.stringify(OUTCOME_PREVIEW_SCENES);
  expect(sceneSource).not.toMatch(/fetch\(|api\/|kinfolk\/chat|search/i);
});

test("keeps the printed QR destination stable", () => {
  expect("/preview").toBe("/preview");
});

test("does not ask a visitor to type a question", () => {
  const copy = OUTCOME_PREVIEW_SCENES.map((scene) => `${scene.headline} ${scene.supporting}`).join(" ");
  expect(copy).not.toMatch(/type|ask kinfolk|enter a question/i);
});

test("keeps each scene focused on a visible human outcome", () => {
  for (const scene of OUTCOME_PREVIEW_SCENES) expect(scene.outcome.length).toBeGreaterThan(10);
});
