import { Navigate, Route } from "react-router-dom";
import { OutcomeLedPreview } from "./OutcomeLedPreview";

// Replace the prior menu-style preview implementation. Keep the QR route unchanged forever.
export const outcomePreviewRoutes = <>
  <Route path="/preview" element={<OutcomeLedPreview />} />
  <Route path="/app-preview" element={<Navigate replace to="/preview" />} />
  <Route path="/tour" element={<Navigate replace to="/preview" />} />
</>;

// The page must be static/curated. Do not mount search, chat, composer, location, map,
// business, Library, community, or network-query hooks inside the preview route.
