import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { PREVIEW_DEMOS, PREVIEW_EXPERIENCES, QR_STABLE_PREVIEW_PATH, type PreviewDemo, type PreviewExperience } from "./previewTourData";
import "./previewTour.css";

type Mode = "guided" | "explore";
const prefersReducedMotion = () => typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

function DemoVisual({ demo }: { demo: PreviewDemo }) {
  return <div aria-hidden="true" className={`preview-visual preview-visual--${demo.visual}`}><span className="preview-visual__glow" /><span className="preview-visual__mark" /> <span className="preview-visual__line preview-visual__line--one" /><span className="preview-visual__line preview-visual__line--two" /><span className="preview-visual__pin preview-visual__pin--one" /><span className="preview-visual__pin preview-visual__pin--two" /></div>;
}

export function PreviewTour() {
  const navigate = useNavigate(); const [params, setParams] = useSearchParams();
  const initialExperience = (params.get("experience") as PreviewExperience | null) ?? "community-member";
  const [mode, setMode] = useState<Mode>(params.get("mode") === "explore" ? "explore" : "guided");
  const [experience, setExperience] = useState<PreviewExperience>(PREVIEW_EXPERIENCES.some((item) => item.id === initialExperience) ? initialExperience : "community-member");
  const demos = useMemo(() => PREVIEW_DEMOS.filter((item) => item.experience === experience), [experience]);
  const [activeIndex, setActiveIndex] = useState(0); const [paused, setPaused] = useState(prefersReducedMotion());
  const active = demos[activeIndex] ?? demos[0];

  useEffect(() => { setActiveIndex(0); }, [experience, mode]);
  useEffect(() => { if (mode !== "guided" || paused) return; const timer = window.setInterval(() => setActiveIndex((index) => (index + 1) % demos.length), 4800); return () => window.clearInterval(timer); }, [demos.length, mode, paused]);
  function setModeWithUrl(next: Mode) { setMode(next); setParams((previous) => { previous.set("mode", next); return previous; }, { replace: true }); }
  function chooseExperience(next: PreviewExperience) { setExperience(next); setParams((previous) => { previous.set("experience", next); return previous; }, { replace: true }); }

  return <main className="preview-tour" data-mode={mode}><header className="preview-tour__header"><p className="preview-tour__eyebrow">MAPPING WITH MELANIN</p><h1>See the community in motion.</h1><p>Choose a guided animated preview or explore the platform at your own pace.</p><div aria-label="Preview mode" className="preview-tour__modes" role="tablist"><button aria-selected={mode === "guided"} onClick={() => setModeWithUrl("guided")} role="tab">Guided preview</button><button aria-selected={mode === "explore"} onClick={() => setModeWithUrl("explore")} role="tab">Explore the experiences</button></div></header>
    <section aria-label="Experiences" className="preview-tour__experiences">{PREVIEW_EXPERIENCES.map((item) => <button aria-pressed={experience === item.id} key={item.id} onClick={() => chooseExperience(item.id)}><strong>{item.label}</strong><span>{item.description}</span></button>)}</section>
    <section aria-live="polite" className="preview-tour__stage"><DemoVisual demo={active} /><div className="preview-tour__content"><p className="preview-tour__label">{PREVIEW_EXPERIENCES.find((item) => item.id === active.experience)?.label} · {active.label}</p><h2>{active.title}</h2><p>{active.description}</p><button className="preview-tour__action" onClick={() => navigate(active.destination)}>{active.actionLabel}</button>{mode === "guided" ? <button aria-pressed={paused} className="preview-tour__pause" onClick={() => setPaused((value) => !value)}>{paused ? "Resume preview" : "Pause preview"}</button> : null}</div></section>
    <section className="preview-tour__demos" aria-label={`${PREVIEW_EXPERIENCES.find((item) => item.id === experience)?.label} features`}>{demos.map((demo, index) => <button aria-current={activeIndex === index ? "step" : undefined} key={demo.id} onClick={() => { setActiveIndex(index); setPaused(true); }}><span>{String(index + 1).padStart(2, "0")}</span><strong>{demo.label}</strong><small>{demo.title}</small></button>)}</section>
    <footer className="preview-tour__footer"><p><strong>QR-stable preview:</strong> existing QR codes continue to open <code>{QR_STABLE_PREVIEW_PATH}</code>. This tour is versioned by query parameters, not a replacement route.</p><Link to="/">Return to Mapping with Melanin</Link></footer>
  </main>;
}
