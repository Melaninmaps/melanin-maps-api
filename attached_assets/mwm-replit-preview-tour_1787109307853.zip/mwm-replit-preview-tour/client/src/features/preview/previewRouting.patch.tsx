import { Navigate, Route } from "react-router-dom";
import { PreviewTour } from "./PreviewTour";

// Keep /preview stable forever. Printed QR codes must resolve to this path.
// If the older preview used one of the legacy paths below, redirect it rather than changing the QR artwork.
export const previewTourRoutes = <>
  <Route path="/preview" element={<PreviewTour />} />
  <Route path="/app-preview" element={<Navigate replace to="/preview" />} />
  <Route path="/tour" element={<Navigate replace to="/preview" />} />
</>;

// The QR image generator must take its value from the one stable URL:
// const qrValue = new URL('/preview', window.location.origin).toString();
// Never make a QR code to a build ID, preview deployment URL, or query string.
