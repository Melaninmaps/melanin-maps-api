import { expect, test } from "vitest";
import { PREVIEW_DEMOS, PREVIEW_EXPERIENCES, QR_STABLE_PREVIEW_PATH } from "../client/src/features/preview/previewTourData";

test("keeps the existing QR destination stable", () => {
  expect(QR_STABLE_PREVIEW_PATH).toBe("/preview");
  expect(QR_STABLE_PREVIEW_PATH).not.toMatch(/build|preview-id|query/i);
});

test("contains exactly five experiences with at least three demonstrations each", () => {
  expect(PREVIEW_EXPERIENCES).toHaveLength(5);
  for (const experience of PREVIEW_EXPERIENCES) expect(PREVIEW_DEMOS.filter((demo) => demo.experience === experience.id)).toHaveLength(3);
  expect(PREVIEW_DEMOS).toHaveLength(15);
});

test("includes community alerts without the former Community Safety language", () => {
  const alert = PREVIEW_DEMOS.find((demo) => demo.id === "member-alerts");
  expect(alert?.title).toMatch(/informed/i);
  expect(JSON.stringify(PREVIEW_DEMOS)).not.toMatch(/community safety/i);
});

test("gives every demonstration a real in-app destination", () => {
  for (const demo of PREVIEW_DEMOS) expect(demo.destination).toMatch(/^\//);
});
