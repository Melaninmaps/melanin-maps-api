import { describe, expect, it, vi } from "vitest";
import { resolveKinfolkIntent } from "./intentResolver";
import { getConsentBasedProfessionalResults } from "./optionalProfessionalResults";
import { composeKinfolkCapabilityResponse } from "./responseComposer";

const localContextRepository = {
  resolvePlacePhrase: vi.fn(async ({ phrase, memberCity }: { phrase: string; memberCity: string | null }) =>
    phrase === "uptown" && memberCity === "Charlotte"
      ? {
          city: "Charlotte",
          stateCode: "NC",
          neighborhood: "Uptown",
          placeMeaning: "Uptown Charlotte",
          confidence: 0.96,
        }
      : null,
  ),
};

describe("Kinfolk capability layer", () => {
  it("offers, but does not preload, local attorneys after a legal-information question", async () => {
    const intent = await resolveKinfolkIntent({
      message: "I am dealing with an eviction notice. What should I understand?",
      preferredTone: "warm_standard",
      memberLocation: { city: "Charlotte", stateCode: "NC" },
      localContextRepository,
    });
    const response = composeKinfolkCapabilityResponse(intent);

    expect(response.optionalAction?.id).toBe("show_local_attorneys");
    expect(response.professionalResults).toBeNull();
    expect(response.message).toContain("not legal advice");
  });

  it("returns verified professionals only after the member chooses the optional action", async () => {
    const intent = await resolveKinfolkIntent({
      message: "I need a lawyer for a housing issue",
      preferredTone: "warm_standard",
      memberLocation: { city: "Charlotte", stateCode: "NC" },
      localContextRepository,
    });
    const directoryRepository = {
      findNearestVerifiedProfessionals: vi.fn(async () => [
        {
          id: "attorney-1",
          name: "Verified Attorney",
          category: "Housing Attorney",
          city: "Charlotte",
          stateCode: "NC",
          addressLine1: "100 Example Street",
          distanceMiles: 2.5,
          detailUrl: "/businesses/attorney-1",
          isVerified: true,
        },
      ]),
    };

    const result = await getConsentBasedProfessionalResults({ intent, directoryRepository });
    expect(directoryRepository.findNearestVerifiedProfessionals).toHaveBeenCalledOnce();
    expect(result.professionalResults?.[0]?.name).toBe("Verified Attorney");
  });

  it("recognizes Uptown using the member’s city context", async () => {
    const intent = await resolveKinfolkIntent({
      message: "I need to make a stop Uptown",
      preferredTone: "warm_standard",
      memberLocation: { city: "Charlotte", stateCode: "NC" },
      localContextRepository,
    });

    expect(intent.localContext.placeMeaning).toBe("Uptown Charlotte");
    expect(intent.localContext.city).toBe("Charlotte");
  });

  it("uses community conversational language only when the member selected it", async () => {
    const conversationalIntent = await resolveKinfolkIntent({
      message: "Yall know a good plumber?",
      preferredTone: "community_conversational",
      memberLocation: { city: "Charlotte", stateCode: "NC" },
      localContextRepository,
    });
    const standardIntent = await resolveKinfolkIntent({
      message: "Yall know a good plumber?",
      preferredTone: "warm_standard",
      memberLocation: { city: "Charlotte", stateCode: "NC" },
      localContextRepository,
    });

    expect(composeKinfolkCapabilityResponse(conversationalIntent).message).toMatch(/^Y'all,/);
    expect(composeKinfolkCapabilityResponse(standardIntent).message).not.toMatch(/^Y'all,/);
    expect(conversationalIntent.professionalOffer).toBe("plumber");
  });

  it("does not offer a local clinician card for an urgent safety signal", async () => {
    const intent = await resolveKinfolkIntent({
      message: "I have chest pain and cannot breathe",
      preferredTone: "warm_standard",
      memberLocation: { city: "Charlotte", stateCode: "NC" },
      localContextRepository,
    });
    const response = composeKinfolkCapabilityResponse(intent);

    expect(intent.urgentSafetyFlag).toBe(true);
    expect(response.optionalAction).toBeNull();
  });
});
