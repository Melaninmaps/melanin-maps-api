import assert from "node:assert/strict";
import { resolveKinfolkIntent } from "./server/kinfolk/capabilities/intentResolver";
import { getConsentBasedProfessionalResults } from "./server/kinfolk/capabilities/optionalProfessionalResults";
import { composeKinfolkCapabilityResponse } from "./server/kinfolk/capabilities/responseComposer";

const localContextRepository = {
  async resolvePlacePhrase({ phrase, memberCity }: { phrase: string; memberCity: string | null }) {
    if (phrase === "uptown" && memberCity === "Charlotte") {
      return {
        city: "Charlotte",
        stateCode: "NC",
        neighborhood: "Uptown",
        placeMeaning: "Uptown Charlotte",
        confidence: 0.96,
      };
    }
    return null;
  },
};

async function main() {
  const legalIntent = await resolveKinfolkIntent({
    message: "I have an eviction notice. What should I understand?",
    preferredTone: "warm_standard",
    memberLocation: { city: "Charlotte", stateCode: "NC" },
    localContextRepository,
  });
  const legalResponse = composeKinfolkCapabilityResponse(legalIntent);
  assert.equal(legalResponse.optionalAction?.id, "show_local_attorneys");
  assert.equal(legalResponse.professionalResults, null);

  const localDirectory = {
    async findNearestVerifiedProfessionals() {
      return [
        {
          id: "attorney-1",
          name: "Verified Attorney",
          category: "Housing Attorney",
          city: "Charlotte",
          stateCode: "NC",
          addressLine1: "100 Example Street",
          distanceMiles: 2.5,
          detailUrl: "/businesses/attorney-1",
          isVerified: true,
        },
      ];
    },
  };
  const consentedResults = await getConsentBasedProfessionalResults({
    intent: legalIntent,
    directoryRepository: localDirectory,
  });
  assert.equal(consentedResults.professionalResults?.[0]?.name, "Verified Attorney");

  const uptownIntent = await resolveKinfolkIntent({
    message: "I need to make a stop Uptown",
    preferredTone: "warm_standard",
    memberLocation: { city: "Charlotte", stateCode: "NC" },
    localContextRepository,
  });
  assert.equal(uptownIntent.localContext.placeMeaning, "Uptown Charlotte");

  const conversationalIntent = await resolveKinfolkIntent({
    message: "Yall know a good plumber?",
    preferredTone: "community_conversational",
    memberLocation: { city: "Charlotte", stateCode: "NC" },
    localContextRepository,
  });
  assert.match(composeKinfolkCapabilityResponse(conversationalIntent).message, /^Y'all,/);

  console.log("Kinfolk capability smoke test passed.");
}

void main();
