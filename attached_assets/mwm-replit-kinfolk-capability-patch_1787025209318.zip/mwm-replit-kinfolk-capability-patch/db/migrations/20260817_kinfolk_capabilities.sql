-- PostgreSQL migration: Kinfolk capability and consent layer.
-- Adjust `users`, `cities`, and their column names only if this Replit project
-- uses different table names.

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS kinfolk_tone TEXT NOT NULL DEFAULT 'warm_standard',
  ADD CONSTRAINT users_kinfolk_tone_check
    CHECK (kinfolk_tone IN ('warm_standard', 'community_conversational', 'concise_professional'));

CREATE TABLE IF NOT EXISTS local_place_aliases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  city_id UUID NOT NULL REFERENCES cities(id) ON DELETE CASCADE,
  phrase TEXT NOT NULL,
  neighborhood TEXT,
  place_meaning TEXT NOT NULL,
  confidence NUMERIC(3,2) NOT NULL DEFAULT 0.90,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT local_place_aliases_city_phrase_unique UNIQUE (city_id, phrase)
);

CREATE INDEX IF NOT EXISTS local_place_aliases_lookup_idx
  ON local_place_aliases (LOWER(phrase));

-- Example. Seed only editorially verified local meanings; do not infer a
-- neighborhood label from vague text without city context.
INSERT INTO local_place_aliases (city_id, phrase, neighborhood, place_meaning, confidence)
SELECT id, 'uptown', 'Uptown', 'Uptown Charlotte', 0.96
FROM cities
WHERE LOWER(name) = 'charlotte' AND UPPER(state_code) = 'NC'
ON CONFLICT (city_id, phrase) DO UPDATE
SET neighborhood = EXCLUDED.neighborhood,
    place_meaning = EXCLUDED.place_meaning,
    confidence = EXCLUDED.confidence;

-- Keeps inferred intent server-side for thirty minutes so the client cannot
-- forge a request for a different professional type.
CREATE TABLE IF NOT EXISTS kinfolk_capability_turns (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  member_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  intent JSONB NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS kinfolk_capability_turns_lookup_idx
  ON kinfolk_capability_turns (id, member_id, expires_at);
