export const ATLANTA_HBCU_SEED = [
  { slug: "clark-atlanta-university", title: "Clark Atlanta University", addressLine1: "223 James P Brawley Drive SW", city: "Atlanta", stateRegion: "GA", postalCode: "30314", websiteUrl: "https://www.cau.edu/", sourceUrl: "https://aucenter.edu/member-institutions/", sourceLabel: "Atlanta University Center Consortium" },
  { slug: "morehouse-college", title: "Morehouse College", addressLine1: "830 Westview Drive SW", city: "Atlanta", stateRegion: "GA", postalCode: "30314", websiteUrl: "https://morehouse.edu/", sourceUrl: "https://morehouse.edu/contact-us", sourceLabel: "Morehouse College" },
  { slug: "spelman-college", title: "Spelman College", addressLine1: "350 Spelman Lane SW", city: "Atlanta", stateRegion: "GA", postalCode: "30314", websiteUrl: "https://www.spelman.edu/", sourceUrl: "https://aucenter.edu/member-institutions/", sourceLabel: "Atlanta University Center Consortium" },
  { slug: "morehouse-school-of-medicine", title: "Morehouse School of Medicine", addressLine1: "720 Westview Drive SW", city: "Atlanta", stateRegion: "GA", postalCode: "30310", websiteUrl: "https://www.msm.edu/", sourceUrl: "https://www.msm.edu/about_us/facts/facts_contactus.php", sourceLabel: "Morehouse School of Medicine" },
  { slug: "morris-brown-college", title: "Morris Brown College", addressLine1: "643 Martin Luther King Jr Drive", city: "Atlanta", stateRegion: "GA", postalCode: "30314", websiteUrl: "https://morrisbrown.edu/", sourceUrl: "https://morrisbrown.edu/contact-us/", sourceLabel: "Morris Brown College" },
  { slug: "interdenominational-theological-center", title: "Interdenominational Theological Center", addressLine1: "700 Martin Luther King Jr Drive SW", city: "Atlanta", stateRegion: "GA", postalCode: "30314", websiteUrl: "https://www.itc.edu/", sourceUrl: "https://www.itc.edu/about/map-direction/", sourceLabel: "Interdenominational Theological Center" },
] as const;

// Required release process: upsert these records, use the server's approved geocoder on the full
// institution-backed address, set geocode_status='resolved', then publish. Never use client guesses
// or placeholder coordinates. The promotion gate fails if fewer than six Atlanta HBCU records are
// present and routable in published_map_entities.
