import type { Express, NextFunction, Request, Response } from "express";
import type { Pool } from "pg";
const KINDS = new Set(["cultural_site", "hbcu", "festival", "community_event", "market", "public_art", "heritage_marker"]);

export function registerUniversalMapEntityRoutes(app: Express, pool: Pool) {
  app.get("/api/map/entities", async (request: Request, response: Response, next: NextFunction) => {
    try {
      const kind = typeof request.query.kind === "string" ? request.query.kind : undefined;
      const city = typeof request.query.city === "string" ? request.query.city.trim() : undefined;
      if (kind && !KINDS.has(kind)) return response.status(400).json({ code: "UNKNOWN_ENTITY_KIND" });
      const { rows } = await pool.query(`SELECT id,entity_kind,title,slug,summary,city,state_region,latitude,longitude,detail_url FROM published_map_entities WHERE ($1::text IS NULL OR entity_kind=$1) AND ($2::text IS NULL OR lower(city)=lower($2)) ORDER BY title`, [kind ?? null, city ?? null]);
      // This exact array is the only allowed source for both map pins and the side panel.
      return response.json({ items: rows, metadata: { kind: kind ?? "all", city: city ?? null, count: rows.length } });
    } catch (error) { return next(error); }
  });

  app.get("/api/places/:id", async (request: Request, response: Response, next: NextFunction) => {
    try {
      const { rows } = await pool.query(`SELECT id,entity_kind,title,slug,summary,address_line1,city,state_region,postal_code,latitude,longitude,website_url,source_url,source_label,'/places/' || id::text || '/' || slug AS detail_url FROM map_entities WHERE id=$1 AND published=true`, [request.params.id]);
      if (!rows[0]) return response.status(404).json({ code: "PLACE_NOT_FOUND" });
      return response.json(rows[0]);
    } catch (error) { return next(error); }
  });

  // Legacy type-specific paths do not render their own pages. They resolve the canonical entity and redirect.
  app.get("/api/legacy-place/:legacyKind/:legacyId", async (request: Request, response: Response, next: NextFunction) => {
    try {
      const { rows } = await pool.query(`SELECT p.id,p.slug FROM map_entity_aliases a JOIN map_entities p ON p.id=a.entity_id WHERE a.legacy_kind=$1 AND a.legacy_id=$2 AND p.published=true`, [request.params.legacyKind, request.params.legacyId]);
      if (!rows[0]) return response.status(404).json({ code: "LEGACY_PLACE_NOT_FOUND" });
      return response.redirect(308, `/places/${rows[0].id}/${rows[0].slug}`);
    } catch (error) { return next(error); }
  });
}
