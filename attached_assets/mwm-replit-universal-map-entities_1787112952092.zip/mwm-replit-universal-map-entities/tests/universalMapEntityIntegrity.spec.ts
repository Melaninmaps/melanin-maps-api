import { expect, test } from "vitest";
import { ATLANTA_HBCU_SEED } from "../server/map/atlantaHbcuSeed";

test("restores the institution-backed Atlanta HBCU foundation", () => {
  expect(ATLANTA_HBCU_SEED).toHaveLength(6);
  expect(ATLANTA_HBCU_SEED.map((item) => item.title)).toEqual(expect.arrayContaining(["Clark Atlanta University", "Morehouse College", "Spelman College", "Morehouse School of Medicine", "Morris Brown College", "Interdenominational Theological Center"]));
  for (const institution of ATLANTA_HBCU_SEED) { expect(institution.sourceUrl).toMatch(/^https:\/\//); expect(institution.addressLine1).toBeTruthy(); }
});

test("requires every map entity response record to be listable, pinnable, and routable", () => {
  const record = { id: "a7b90b34-7ef1-4d84-b6c5-c7a53d78e55a", entity_kind: "hbcu", title: "Example HBCU", latitude: 33.75, longitude: -84.41, detail_url: "/places/a7b90b34-7ef1-4d84-b6c5-c7a53d78e55a/example-hbcu" };
  expect(record.latitude).toBeTypeOf("number"); expect(record.longitude).toBeTypeOf("number"); expect(record.detail_url).toMatch(/^\/places\/[0-9a-f-]+\//);
});

test("uses one canonical entity path for all non-business detail links", () => {
  const allowedPath = "/places/";
  expect(allowedPath).toBe("/places/");
  expect("/cultural-sites/legacy").not.toMatch(/^\/places\//);
});
