const api = process.env.API_BASE_URL ?? "https://api.melaninmaps.com";
const web = process.env.WEB_BASE_URL ?? "https://www.mappingwithmelanin.com";
const kinds = ["cultural_site", "hbcu", "festival", "community_event", "market", "public_art", "heritage_marker"];

async function request(url: string) { const response = await fetch(url, { redirect: "manual" }); if (!response.ok) throw new Error(`${response.status} ${url}`); return response; }
async function verifyKind(kind: string, city: string) {
  const response = await request(`${api}/api/map/entities?kind=${kind}&city=${encodeURIComponent(city)}`);
  const payload = await response.json() as { items: { id: string; detail_url: string; latitude: number; longitude: number }[] };
  for (const item of payload.items) {
    if (!item.detail_url || !Number.isFinite(item.latitude) || !Number.isFinite(item.longitude)) throw new Error(`UNROUTABLE_OR_UNPINNABLE_ENTITY ${kind}:${item.id}`);
    await request(`${web}${item.detail_url}`);
    await request(`${api}/api/places/${item.id}`);
  }
  return payload.items.length;
}

async function main() {
  const atlantaHbcus = await verifyKind("hbcu", "Atlanta");
  if (atlantaHbcus < 6) throw new Error(`ATLANTA_HBCU_BASELINE_FAILED expected>=6 actual=${atlantaHbcus}`);
  for (const kind of kinds) await verifyKind(kind, "Atlanta");
  console.log("UNIVERSAL_MAP_ENTITY_INTEGRITY_OK");
}
main().catch((error) => { console.error(error); process.exit(1); });
