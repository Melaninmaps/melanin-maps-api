BEGIN;

CREATE TABLE IF NOT EXISTS public.map_entities (
  id uuid PRIMARY KEY,
  entity_kind text NOT NULL CHECK (entity_kind IN ('cultural_site','hbcu','festival','community_event','market','public_art','heritage_marker')),
  title text NOT NULL,
  slug text NOT NULL,
  summary text,
  address_line1 text,
  city text NOT NULL,
  state_region text,
  postal_code text,
  country_code char(2) NOT NULL DEFAULT 'US',
  latitude double precision,
  longitude double precision,
  website_url text,
  source_url text,
  source_label text,
  source_record_id uuid,
  published boolean NOT NULL DEFAULT false,
  geocode_status text NOT NULL DEFAULT 'queued' CHECK (geocode_status IN ('queued','resolved','failed')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (entity_kind, slug),
  CHECK ((latitude IS NULL AND longitude IS NULL) OR (latitude BETWEEN -90 AND 90 AND longitude BETWEEN -180 AND 180))
);
CREATE INDEX IF NOT EXISTS map_entities_browse_idx ON public.map_entities(entity_kind, city, state_region, published);
CREATE INDEX IF NOT EXISTS map_entities_coordinates_idx ON public.map_entities(latitude, longitude) WHERE published AND geocode_status='resolved';

CREATE TABLE IF NOT EXISTS public.map_entity_aliases (
  entity_id uuid NOT NULL REFERENCES public.map_entities(id) ON DELETE CASCADE,
  legacy_kind text NOT NULL,
  legacy_slug text,
  legacy_id uuid,
  PRIMARY KEY (entity_id, legacy_kind, legacy_slug)
);

-- The browse API uses this view for BOTH map pins and side-panel results.
CREATE OR REPLACE VIEW public.published_map_entities AS
SELECT id, entity_kind, title, slug, summary, address_line1, city, state_region, postal_code,
       country_code, latitude, longitude, website_url, source_url, source_label,
       '/places/' || id::text || '/' || slug AS detail_url
FROM public.map_entities
WHERE published = true AND geocode_status = 'resolved' AND latitude IS NOT NULL AND longitude IS NOT NULL;

COMMIT;
