import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

type Place = { id: string; entity_kind: string; title: string; slug: string; summary: string | null; address_line1: string | null; city: string; state_region: string | null; website_url: string | null; source_url: string | null; source_label: string | null; detail_url: string };
export function UniversalPlaceDetailPage() {
  const { id, slug } = useParams(); const navigate = useNavigate(); const [place, setPlace] = useState<Place | null>(null); const [state, setState] = useState<"loading" | "ready" | "missing">("loading");
  useEffect(() => { if (!id) return; fetch(`/api/places/${id}`).then(async (response) => { if (response.status === 404) throw new Error("missing"); if (!response.ok) throw new Error("failed"); return response.json() as Promise<Place>; }).then((record) => { setPlace(record); setState("ready"); if (slug !== record.slug) navigate(record.detail_url, { replace: true }); }).catch(() => setState("missing")); }, [id, slug, navigate]);
  if (state === "loading") return <main className="place-detail"><p>Loading place…</p></main>;
  if (state === "missing") return <main className="place-detail"><p>We could not find this published place.</p><Link to="/map">Return to the Map</Link></main>;
  return <main className="place-detail"><Link to="/map">← Back to Map</Link><p>{place?.entity_kind.replaceAll("_", " ")}</p><h1>{place?.title}</h1>{place?.summary ? <p>{place.summary}</p> : null}<p>{[place?.address_line1, place?.city, place?.state_region].filter(Boolean).join(", ")}</p>{place?.website_url ? <a href={place.website_url} rel="noreferrer" target="_blank">Visit official website</a> : null}{place?.source_url ? <a href={place.source_url} rel="noreferrer" target="_blank">Source: {place.source_label ?? "Learn more"}</a> : null}</main>;
}
