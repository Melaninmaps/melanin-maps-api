import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

type MapEntity = { id: string; entity_kind: string; title: string; slug: string; summary: string | null; city: string; state_region: string | null; latitude: number; longitude: number; detail_url: string };
type Props = { kind: "cultural_site" | "hbcu" | "festival" | "community_event" | "market" | "public_art" | "heritage_marker"; city: string; renderPins(items: MapEntity[]): React.ReactNode };

export function UniversalEntityLayer({ kind, city, renderPins }: Props) {
  const [items, setItems] = useState<MapEntity[]>([]); const [state, setState] = useState<"loading" | "ready" | "error">("loading");
  useEffect(() => { let active = true; setState("loading"); fetch(`/api/map/entities?kind=${encodeURIComponent(kind)}&city=${encodeURIComponent(city)}`).then(async (result) => { const payload = await result.json(); if (!result.ok) throw new Error(payload.code ?? "MAP_ENTITY_LOAD_FAILED"); return payload.items as MapEntity[]; }).then((records) => { if (active) { setItems(records); setState("ready"); } }).catch(() => { if (active) setState("error"); }); return () => { active = false; }; }, [kind, city]);
  if (state === "error") return <aside className="map-category-panel"><h2>{kind.replaceAll("_", " ")}</h2><p>We could not load this category. Please try again.</p></aside>;
  if (state === "loading") return <aside className="map-category-panel" aria-busy="true"><h2>{kind.replaceAll("_", " ")}</h2><p>Loading local places…</p></aside>;
  return <><aside className="map-category-panel"><h2>{kind.replaceAll("_", " ")}</h2><p>{items.length} {items.length === 1 ? "site" : "sites"}</p>{items.length ? <ul>{items.map((item) => <li key={item.id}><Link to={item.detail_url}><strong>{item.title}</strong><span>{item.city}{item.state_region ? `, ${item.state_region}` : ""}</span></Link></li>)}</ul> : <div><p>No published {kind.replaceAll("_", " ")} records are currently indexed for {city}.</p></div>}</aside>{renderPins(items)}</>;
}

// Do not pass a global map collection to renderPins. `items` above is the single source of truth.
