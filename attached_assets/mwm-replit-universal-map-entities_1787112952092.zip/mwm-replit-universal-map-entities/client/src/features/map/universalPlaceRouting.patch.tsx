import { Navigate, Route } from "react-router-dom";
import { UniversalPlaceDetailPage } from "./UniversalPlaceDetailPage";

export const universalPlaceRoutes = <>
  <Route path="/places/:id/:slug?" element={<UniversalPlaceDetailPage />} />
  <Route path="/cultural-sites/:id/:slug?" element={<Navigate replace to="/places/:id" />} />
  <Route path="/hbcus/:id/:slug?" element={<Navigate replace to="/places/:id" />} />
</>;

// The frontend deployment must serve the SPA index after static assets and API routes for /places/*.
// No non-business map marker may construct any other client route.
