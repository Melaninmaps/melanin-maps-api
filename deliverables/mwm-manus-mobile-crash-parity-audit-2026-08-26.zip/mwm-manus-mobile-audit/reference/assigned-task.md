# Mobile Crash And Parity Audit

## What & Why
Audit the Expo application across iOS and Android against the existing web experience, then fix confirmed crash risks and the highest-impact parity gaps instead of attempting an unbounded feature rewrite. The audit must also leave repeatable Replit validation scripts so regressions are caught before an EAS build or preview release.

The web media-posting and cultural-site link failures are already represented by Task #361 (shared media upload repair) and Tasks #285/#370 (cultural-site link and release verification). This task should verify mobile consumes the resulting contracts without creating a second upload or link implementation.

## Done looks like
- A written, code-grounded parity matrix identifies the critical web flows that exist on mobile, are missing, or behave differently, with the first fixes limited to confirmed high-impact gaps.
- iOS and Android checks run from Replit for TypeScript, Expo/Metro bundling, route imports, and native configuration; failures are actionable rather than silent.
- Confirmed crash risks in the audited flows are guarded with safe loading, permission-denied, malformed-response, timeout, and unavailable-resource states.
- Mobile community media posting uses the same server contract as the repaired web flow, preserves selected media through submission, and shows a recoverable error instead of silently dropping an image.
- Cultural-site and external-link navigation uses server-provided canonical URLs, validates external URLs before opening them, and safely handles unavailable links on both platforms.
- Existing website behavior remains unchanged except for the separately authorized media and cultural-site work already tracked in the project queue.
- Replit validation output records the tested iOS/Android parity checks and the known-good community-post, cultural-site, and place-control journeys.

## Out of scope
- Deploying to production, submitting to App Store Connect or Google Play, or changing EAS build numbers.
- Replacing Expo, React Native, the router, the map provider, authentication, or storage architecture.
- Rebuilding every website feature on mobile in one pass; lower-priority parity gaps become follow-up tasks after the matrix is reviewed.
- Duplicating the implementation already covered by Task #361 or Tasks #285/#370.
- Changes to KinfolkAI, database schema, unrelated business workflows, or production data.

## Steps
1. **Build the parity and crash inventory** -- Compare the critical web journeys with their mobile routes and components, trace confirmed crash-prone paths, and rank findings by user impact and reproducibility.
2. **Add Replit-native validation** -- Create scripts and checks for mobile typechecking, Expo/Metro bundling, route/config validation, and deterministic smoke coverage for the audited journeys.
3. **Harden confirmed failure paths** -- Add targeted guards for the audited crashes and native failure states, preserving the existing visual and navigation conventions on both platforms.
4. **Align shared contracts** -- Verify mobile media posting and cultural-site navigation against the repaired web/API contracts, including retryable upload failures, canonical links, and unavailable-resource handling.
5. **Run cross-platform verification** -- Execute the Replit checks plus authenticated web/mobile-compatible smoke coverage, document remaining gaps, and leave deployment decisions to a separate owner authorization.

## Relevant files
- `artifacts/mobile/app/_layout.tsx`
- `artifacts/mobile/lib/crashLogger.ts`
- `artifacts/mobile/app/(tabs)/community.tsx`
- `artifacts/mobile/components/FullMapView.tsx`
- `artifacts/mobile/components/BusinessMapView.tsx`
- `artifacts/mobile/package.json`
- `artifacts/mobile/app.json`
- `artifacts/web/src/pages/community.tsx`
- `artifacts/web/src/pages/cultural-site-detail.tsx`
- `artifacts/api-server/src/media/registerMediaRoutes.ts`
- `artifacts/api-server/src/routes/community.ts`
- `artifacts/api-server/src/routes/canonical-cultural-sites.ts`
- `artifacts/api-server/src/routes/directory/canonicalCulturalSiteRepository.ts`
- `docs/MANUS_PLATFORM_AUDIT_v1.0.md`